﻿using LimitlessUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemMonitor;
using SystemMonitor.Properties;
using SystemMonitor.Tabs;

namespace SystemMonitor
{
    public partial class MainForm : Form_WOC
    {
        private bool _isDrawerExpanded = true;
        private DataCollector _dataCollector = new DataCollector();
        private Sender _sender;

        public MainForm()
        {
            Utils_WOC._threadsForm = this;

            InitializeComponent();
            setupNavigation();
            hideBorders(0);

            TCPServer.onConnect += onConnect;
            TCPServer.onDisconnect += onDisconnect;

            if (!Settings.Default.lightTheme)
                setTheme(false);

            if (!Settings.Default.drawerExpanded)
                nav_panel.Width = 48;
            if (Settings.Default.runServer)
                TCPServer.startListeningInSeperateThread(4444, 2);
        }

        public void setTheme(bool isLight)
        {
            Bitmap[] images = isLight ? new Bitmap[] { Resources.dashboard_light_ic, Resources.cpu_light_ic, Resources.ram_light_ic, Resources.gpu_light_ic, Resources.remote_light_ic, Resources.settings_light_ic, Resources.hamburger_light_ic } :
                                                       new Bitmap[] { Resources.dashboard_dark_ic, Resources.cpu_dark_ic, Resources.ram_dark_ic, Resources.gpu_dark_ic, Resources.remote_dark_ic, Resources.settings_dark_ic, Resources.hamburger_dark_ic };

            foreach (FlatButton_WOC button in nav_panel.Controls)
            {
                button.BackColor = isLight ? Theme.Default.nav_light : Theme.Default.nav_dark;
               // button.DefaultBackColor = isLight ? Theme.Default.nav_light : Theme.Default.nav_dark;

                if (!button.Selected)
                    button.ForeColor = isLight ? Color.Black : Color.White;
             //   else button.DefaultForeColor = isLight ? Color.Black : Color.White;
                button.Image = images[button.TabIndex];
            }

            foreach (Control tab in tab_holder.Controls)
            {
                tab.BackColor = isLight ? Theme.Default.background_light : Theme.Default.background_dark;
                if (tab is Theme_interface)
                    ((Theme_interface)tab).themeChanged(isLight);
            }

            BackColor = isLight ? Theme.Default.background_light : Theme.Default.background_dark;
            nav_panel.BackColor = isLight ? Theme.Default.nav_light : Theme.Default.nav_dark;
            tabTitle_panel.BackColor = isLight ? Theme.Default.background_light : Theme.Default.background_dark;
            tabTitle_txt.ForeColor = isLight ? Color.Black : Color.White;
            hideBorders(0);
        }

        private void setupNavigation()
        {
           // drawer_anim._onAnimationStart_del += nav_animationStarted;
           // drawer_anim._onAnimationEnd_del += nav_animationEnded;

            drawer_anim._onWidthChanged_del += navWidth_changed;
            nav_adapter.addTab(Dashboard_Tab.getInstance(_dataCollector), true);
            nav_adapter.addTab(CPU_Tab.getInstance(_dataCollector), false);
            nav_adapter.addTab(RAM_Tab.getInstance(_dataCollector), false);
            nav_adapter.addTab(GPU_Tab.getInstance(_dataCollector), false);
            nav_adapter.addTab(RemoteMon_TAB.getInstance(_dataCollector), false);
            nav_adapter.addTab(Settings_Tab.getInstance(this), false);
        }


        public void hideBorders(int bottomExpanction)
        {
            clearLines();
            drawLine(LinePositions.TOP, title_bar.BackColor, 0, Width);
            drawLine(LinePositions.LEFT, title_bar.BackColor, 0, title_bar.Height + 3);
            drawLine(LinePositions.LEFT, Settings.Default.lightTheme ? nav_panel.BackColor : Theme.Default.nav_dark, title_bar.Height + 4, Height);
            drawLine(LinePositions.RIGHT, title_bar.BackColor, 0, title_bar.Height + 3);
            drawLine(LinePositions.BOTTOM, Settings.Default.lightTheme ? nav_panel.BackColor : Theme.Default.nav_dark, 0, nav_panel.Width + 2 + bottomExpanction);
            Invalidate();
        }

        private void onDisconnect(Socket socket)
        {
            Utils.showNotification(tray_ic, "System Monitor", "Client disconected", ToolTipIcon.None);
        }

        private void onConnect(Socket socket)
        {
            if (_sender == null)
                _sender = Sender.getInstance(_dataCollector);
            RemoteMon_TAB.getInstance(_dataCollector).Client = socket.RemoteEndPoint.ToString().Split(':')[0];
            Utils.showNotification(tray_ic, "Remote Monitor", "Client " + socket.RemoteEndPoint.ToString().Split(':')[0] + " connected.", ToolTipIcon.None);
        }

        private void nav_animationStarted(Control control)
        {
            SuspendLayout();
        }

        private void nav_animationEnded(Control control)
        {
            ResumeLayout();
        }

        private void navWidth_changed(Control control, int change)
        {
            Width = change;
            hideBorders(0);
        }

        private void nav_click(object sender, EventArgs e)
        {
            if (((FlatButton_WOC)sender).TabIndex == 6)
            {
                IsDrawerExpanded = !_isDrawerExpanded;
                return;
            }
            nav_adapter.showTab(((FlatButton_WOC)sender).TabIndex);
            tabTitle_txt.Text = ((FlatButton_WOC)sender).Text;
        }


        private void exit_btn_Click(object sender, EventArgs e)
        {
            if (!Settings.Default.minimiseOnExit)
                Close();
            else
            {
                WindowState = FormWindowState.Minimized;
                ShowInTaskbar = false;
                tray_ic.Visible = true;
                Hide();
            }
        }

        private void tray_ic_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            this.Show();

            this.TopMost = true;
            this.Focus();
            this.BringToFront();
            this.TopMost = false;
            tray_ic.Visible = false;
        }

        private void OnSizeChanged(object sender, EventArgs e)
        {
            hideBorders(0);
         //   Debug.WriteLine("Width: " + Width + "   Height: " + Height);
        }

        private void tray_ic_menu_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void minimise_btn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void maximise_btn_Click(object sender, EventArgs e)
        {
            this.WindowState = this.WindowState == FormWindowState.Normal ? FormWindowState.Maximized : FormWindowState.Normal;
            maximise_btn.Image = WindowState == FormWindowState.Normal ? Resources.maximise_light_ic : Resources.maximise2_light_ic;
            maximise_btn.ActiveImage = WindowState == FormWindowState.Normal ? Resources.maximise_hover_ic : Resources.maximise2_hover_ic;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            _dataCollector.run = false;
            TCPServer.closeServer();
            Settings.Default.drawerExpanded = _isDrawerExpanded;
            Settings.Default.Save();
        }

        public bool IsDrawerExpanded
        {
            get { return _isDrawerExpanded; }
            set
            {
                drawer_anim.animate(300, !value ? 48 : 200);
                //drawer_anim.changeSize(15, !value ? 48 : 200, nav_panel.Height);
                //drawer_anim.startAnimation();
                _isDrawerExpanded = value;
            }
        }

        public Sender Sender
        {
            get { return _sender; }
        }
    }
}
