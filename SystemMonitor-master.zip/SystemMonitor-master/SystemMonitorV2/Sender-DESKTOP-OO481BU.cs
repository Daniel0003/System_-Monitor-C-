﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Management;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using SystemMonitor;

public class Sender
{

    private static Sender _instance;

    private DataCollector _dataCollector;
    private List<string> _checkedItems = new List<string>();
    private string subDataKey = "clear";
    private volatile bool _run = true;

  
    public Sender(List<string> checkedItems, List<string> ids, DataCollector dataCollector)
    {
        this._dataCollector = dataCollector;
        this._checkedItems = checkedItems;
        // sendOrder(ids);
        //addSubData();
        TCPServer.onConnect += onConnect;
        TCPServer.onDataReceive += onReceive;
        TCPServer.onDisconnect += onDisconect;
        restart();
        Debug.WriteLine("sender");
    }

    public static Sender getInstance(DataCollector dataCollector)
    {
        if (_instance == null)
            _instance = new Sender(Settings.Default.listData.Split(',').ToList(), Settings.Default.ids.Split(',').ToList(), dataCollector);
        return _instance;
    }

    private void onConnect(Socket socket)
    {
            if (!_run)
                restart();
    }

    private void onReceive(string message, byte[] bytes, int count)
    {
        Debug.WriteLine("Received: " + message);
        if (message.Contains(':'))
            Settings.Default.listData = message.Split(':')[1];
        else
        {
            addSubData(message);
            SubDataKey = message;
        }
    }

    private void onDisconect(Socket socket)
    {
            _run = false;
    }

    private void send()
    {
        try
        {
            while (_run)
            {
                if (SubDataKey.Equals("clear"))
                    foreach (string item in _checkedItems)
                        sendMainData(item);
                else
                    sendSubdata(SubDataKey);

                Thread.Sleep(1000);
            }
        }
        catch (Exception ex)
        {
            _run = false;
            Debug.WriteLine(ex.ToString());
        }
    }

    public void restart()
    {
        _run = true;
        new Thread(new ThreadStart(send)).Start();
    }

    private void sendOrder(List<string> list)
    {
        foreach (string listItem in list)
            TCPServer.broadcastln("addIds:" + listItem);
    }

    private void sendMainData(string item)
    {
        if (!item.Contains("Drive"))
            switch (item)
            {
                case "CPU":
                    TCPServer.broadcastln("00CPU-" + _dataCollector.cpuLoad.Last().Value + "%-" + _dataCollector.cpuTemps.Last().Value + "C-" + Utils.StringToHex(Utils.getColorPerTemp((int)_dataCollector.cpuTemps.Last().Value)) + "-" + _dataCollector.cpuLoad.Last().Value);
                    break;
                case "RAM":
                    TCPServer.broadcastln("01RAM-" + Math.Round(_dataCollector.usedRam, 1) + "/" + Math.Round(_dataCollector.totalRam, 1) + "GB---" + _dataCollector.usedRamPrecentage);
                    break;
                case "GPU":
                    TCPServer.broadcastln("0" + (2 + 0) + "GPU-" + Math.Round(Utils.averageValue(_dataCollector.gpuCoreLoad)) + "%-" + Utils.averageValue(_dataCollector.gpuTemps) + "C-" + Utils.StringToHex(Utils.getColorPerTemp(Int32.Parse(Utils.averageValue(_dataCollector.gpuTemps).ToString()))) + "-" + Math.Round(Utils.averageValue(_dataCollector.gpuCoreLoad)));
                    break;
            }
        else
            for (int i = 0; i < _dataCollector.driveData.Count; i++)
                if ("Drive: " + _dataCollector.driveData.ElementAt(i)["Caption"] == item)
                    TCPServer.broadcastln("0" + (6 + i) + "Drive " + _dataCollector.driveData.ElementAt(i)["Caption"].Remove(1) + "-" + _dataCollector.driveData.ElementAt(i)["Used Space"] + "/" + _dataCollector.driveData.ElementAt(i)["Size"] + "GB---" + _dataCollector.driveData.ElementAt(i)["Load"] + "-N");
    }

    private void sendSubdata(string key)
    {
        switch (key)
        {
            case "CPU":
                int coresCount = _dataCollector.cpuLoad.Count;
                for (int i = 0; i < coresCount; i++)
                    TCPServer.broadcastln("2" + i + _dataCollector.cpuLoad.ElementAt(i).Value + "-" + _dataCollector.cpuTemps.ElementAt(i).Value);
                //TCPServer.broadcastln("setSubData:"+coresCount +"-" + Math.Round(dataCollector.cpuLoad.Last().Value) +"%");

                break;
            case "RAM":
                TCPServer.broadcastln("20" + _dataCollector.usedRamPrecentage);
                break;
            case "GPU":
                TCPServer.broadcastln("20" + _dataCollector.gpuCoreLoad.First().Value + "-" + _dataCollector.gpuTemps.First().Value + Environment.NewLine + "21" + _dataCollector.gpuCoreClock.First().Value + "-" + _dataCollector.gpuMemoryClock.First().Value);
                break;
        }
    }

    private void sendStaticSubData(String key)
    {
        switch (key)
        {
            case "CPU":
                int coresCount = _dataCollector.cpuLoad.Count + 1;
                foreach (string value in _dataCollector.cpuData.Values)
                    TCPServer.broadcastln("setSubData:" + coresCount++ + "-" + value);

                break;
            case "RAM":
                break;
            case "GPU":
                break;
        }
    }

    public void addSubData(String key)
    {
        _dataCollector.openComputerThread.Join();
        switch (key)
        {
            case "CPU":
                int coreCount = _dataCollector.cpuLoad.Count;

                for (int i = 0; i < coreCount - 1; i++)
                    TCPServer.broadcastln("11CPU Core #" + i + "-1111FF-FF1111");
                TCPServer.broadcastln("11CPU Total-1111FF-FF1111");
                break;
            case "RAM":
                TCPServer.broadcastln("11Memory Usage (%)-1111FF");
                break;
            case "GPU":
                TCPServer.broadcastln("11GPU-1111FF-FF1111");
                TCPServer.broadcastln("11Clocks-1111FF-11FF11");
                break;
        }


        //  foreach (String key in dataCollector.cpuData.Keys)
        //      cpuMessage += "-" + key + ",false";
        /*
                    TCPServer.broadcastln(cpuMessage);
                    TCPServer.broadcastln("addSubData:Memory Usage (%),true");

                    foreach (ManagementObject queryObj in Win32_VideoController.Get())
                        TCPServer.broadcastln("addSubData:GPU,true-Clocks,true");
                        */
    }

    public void setCheckedItems(List<string> items)
    {
        this._checkedItems = items;
    }

    public string SubDataKey
    {
        get { return subDataKey; }
        set
        {
            subDataKey = value; //sendStaticSubData(value);
        }
    }
}
