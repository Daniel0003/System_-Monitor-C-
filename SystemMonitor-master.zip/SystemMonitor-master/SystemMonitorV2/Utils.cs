﻿using LimitlessUI;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using SystemMonitor;
using SystemMonitor.Fragments;
using SystemMonitor.Fragments;

class Utils
{
    public static readonly string Path = System.IO.Path.GetFullPath("System Monitor.exe");
    public static int FontSize1 = 11;
    public static readonly Color[] LinesColors = {Color.Blue, Color.Red, Color.Green, Color.Orange, Color.Violet, Color.Magenta};

    public static void ChangeTheme(Chart_UC chart, bool light)
    {
        chart.BackColor = light ? Color.White : Theme.Default.background_dark;
        chart.chart.ForeColor = !light ? Color.White : Theme.Default.background_dark;
        chart.legend.TextColor = !light ? Color.White : Theme.Default.background_dark;
        chart.legend.NotifySeriesChanged();
    }

    public static void ChangeTheme(DropDown_WOC dropdown, bool light)
    {
        dropdown.ForeColor = light ? Color.Black : Color.White;
        dropdown.Image = light
            ? SystemMonitor.Properties.Resources.expand_light_ic
            : SystemMonitor.Properties.Resources.expand_dark_ic;
    }

    public static void ChangeTheme(ListView_WOC specsContainer, bool isLight)
    {
        foreach (Control item in specsContainer.Items)
            if (item is Specs_ListChild)
                ((Specs_ListChild) item).IsLightTheme =isLight;
            else if (item is Label)
            {
                item.ForeColor = isLight ? Color.Black : Color.White;
            }
    }

    public static Label GenerateTitleLabel(string title)
    {
        return new Label()
        {
            Text = title,
            Font = new Font("Segoe UI Semibold", 13, FontStyle.Bold, GraphicsUnit.Point, 0)
        };
    }

    public static List<string> ReadFile(string path)
    {
        return File.Exists(Path + "//" + path) ? File.ReadAllLines(Path + "//" + path).ToList() : new List<string>();
    }

    public static string ListToString(List<string> list)
    {
        var s = "";
        foreach (var st in list)
            s += st;
        return s;
    }

    public static int AverageValue(List<float> list)
    {
        int value = 0;
        foreach (int i in list)
            value += i;

        return value / list.Count();
    }

    public static void LoadUserControl(UserControl control, int x, int y, Panel container)
    {
        control.Location = new Point(x, y);
        container.Controls.Add(control);
    }

    public static void PrepareChart(Chart_UC chart, int xLenght)
    {
        chart.Height = Settings.Default.graphHeight;
        chart.chart.ChartLength = xLenght;
        //  chart.chart.LineThikness = Settings.Default.chartBorderWidth;
    }

    public static void AddSerie(SeriesCollection series, string serieName)
    {
        series.Add(serieName);
        series.Last().ChartType = SeriesChartType.Line;
        series.Last().BorderWidth = Settings.Default.chartBorderWidth;
        series.Last().Points.AddY(5);
    }

    public static Color GetColorPerTemp(int temp)
    {
        if (temp > 70)
            return Color.Red;
        else if (temp > 50)
            return Color.Orange;
        else if (temp > 25)
            return Color.LawnGreen;
        else if (temp > 0)
            return Color.Blue;

        return Color.DeepSkyBlue;
    }

    public static string StringToHex(Color c)
    {
        return $"{c.R:X2}{c.G:X2}{c.B:X2}";
    }

    public static void ShowNotification(NotifyIcon ni, string title, string content, ToolTipIcon icon)
    {
        ni.ShowBalloonTip(1500, title, content, icon);
    }

    internal static float AverageValue(SortedDictionary<string, float> dictionary)
    {
        float total = 0;
        foreach (float var in dictionary.Values)
            total += var;
        return total / dictionary.Count;
    }

    internal static float AverageValue(SortedDictionary<string, int> dictionary)
    {
        float total = 0;
        foreach (var var in dictionary.Values)
            total += var;
        return total / dictionary.Count;
    }
}