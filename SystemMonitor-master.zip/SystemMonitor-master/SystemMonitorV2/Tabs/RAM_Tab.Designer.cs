﻿using SystemMonitor.Fragments;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class RAM_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dropDown_WOC1 = new LimitlessUI.DropDown_WOC();
            this.ram_chart = new Chart_UC();
            this.timer_1s = new System.Windows.Forms.Timer(this.components);
            this.specs_lv = new LimitlessUI.ListView_WOC();
            this.ram_data = new System.Windows.Forms.Panel();
            this.totalRam = new System.Windows.Forms.Label();
            this.usedRam = new System.Windows.Forms.Label();
            this.freeRam = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ram_data.SuspendLayout();
            this.SuspendLayout();
            // 
            // dropDown_WOC1
            // 
            this.dropDown_WOC1.AnimationLength = 300;
            this.dropDown_WOC1.ArrowSize = 19;
            this.dropDown_WOC1.Control = this.ram_chart;
            this.dropDown_WOC1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dropDown_WOC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dropDown_WOC1.Image = global::SystemMonitor.Properties.Resources.expand_light_ic;
            this.dropDown_WOC1.Location = new System.Drawing.Point(8, 8);
            this.dropDown_WOC1.Name = "dropDown_WOC1";
            this.dropDown_WOC1.Size = new System.Drawing.Size(773, 23);
            this.dropDown_WOC1.TabIndex = 0;
            this.dropDown_WOC1.Text = "RAM Usage";
            this.dropDown_WOC1.TextOffset = new System.Drawing.Point(-5, 0);
            // 
            // ram_chart
            // 
            this.ram_chart.Dock = System.Windows.Forms.DockStyle.Top;
            this.ram_chart.Location = new System.Drawing.Point(8, 31);
            this.ram_chart.Name = "ram_chart";
            this.ram_chart.Size = new System.Drawing.Size(773, 265);
            this.ram_chart.TabIndex = 8;
            // 
            // timer_1s
            // 
            this.timer_1s.Enabled = true;
            this.timer_1s.Interval = 1000;
            this.timer_1s.Tick += new System.EventHandler(this.Timer_1s_Tick);
            // 
            // specs_lv
            // 
            this.specs_lv.AutoExpand = true;
            this.specs_lv.AutoScroll = true;
            this.specs_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.specs_lv.Location = new System.Drawing.Point(8, 390);
            this.specs_lv.Margin = new System.Windows.Forms.Padding(35, 3, 3, 3);
            this.specs_lv.Name = "specs_lv";
            this.specs_lv.Padding = new System.Windows.Forms.Padding(35, 10, 0, 0);
            this.specs_lv.Size = new System.Drawing.Size(773, 154);
            this.specs_lv.TabIndex = 10;
            this.specs_lv.Text = "listView_WOC1";
            this.specs_lv.Vertical = true;
            // 
            // ram_data
            // 
            this.ram_data.Controls.Add(this.totalRam);
            this.ram_data.Controls.Add(this.usedRam);
            this.ram_data.Controls.Add(this.freeRam);
            this.ram_data.Controls.Add(this.label7);
            this.ram_data.Controls.Add(this.label8);
            this.ram_data.Controls.Add(this.label9);
            this.ram_data.Dock = System.Windows.Forms.DockStyle.Top;
            this.ram_data.Location = new System.Drawing.Point(8, 296);
            this.ram_data.Name = "ram_data";
            this.ram_data.Size = new System.Drawing.Size(773, 94);
            this.ram_data.TabIndex = 9;
            // 
            // totalRam
            // 
            this.totalRam.AutoSize = true;
            this.totalRam.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalRam.Location = new System.Drawing.Point(310, 62);
            this.totalRam.Margin = new System.Windows.Forms.Padding(0);
            this.totalRam.Name = "totalRam";
            this.totalRam.Size = new System.Drawing.Size(47, 20);
            this.totalRam.TabIndex = 29;
            this.totalRam.Text = "7.9GB";
            // 
            // usedRam
            // 
            this.usedRam.AutoSize = true;
            this.usedRam.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usedRam.Location = new System.Drawing.Point(310, 12);
            this.usedRam.Margin = new System.Windows.Forms.Padding(0);
            this.usedRam.Name = "usedRam";
            this.usedRam.Size = new System.Drawing.Size(47, 20);
            this.usedRam.TabIndex = 28;
            this.usedRam.Text = "5.6GB";
            // 
            // freeRam
            // 
            this.freeRam.AutoSize = true;
            this.freeRam.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.freeRam.Location = new System.Drawing.Point(310, 37);
            this.freeRam.Margin = new System.Windows.Forms.Padding(0);
            this.freeRam.Name = "freeRam";
            this.freeRam.Size = new System.Drawing.Size(47, 20);
            this.freeRam.TabIndex = 27;
            this.freeRam.Text = "3.3GB";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(38, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 20);
            this.label7.TabIndex = 26;
            this.label7.Text = "Total RAM:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(38, 12);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 20);
            this.label8.TabIndex = 25;
            this.label8.Text = "Used RAM:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(38, 37);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "Free RAM:";
            // 
            // RAM_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.specs_lv);
            this.Controls.Add(this.ram_data);
            this.Controls.Add(this.ram_chart);
            this.Controls.Add(this.dropDown_WOC1);
            this.Name = "RAM_Tab";
            this.Padding = new System.Windows.Forms.Padding(8, 8, 8, 0);
            this.Size = new System.Drawing.Size(789, 520);
            this.ram_data.ResumeLayout(false);
            this.ram_data.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DropDown_WOC dropDown_WOC1;
        private System.Windows.Forms.Timer timer_1s;
        private Chart_UC ram_chart;
        private ListView_WOC specs_lv;
        private System.Windows.Forms.Panel ram_data;
        private System.Windows.Forms.Label totalRam;
        private System.Windows.Forms.Label usedRam;
        private System.Windows.Forms.Label freeRam;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}
