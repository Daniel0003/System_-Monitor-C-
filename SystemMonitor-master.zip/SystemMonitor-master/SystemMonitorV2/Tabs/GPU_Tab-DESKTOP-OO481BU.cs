﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SystemMonitor.ListItems;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class GPU_Tab : UserControl, Tab_WOC, Theme_interface
    {
        private static GPU_Tab _instance;
        private DataCollector _dataCollector;
        private int _chartLenght;


        public GPU_Tab(DataCollector dataCollector)
        {
            InitializeComponent();
            _dataCollector = dataCollector;

            _chartLenght = Settings.Default.gpuXLenght;
            timer_1s.Start();

            loadSeries();
            loadSpecs();
        }

        public void themeChanged(bool isLight)
        {
            Utils.changeChartTheme(gpu_chart, isLight);
            Utils.changeChartTheme(gpuClocks_chart, isLight);
            Utils.changeSpecsTheme(specs_lv, isLight);

            foreach (VerticalLabels item in gpus_lv.items)
                item.isLightTheme(isLight);
        }

        public void onShowTab()
        {
            Utils.prepareChart(gpu_chart, Settings.Default.gpuXLenght);
            Utils.prepareChart(gpuClocks_chart, Settings.Default.gpuXLenght);
            _chartLenght = Settings.Default.gpuXLenght;
        }

        private void loadSeries()
        {
            gpu_chart.Series.Clear();
            gpuClocks_chart.Series.Clear();

            _dataCollector.dataCollected.WaitOne();
            for (int i = 0; i < _dataCollector.gpuCoreLoad.Count; i++)
            {
                gpus_lv.add(new VerticalLabels("gpu #" + i));

                Utils.addSerie(gpu_chart.Series, "GPU #" + i + " Load");
                Utils.addSerie(gpu_chart.Series, "GPU #" + i + " Temp");
                Utils.addSerie(gpuClocks_chart.Series, "GPU #" + i + " Core clock");
                Utils.addSerie(gpuClocks_chart.Series, "GPU #" + i + " Memory clock");
            }
        }

        private void timer_1s_Tick(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < (gpu_chart.Series.Count / 2); i++)
                {
                    string gpuName = _dataCollector.gpuCoreClock.Keys.ElementAt(i);
                    ((VerticalLabels)gpus_lv.items.ElementAt(i)).setValues(_dataCollector.gpuCoreLoad[gpuName], _dataCollector.gpuTemps[gpuName], _dataCollector.gpuCoreClock[gpuName], _dataCollector.gpuMemoryClock[gpuName]);

                    gpu_chart.Series[i].Points.AddY(_dataCollector.gpuCoreLoad[gpuName]);
                    gpu_chart.Series[i + 1].Points.AddY(_dataCollector.gpuTemps[gpuName]);

                    gpuClocks_chart.Series[i].Points.AddY(_dataCollector.gpuCoreClock[gpuName]);
                    gpuClocks_chart.Series[i + 1].Points.AddY(_dataCollector.gpuMemoryClock[gpuName]);

                    if (gpuClocks_chart.Series[i].Points.Count > _chartLenght || gpu_chart.Series[i].Points.Count > _chartLenght)
                    {
                        gpu_chart.Series[i].Points.RemoveAt(0);
                        gpu_chart.Series[i + 1].Points.RemoveAt(0);

                        gpuClocks_chart.Series[i].Points.RemoveAt(0);
                        gpuClocks_chart.Series[i + 1].Points.RemoveAt(0);
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void loadSpecs()
        {
            _dataCollector.gpuThread.Join();
            foreach (SortedDictionary<string, string> dictionary in _dataCollector.gpuData)
            {
                specs_lv.add(Utils.generateTitleLabel(dictionary["Name"] + ":"));
                foreach (KeyValuePair<string, string> pair in dictionary)
                    if (pair.Key != "Name" && !pair.Key.Contains("Caption") && !pair.Key.Contains("Description"))
                        specs_lv.add(new Specs_ListChild(pair.Key + ":", pair.Value, 12));
            }
        }


        public static GPU_Tab getInstance(DataCollector dataCollector)
        {
            if (_instance == null)
                _instance = new GPU_Tab(dataCollector);
            return _instance;
        }

        private void gpu_chart_Click(object sender, EventArgs e)
        {

        }
    }
}
