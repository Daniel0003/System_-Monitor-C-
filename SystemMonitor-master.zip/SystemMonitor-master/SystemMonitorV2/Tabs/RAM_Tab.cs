﻿using System;
using System.Drawing;
using System.Windows.Forms;
using SystemMonitor.Fragments;
using SystemMonitor.Core;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class RAM_Tab : UserControl, Tab_WOC, IThemeChanger
    {
        private static RAM_Tab _instance;
        private int chartLenght;
        private readonly DataCollector _dataCollector = DataCollector.Instance;
        public static RAM_Tab Instance => _instance ?? (_instance = new RAM_Tab());

        public RAM_Tab()
        {
            InitializeComponent();

            chartLenght = Settings.Default.ramXLenght;

            _dataCollector.OpenComputerThread.Join();

            _dataCollector.RamTask.Wait();
            LoadRamData();
            ram_chart.chart.AddSerie(Color.Blue, "Ram Usage", true);
            ram_chart.legend.NotifySeriesChanged();
        }

        public void ThemeChanged(bool isLight)
        {
            Utils.ChangeTheme(ram_chart, isLight);
            Utils.ChangeTheme(specs_lv, isLight);
            Utils.ChangeTheme(dropDown_WOC1, isLight);

            usedRam.ForeColor = isLight ? Color.Black : Color.White;
            totalRam.ForeColor = isLight ? Color.Black : Color.White;
            freeRam.ForeColor = isLight ? Color.Black : Color.White;
        }


        public void OnShowTab()
        {
            Utils.PrepareChart(ram_chart, Settings.Default.ramXLenght);
            chartLenght = Settings.Default.ramXLenght;
        }

        public void Timer_1s_Tick(object sender, EventArgs e)
        {
            usedRam.Text = Math.Round(_dataCollector.UsedRam, 2) + "GB";
            freeRam.Text = Math.Round(_dataCollector.TotalRam - _dataCollector.UsedRam, 2) + "GB";
            totalRam.Text = Math.Round(_dataCollector.TotalRam, 2) + "GB";
            ram_chart.chart.AddValue(0, _dataCollector.UsedRamPrecentage);
        }

        private void LoadRamData()
        {
            foreach (var ramStick in _dataCollector.RamData)
            foreach (var valuePair in ramStick)
            {
                if (valuePair.Key.Equals("BankLabel"))
                    specs_lv.Add(Utils.GenerateTitleLabel(valuePair.Value + ":"));
                else
                    specs_lv.Add(new Specs_ListChild(valuePair.Key + ":", valuePair.Value, 12));
            }
        }
    }
}