﻿using SystemMonitor.Fragments;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class GPU_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GPU_Tab));
            this.gpu_dd = new LimitlessUI.DropDown_WOC();
            this.timer_1s = new System.Windows.Forms.Timer(this.components);
            this.gpu_chart = new Chart_UC();
            this.clocks_chart = new Chart_UC();
            this.gpuClocks_dd = new LimitlessUI.DropDown_WOC();
            this.specs_lv = new LimitlessUI.ListView_WOC();
            this.gpus_lv = new LimitlessUI.ListView_WOC();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gpus_lv.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpu_dd
            // 
            this.gpu_dd.AnimationLength = 300;
            this.gpu_dd.ArrowSize = 19;
            this.gpu_dd.Control = this.gpu_chart;
            this.gpu_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpu_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.gpu_dd.Image = ((System.Drawing.Image)(resources.GetObject("gpu_dd.Image")));
            this.gpu_dd.Location = new System.Drawing.Point(8, 8);
            this.gpu_dd.Name = "gpu_dd";
            this.gpu_dd.Size = new System.Drawing.Size(1084, 23);
            this.gpu_dd.TabIndex = 11;
            this.gpu_dd.Text = "GPU";
            this.gpu_dd.TextOffset = new System.Drawing.Point(-5, 0);
            // 
            // timer_1s
            // 
            this.timer_1s.Interval = 1000;
            this.timer_1s.Tick += new System.EventHandler(this.timer_1s_Tick);
            // 
            // gpu_chart
            // 
            this.gpu_chart.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpu_chart.Location = new System.Drawing.Point(8, 31);
            this.gpu_chart.Name = "gpu_chart";
            this.gpu_chart.Size = new System.Drawing.Size(1084, 265);
            this.gpu_chart.TabIndex = 17;
            // 
            // clocks_chart
            // 
            this.clocks_chart.Dock = System.Windows.Forms.DockStyle.Top;
            this.clocks_chart.Location = new System.Drawing.Point(8, 319);
            this.clocks_chart.Name = "clocks_chart";
            this.clocks_chart.Size = new System.Drawing.Size(1084, 265);
            this.clocks_chart.TabIndex = 21;
            // 
            // gpuClocks_dd
            // 
            this.gpuClocks_dd.AnimationLength = 300;
            this.gpuClocks_dd.ArrowSize = 19;
            this.gpuClocks_dd.Control = this.clocks_chart;
            this.gpuClocks_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpuClocks_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.gpuClocks_dd.Image = ((System.Drawing.Image)(resources.GetObject("gpuClocks_dd.Image")));
            this.gpuClocks_dd.Location = new System.Drawing.Point(8, 296);
            this.gpuClocks_dd.Name = "gpuClocks_dd";
            this.gpuClocks_dd.Size = new System.Drawing.Size(1084, 23);
            this.gpuClocks_dd.TabIndex = 18;
            this.gpuClocks_dd.Text = "GPU Clocks";
            this.gpuClocks_dd.TextOffset = new System.Drawing.Point(-5, 0);
            // 
            // specs_lv
            // 
            this.specs_lv.AutoExpand = true;
            this.specs_lv.AutoScroll = true;
            this.specs_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.specs_lv.Location = new System.Drawing.Point(8, 714);
            this.specs_lv.Name = "specs_lv";
            this.specs_lv.Padding = new System.Windows.Forms.Padding(27, 10, 0, 0);
            this.specs_lv.Size = new System.Drawing.Size(1084, 309);
            this.specs_lv.TabIndex = 23;
            this.specs_lv.Text = "listView_WOC2";
            this.specs_lv.Vertical = true;
            // 
            // gpus_lv
            // 
            this.gpus_lv.AutoExpand = false;
            this.gpus_lv.AutoScroll = true;
            this.gpus_lv.Controls.Add(this.panel2);
            this.gpus_lv.Controls.Add(this.panel1);
            this.gpus_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpus_lv.Location = new System.Drawing.Point(8, 584);
            this.gpus_lv.Name = "gpus_lv";
            this.gpus_lv.Size = new System.Drawing.Size(1084, 130);
            this.gpus_lv.TabIndex = 22;
            this.gpus_lv.Text = "listView_WOC1";
            this.gpus_lv.Vertical = true;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(145, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(160, 130);
            this.panel2.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(145, 130);
            this.panel1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(28, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Core Clock:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(28, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 30;
            this.label4.Text = "Memory Clock:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(28, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "Temperature:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(28, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 20);
            this.label6.TabIndex = 28;
            this.label6.Text = "GPU Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(28, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "Core Load:";
            // 
            // GPU_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.specs_lv);
            this.Controls.Add(this.gpus_lv);
            this.Controls.Add(this.clocks_chart);
            this.Controls.Add(this.gpuClocks_dd);
            this.Controls.Add(this.gpu_chart);
            this.Controls.Add(this.gpu_dd);
            this.Name = "GPU_Tab";
            this.Padding = new System.Windows.Forms.Padding(8, 8, 8, 0);
            this.Size = new System.Drawing.Size(1100, 520);
            this.gpus_lv.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private DropDown_WOC gpu_dd;
        private System.Windows.Forms.Timer timer_1s;
        private Chart_UC gpu_chart;
        private Chart_UC clocks_chart;
        private DropDown_WOC gpuClocks_dd;
        private ListView_WOC specs_lv;
        private ListView_WOC gpus_lv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}
