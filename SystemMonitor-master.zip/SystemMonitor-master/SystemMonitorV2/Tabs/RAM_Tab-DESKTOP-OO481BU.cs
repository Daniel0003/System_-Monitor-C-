﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemMonitor.ListItems;
using System.Diagnostics;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class RAM_Tab : UserControl, Tab_WOC, Theme_interface
    {
        private static RAM_Tab _instance;
        private int chartLenght;
        private DataCollector dataCollector;

        public RAM_Tab(DataCollector dataCollector)
        {
            InitializeComponent();

            this.dataCollector = dataCollector;
            chartLenght = Settings.Default.ramXLenght;
            ram_chart.Series[0].Points.AddY(0);

            dataCollector.openComputerThread.Join();
            timer_1s.Start();

            dataCollector.ramThread.Join();
            loadRamData();
        }

        public void themeChanged(bool isLight)
        {
            Utils.changeChartTheme(ram_chart, isLight);
            Utils.changeSpecsTheme(specs_lv, isLight);
            usedRam.ForeColor = isLight ? Color.Black : Color.White;
            totalRam.ForeColor = isLight ? Color.Black : Color.White;
            freeRam.ForeColor = isLight ? Color.Black : Color.White;
        }


        public void onShowTab()
        {
            Utils.prepareChart(ram_chart, Settings.Default.ramXLenght);
            chartLenght = Settings.Default.ramXLenght;
        }

        private void timer_1s_Tick(object sender, EventArgs e)
        {
            usedRam.Text = Math.Round(dataCollector.usedRam, 2) + "GB";
            freeRam.Text = Math.Round(dataCollector.totalRam - dataCollector.usedRam, 2) + "GB";
            totalRam.Text = Math.Round(dataCollector.totalRam, 2) + "GB";
            ram_chart.Series[0].Points.AddY(dataCollector.usedRamPrecentage);
            if (ram_chart.Series[0].Points.Count > chartLenght)
                ram_chart.Series[0].Points.RemoveAt(0);
        }

        private void loadRamData()
        {
            foreach (SortedDictionary<string, string> ramStick in dataCollector.ramData)
                foreach (KeyValuePair<string, string> valuePair in ramStick)
                {
                    if (valuePair.Key.Equals("BankLabel"))
                        specs_lv.add(Utils.generateTitleLabel(valuePair.Value + ":"));
                    else
                        specs_lv.add(new Specs_ListChild(valuePair.Key + ":", valuePair.Value, 12));
                }
        }





        public static RAM_Tab getInstance(DataCollector dataCollector)
        {
            if (_instance == null)
                _instance = new RAM_Tab(dataCollector);
            return _instance;
        }

    }
}
