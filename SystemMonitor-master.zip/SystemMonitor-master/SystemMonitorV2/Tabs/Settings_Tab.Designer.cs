﻿using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class Settings_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cpuLenghtLabel = new System.Windows.Forms.Label();
            this.chartHeightLabel = new System.Windows.Forms.Label();
            this.minimise_txt = new System.Windows.Forms.Label();
            this.ramLenghtLabel = new System.Windows.Forms.Label();
            this.gpuLenghtLabel = new System.Windows.Forms.Label();
            this.chartLineThiknessLabel = new System.Windows.Forms.Label();
            this.settingsNames_holder = new System.Windows.Forms.Panel();
            this.theme_txt = new System.Windows.Forms.Label();
            this.settingsValues_holder = new System.Windows.Forms.Panel();
            this.gpuLenghtValue = new System.Windows.Forms.Label();
            this.cpuLenghtValue = new System.Windows.Forms.Label();
            this.ramLenghtValue = new System.Windows.Forms.Label();
            this.chartHeightValue = new System.Windows.Forms.Label();
            this.chartLineThiknessValue = new System.Windows.Forms.Label();
            this.sliders_holder = new System.Windows.Forms.Panel();
            this.theme_sw = new LimitlessUI.Switch_WOC();
            this.minimise_sw = new LimitlessUI.Switch_WOC();
            this.gpuLenghtSlider = new LimitlessUI.Slider_WOC();
            this.ramLenghtSlider = new LimitlessUI.Slider_WOC();
            this.cpuLenghtSlider = new LimitlessUI.Slider_WOC();
            this.chartLineThiknessSlider = new LimitlessUI.Slider_WOC();
            this.chartHeightSlider = new LimitlessUI.Slider_WOC();
            this.settingsNames_holder.SuspendLayout();
            this.settingsValues_holder.SuspendLayout();
            this.sliders_holder.SuspendLayout();
            this.SuspendLayout();
            // 
            // cpuLenghtLabel
            // 
            this.cpuLenghtLabel.AutoSize = true;
            this.cpuLenghtLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpuLenghtLabel.Location = new System.Drawing.Point(0, 61);
            this.cpuLenghtLabel.Name = "cpuLenghtLabel";
            this.cpuLenghtLabel.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.cpuLenghtLabel.Size = new System.Drawing.Size(167, 21);
            this.cpuLenghtLabel.TabIndex = 30;
            this.cpuLenghtLabel.Text = "CPU Chart X Lenght:";
            // 
            // chartHeightLabel
            // 
            this.chartHeightLabel.AutoSize = true;
            this.chartHeightLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chartHeightLabel.Location = new System.Drawing.Point(0, 2);
            this.chartHeightLabel.Name = "chartHeightLabel";
            this.chartHeightLabel.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.chartHeightLabel.Size = new System.Drawing.Size(120, 21);
            this.chartHeightLabel.TabIndex = 29;
            this.chartHeightLabel.Text = "Chart height: ";
            // 
            // minimise_txt
            // 
            this.minimise_txt.AutoSize = true;
            this.minimise_txt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimise_txt.Location = new System.Drawing.Point(0, 152);
            this.minimise_txt.Name = "minimise_txt";
            this.minimise_txt.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.minimise_txt.Size = new System.Drawing.Size(144, 21);
            this.minimise_txt.TabIndex = 34;
            this.minimise_txt.Text = "Minimise on exit:";
            // 
            // ramLenghtLabel
            // 
            this.ramLenghtLabel.AutoSize = true;
            this.ramLenghtLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ramLenghtLabel.Location = new System.Drawing.Point(0, 91);
            this.ramLenghtLabel.Name = "ramLenghtLabel";
            this.ramLenghtLabel.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.ramLenghtLabel.Size = new System.Drawing.Size(171, 21);
            this.ramLenghtLabel.TabIndex = 33;
            this.ramLenghtLabel.Text = "RAM Chart X Lenght:";
            // 
            // gpuLenghtLabel
            // 
            this.gpuLenghtLabel.AutoSize = true;
            this.gpuLenghtLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpuLenghtLabel.Location = new System.Drawing.Point(0, 121);
            this.gpuLenghtLabel.Name = "gpuLenghtLabel";
            this.gpuLenghtLabel.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.gpuLenghtLabel.Size = new System.Drawing.Size(168, 21);
            this.gpuLenghtLabel.TabIndex = 32;
            this.gpuLenghtLabel.Text = "GPU Chart X Lenght:";
            // 
            // chartLineThiknessLabel
            // 
            this.chartLineThiknessLabel.AutoSize = true;
            this.chartLineThiknessLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chartLineThiknessLabel.Location = new System.Drawing.Point(0, 31);
            this.chartLineThiknessLabel.Name = "chartLineThiknessLabel";
            this.chartLineThiknessLabel.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.chartLineThiknessLabel.Size = new System.Drawing.Size(162, 21);
            this.chartLineThiknessLabel.TabIndex = 31;
            this.chartLineThiknessLabel.Text = "Chart line thikness: ";
            // 
            // settingsNames_holder
            // 
            this.settingsNames_holder.Controls.Add(this.theme_txt);
            this.settingsNames_holder.Controls.Add(this.minimise_txt);
            this.settingsNames_holder.Controls.Add(this.ramLenghtLabel);
            this.settingsNames_holder.Controls.Add(this.gpuLenghtLabel);
            this.settingsNames_holder.Controls.Add(this.chartLineThiknessLabel);
            this.settingsNames_holder.Controls.Add(this.cpuLenghtLabel);
            this.settingsNames_holder.Controls.Add(this.chartHeightLabel);
            this.settingsNames_holder.Dock = System.Windows.Forms.DockStyle.Left;
            this.settingsNames_holder.Location = new System.Drawing.Point(0, 0);
            this.settingsNames_holder.Name = "settingsNames_holder";
            this.settingsNames_holder.Padding = new System.Windows.Forms.Padding(0, 17, 0, 0);
            this.settingsNames_holder.Size = new System.Drawing.Size(174, 520);
            this.settingsNames_holder.TabIndex = 32;
            // 
            // theme_txt
            // 
            this.theme_txt.AutoSize = true;
            this.theme_txt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.theme_txt.Location = new System.Drawing.Point(0, 182);
            this.theme_txt.Name = "theme_txt";
            this.theme_txt.Padding = new System.Windows.Forms.Padding(17, 0, 0, 0);
            this.theme_txt.Size = new System.Drawing.Size(114, 21);
            this.theme_txt.TabIndex = 35;
            this.theme_txt.Text = "Dark Theme:";
            // 
            // settingsValues_holder
            // 
            this.settingsValues_holder.Controls.Add(this.gpuLenghtValue);
            this.settingsValues_holder.Controls.Add(this.cpuLenghtValue);
            this.settingsValues_holder.Controls.Add(this.ramLenghtValue);
            this.settingsValues_holder.Controls.Add(this.chartHeightValue);
            this.settingsValues_holder.Controls.Add(this.chartLineThiknessValue);
            this.settingsValues_holder.Dock = System.Windows.Forms.DockStyle.Right;
            this.settingsValues_holder.Location = new System.Drawing.Point(716, 0);
            this.settingsValues_holder.Name = "settingsValues_holder";
            this.settingsValues_holder.Padding = new System.Windows.Forms.Padding(0, 17, 0, 0);
            this.settingsValues_holder.Size = new System.Drawing.Size(73, 520);
            this.settingsValues_holder.TabIndex = 34;
            // 
            // gpuLenghtValue
            // 
            this.gpuLenghtValue.AutoSize = true;
            this.gpuLenghtValue.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpuLenghtValue.Location = new System.Drawing.Point(0, 122);
            this.gpuLenghtValue.Margin = new System.Windows.Forms.Padding(0);
            this.gpuLenghtValue.Name = "gpuLenghtValue";
            this.gpuLenghtValue.Size = new System.Drawing.Size(68, 21);
            this.gpuLenghtValue.TabIndex = 25;
            this.gpuLenghtValue.Text = ":200 Sec";
            // 
            // cpuLenghtValue
            // 
            this.cpuLenghtValue.AutoSize = true;
            this.cpuLenghtValue.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpuLenghtValue.Location = new System.Drawing.Point(0, 62);
            this.cpuLenghtValue.Margin = new System.Windows.Forms.Padding(0);
            this.cpuLenghtValue.Name = "cpuLenghtValue";
            this.cpuLenghtValue.Size = new System.Drawing.Size(68, 21);
            this.cpuLenghtValue.TabIndex = 24;
            this.cpuLenghtValue.Text = ":200 Sec";
            // 
            // ramLenghtValue
            // 
            this.ramLenghtValue.AutoSize = true;
            this.ramLenghtValue.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ramLenghtValue.Location = new System.Drawing.Point(0, 92);
            this.ramLenghtValue.Margin = new System.Windows.Forms.Padding(0);
            this.ramLenghtValue.Name = "ramLenghtValue";
            this.ramLenghtValue.Size = new System.Drawing.Size(68, 21);
            this.ramLenghtValue.TabIndex = 23;
            this.ramLenghtValue.Text = ":200 Sec";
            // 
            // chartHeightValue
            // 
            this.chartHeightValue.AutoSize = true;
            this.chartHeightValue.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chartHeightValue.Location = new System.Drawing.Point(0, 2);
            this.chartHeightValue.Margin = new System.Windows.Forms.Padding(0);
            this.chartHeightValue.Name = "chartHeightValue";
            this.chartHeightValue.Size = new System.Drawing.Size(68, 21);
            this.chartHeightValue.TabIndex = 22;
            this.chartHeightValue.Text = ":200 Sec";
            // 
            // chartLineThiknessValue
            // 
            this.chartLineThiknessValue.AutoSize = true;
            this.chartLineThiknessValue.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chartLineThiknessValue.Location = new System.Drawing.Point(0, 33);
            this.chartLineThiknessValue.Margin = new System.Windows.Forms.Padding(0);
            this.chartLineThiknessValue.Name = "chartLineThiknessValue";
            this.chartLineThiknessValue.Size = new System.Drawing.Size(68, 21);
            this.chartLineThiknessValue.TabIndex = 9;
            this.chartLineThiknessValue.Text = ":200 Sec";
            // 
            // sliders_holder
            // 
            this.sliders_holder.Controls.Add(this.theme_sw);
            this.sliders_holder.Controls.Add(this.minimise_sw);
            this.sliders_holder.Controls.Add(this.gpuLenghtSlider);
            this.sliders_holder.Controls.Add(this.ramLenghtSlider);
            this.sliders_holder.Controls.Add(this.cpuLenghtSlider);
            this.sliders_holder.Controls.Add(this.chartLineThiknessSlider);
            this.sliders_holder.Controls.Add(this.chartHeightSlider);
            this.sliders_holder.Dock = System.Windows.Forms.DockStyle.Top;
            this.sliders_holder.Location = new System.Drawing.Point(174, 0);
            this.sliders_holder.Name = "sliders_holder";
            this.sliders_holder.Size = new System.Drawing.Size(542, 262);
            this.sliders_holder.TabIndex = 35;
            // 
            // theme_sw
            // 
            this.theme_sw.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.theme_sw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.theme_sw.IsOn = true;
            this.theme_sw.Location = new System.Drawing.Point(9, 185);
            this.theme_sw.Name = "theme_sw";
            this.theme_sw.OffColor = System.Drawing.Color.DarkGray;
            this.theme_sw.OffText = "Off";
            this.theme_sw.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.theme_sw.OnText = "On";
            this.theme_sw.Size = new System.Drawing.Size(51, 18);
            this.theme_sw.TabIndex = 36;
            this.theme_sw.Text = "switch_WOC2";
            this.theme_sw.TextEnabled = true;
            this.theme_sw.Click += new System.EventHandler(this.Switch_Click);
            this.theme_sw.DoubleClick += new System.EventHandler(this.Switch_Click);
            // 
            // minimise_sw
            // 
            this.minimise_sw.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.minimise_sw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.minimise_sw.IsOn = false;
            this.minimise_sw.Location = new System.Drawing.Point(9, 156);
            this.minimise_sw.Name = "minimise_sw";
            this.minimise_sw.OffColor = System.Drawing.Color.DarkGray;
            this.minimise_sw.OffText = "Off";
            this.minimise_sw.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.minimise_sw.OnText = "On";
            this.minimise_sw.Size = new System.Drawing.Size(51, 18);
            this.minimise_sw.TabIndex = 35;
            this.minimise_sw.Text = "switch_WOC1";
            this.minimise_sw.TextEnabled = true;
            this.minimise_sw.Click += new System.EventHandler(this.Switch_Click);
            this.minimise_sw.DoubleClick += new System.EventHandler(this.Switch_Click);
            // 
            // gpuLenghtSlider
            // 
            this.gpuLenghtSlider.BackLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.gpuLenghtSlider.BackLineThikness = 7F;
            this.gpuLenghtSlider.CircleSize = 17F;
            this.gpuLenghtSlider.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpuLenghtSlider.DrawCircle = true;
            this.gpuLenghtSlider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.gpuLenghtSlider.FrontLineThikness = 7F;
            this.gpuLenghtSlider.Location = new System.Drawing.Point(0, 120);
            this.gpuLenghtSlider.MaxValue = 3600F;
            this.gpuLenghtSlider.Name = "gpuLenghtSlider";
            this.gpuLenghtSlider.Rounded = false;
            this.gpuLenghtSlider.Size = new System.Drawing.Size(542, 30);
            this.gpuLenghtSlider.TabIndex = 34;
            this.gpuLenghtSlider.Text = "slider_WOC5";
            this.gpuLenghtSlider.Value = 329.7143F;
            this.gpuLenghtSlider.OnValueChanged += new LimitlessUI.Slider_WOC.OnValueChangedEvent(this.settingsSlider_ValueChanged);
            // 
            // ramLenghtSlider
            // 
            this.ramLenghtSlider.BackLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ramLenghtSlider.BackLineThikness = 7F;
            this.ramLenghtSlider.CircleSize = 17F;
            this.ramLenghtSlider.Dock = System.Windows.Forms.DockStyle.Top;
            this.ramLenghtSlider.DrawCircle = true;
            this.ramLenghtSlider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.ramLenghtSlider.FrontLineThikness = 7F;
            this.ramLenghtSlider.Location = new System.Drawing.Point(0, 90);
            this.ramLenghtSlider.MaxValue = 3600F;
            this.ramLenghtSlider.Name = "ramLenghtSlider";
            this.ramLenghtSlider.Rounded = false;
            this.ramLenghtSlider.Size = new System.Drawing.Size(542, 30);
            this.ramLenghtSlider.TabIndex = 33;
            this.ramLenghtSlider.Text = "slider_WOC4";
            this.ramLenghtSlider.Value = 329.7143F;
            this.ramLenghtSlider.OnValueChanged += new LimitlessUI.Slider_WOC.OnValueChangedEvent(this.settingsSlider_ValueChanged);
            // 
            // cpuLenghtSlider
            // 
            this.cpuLenghtSlider.BackLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.cpuLenghtSlider.BackLineThikness = 7F;
            this.cpuLenghtSlider.CircleSize = 17F;
            this.cpuLenghtSlider.Dock = System.Windows.Forms.DockStyle.Top;
            this.cpuLenghtSlider.DrawCircle = true;
            this.cpuLenghtSlider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.cpuLenghtSlider.FrontLineThikness = 7F;
            this.cpuLenghtSlider.Location = new System.Drawing.Point(0, 60);
            this.cpuLenghtSlider.MaxValue = 3600F;
            this.cpuLenghtSlider.Name = "cpuLenghtSlider";
            this.cpuLenghtSlider.Rounded = false;
            this.cpuLenghtSlider.Size = new System.Drawing.Size(542, 30);
            this.cpuLenghtSlider.TabIndex = 32;
            this.cpuLenghtSlider.Text = "slider_WOC3";
            this.cpuLenghtSlider.Value = 329.7143F;
            this.cpuLenghtSlider.OnValueChanged += new LimitlessUI.Slider_WOC.OnValueChangedEvent(this.settingsSlider_ValueChanged);
            // 
            // chartLineThiknessSlider
            // 
            this.chartLineThiknessSlider.BackLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.chartLineThiknessSlider.BackLineThikness = 7F;
            this.chartLineThiknessSlider.CircleSize = 17F;
            this.chartLineThiknessSlider.Dock = System.Windows.Forms.DockStyle.Top;
            this.chartLineThiknessSlider.DrawCircle = true;
            this.chartLineThiknessSlider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.chartLineThiknessSlider.FrontLineThikness = 7F;
            this.chartLineThiknessSlider.Location = new System.Drawing.Point(0, 30);
            this.chartLineThiknessSlider.MaxValue = 10F;
            this.chartLineThiknessSlider.Name = "chartLineThiknessSlider";
            this.chartLineThiknessSlider.Rounded = false;
            this.chartLineThiknessSlider.Size = new System.Drawing.Size(542, 30);
            this.chartLineThiknessSlider.TabIndex = 31;
            this.chartLineThiknessSlider.Text = "slider_WOC2";
            this.chartLineThiknessSlider.Value = 3.297143F;
            this.chartLineThiknessSlider.OnValueChanged += new LimitlessUI.Slider_WOC.OnValueChangedEvent(this.settingsSlider_ValueChanged);
            // 
            // chartHeightSlider
            // 
            this.chartHeightSlider.BackLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.chartHeightSlider.BackLineThikness = 7F;
            this.chartHeightSlider.CircleSize = 17F;
            this.chartHeightSlider.Dock = System.Windows.Forms.DockStyle.Top;
            this.chartHeightSlider.DrawCircle = true;
            this.chartHeightSlider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.chartHeightSlider.FrontLineThikness = 7F;
            this.chartHeightSlider.Location = new System.Drawing.Point(0, 0);
            this.chartHeightSlider.MaxValue = 1000F;
            this.chartHeightSlider.Name = "chartHeightSlider";
            this.chartHeightSlider.Rounded = false;
            this.chartHeightSlider.Size = new System.Drawing.Size(542, 30);
            this.chartHeightSlider.TabIndex = 30;
            this.chartHeightSlider.Text = "slider_WOC1";
            this.chartHeightSlider.Value = 329.7143F;
            this.chartHeightSlider.OnValueChanged += new LimitlessUI.Slider_WOC.OnValueChangedEvent(this.settingsSlider_ValueChanged);
            // 
            // Settings_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.sliders_holder);
            this.Controls.Add(this.settingsValues_holder);
            this.Controls.Add(this.settingsNames_holder);
            this.Name = "Settings_Tab";
            this.Size = new System.Drawing.Size(789, 520);
            this.SizeChanged += new System.EventHandler(this.OnSizeChanged);
            this.settingsNames_holder.ResumeLayout(false);
            this.settingsNames_holder.PerformLayout();
            this.settingsValues_holder.ResumeLayout(false);
            this.settingsValues_holder.PerformLayout();
            this.sliders_holder.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label cpuLenghtLabel;
        private System.Windows.Forms.Label chartHeightLabel;
        private System.Windows.Forms.Label minimise_txt;
        private System.Windows.Forms.Label ramLenghtLabel;
        private System.Windows.Forms.Label gpuLenghtLabel;
        private System.Windows.Forms.Label chartLineThiknessLabel;
        private System.Windows.Forms.Panel settingsNames_holder;
        private System.Windows.Forms.Panel settingsValues_holder;
        private System.Windows.Forms.Label gpuLenghtValue;
        private System.Windows.Forms.Label cpuLenghtValue;
        private System.Windows.Forms.Label ramLenghtValue;
        private System.Windows.Forms.Label chartHeightValue;
        private System.Windows.Forms.Label chartLineThiknessValue;
        private System.Windows.Forms.Panel sliders_holder;
        private Switch_WOC minimise_sw;
        private Slider_WOC gpuLenghtSlider;
        private Slider_WOC ramLenghtSlider;
        private Slider_WOC cpuLenghtSlider;
        private Slider_WOC chartLineThiknessSlider;
        private Slider_WOC chartHeightSlider;
        private System.Windows.Forms.Label theme_txt;
        private Switch_WOC theme_sw;
    }
}
