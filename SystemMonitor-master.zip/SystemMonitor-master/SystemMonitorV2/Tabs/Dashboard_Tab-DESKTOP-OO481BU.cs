﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using SystemMonitor.ListItems;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class Dashboard_Tab : UserControl, Theme_interface
    {
        private static Dashboard_Tab _instance;
        private DataCollector dataCollector;

        public Dashboard_Tab(DataCollector collector)
        {
            this.dataCollector = collector;
            _instance = this;
            InitializeComponent();
            timer_1s.Start();
            timer_5s.Start();
        }

        public void themeChanged(bool isLight)
        {
            foreach (ArchProgressBar_WOC progress in archProgress_panel.Controls)
            {
                progress.Text1Color = isLight ? Color.Black : Color.White;
                progress.Text2Color = isLight ? Color.Black : Color.White;
                progress.Text3Color = isLight ? Color.Black : Color.White;
                progress.ProgressBackColor = isLight ? Theme.Default.controlsBG_light : Theme.Default.controlsBG_dark;
            }
            foreach (Drives_listChild drive_lc in drives_lv.items)
                drive_lc.changeTheme(isLight);
        }

        private void timer_1s_Tick(object sender, EventArgs e)
        {
            try
            {
                dataCollector.cpuThread.Join();
                cpu_progress.updateData(Math.Round(dataCollector.cpuLoad.First().Value) + "%", dataCollector.cpuTemps.Last().Value + "°C", ((int)dataCollector.cpuLoad.First().Value), Utils.getColorPerTemp(dataCollector.cpuTemps.Last().Value));
                ram_progress.updateData(Math.Round(dataCollector.usedRam, 2) + "/" + Math.Round(dataCollector.totalRam, 2) + "GB", dataCollector.usedRamPrecentage);
                if (dataCollector.gpuCoreLoad.Count != 0)
                    gpu_progress.updateData((int)dataCollector.gpuCoreLoad.First().Value + "%", dataCollector.gpuTemps.First().Value + "°C", ((int)dataCollector.gpuCoreLoad.First().Value), Utils.getColorPerTemp(dataCollector.gpuTemps.First().Value));
            }
            catch (Exception ex)
            {
                //Debug.WriteLine(ex.ToString());
            }
        }


        private void timer_5s_Tick(object sender, EventArgs e)
        {
            try
            {
                if (drives_lv.items.Count != dataCollector.driveData.Count || drives_lv.items.Count == 0)
                {
                    drives_lv.clear();
                    foreach (SortedDictionary<string, string> drive in dataCollector.driveData)
                    {
                        drives_lv.add(new Drives_listChild(drive["Caption"],
                                 Int16.Parse(drive["Load"]),
                                 drive["Used Space"] + "/" +
                                 drive["Size"]));
                        if (!Settings.Default.lightTheme)
                            ((Drives_listChild)drives_lv.items.Last()).changeTheme(Settings.Default.lightTheme);
                        if ((drive["Caption"] + "\\").Equals(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System))))
                        {
                            drive_progress.updateData(dataCollector.driveData.First()["Used Space"] + "/" + dataCollector.driveData.First()["Size"], Int32.Parse(dataCollector.driveData.ElementAt(0)["Load"]));
                            //       drive_progress.updateText(
                            //        dataCollector.driveData.First()["Used Space"] + "/" + dataCollector.driveData.First()["Size"],
                            //       "");
                            //        drive_progress.Value = Int32.Parse(dataCollector.driveData.ElementAt(0)["Load"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
        }

        private void progressBar_Click(object sender, EventArgs e)
        {
            //   mainForm.loadTab(((ArchProgressBar_WOC)sender).TabIndex + 2);
        }

        public static Dashboard_Tab getInstance(DataCollector dataCollector)
        {
            if (_instance == null)
                _instance = new Dashboard_Tab(dataCollector);
            return _instance;
        }

        private void OnSizeChanged(object sender, EventArgs e)
        {
            SuspendLayout();
            cpu_progress.Invalidate();
            ram_progress.Invalidate();
            gpu_progress.Invalidate();
            drive_progress.Invalidate();

            foreach (Drives_listChild drive in drives_lv.items)
                drive.redraw();
            ResumeLayout();
        }
    }
}
