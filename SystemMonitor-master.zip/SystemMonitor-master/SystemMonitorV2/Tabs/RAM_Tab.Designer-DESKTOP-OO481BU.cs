﻿using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class RAM_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.dropDown_WOC1 = new DropDown_WOC();
            this.ram_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ram_data = new System.Windows.Forms.Panel();
            this.totalRam = new System.Windows.Forms.Label();
            this.usedRam = new System.Windows.Forms.Label();
            this.freeRam = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.specs_lv = new ListView_WOC();
            this.timer_1s = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ram_chart)).BeginInit();
            this.ram_data.SuspendLayout();
            this.SuspendLayout();
            // 
            // dropDown_WOC1
            // 
            this.dropDown_WOC1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dropDown_WOC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dropDown_WOC1.Location = new System.Drawing.Point(8, 8);
            this.dropDown_WOC1.Name = "dropDown_WOC1";
            this.dropDown_WOC1.Size = new System.Drawing.Size(824, 23);
            this.dropDown_WOC1.TabIndex = 0;
            this.dropDown_WOC1.Text = "RAM Usage";
            // 
            // ram_chart
            // 
            this.ram_chart.BorderlineColor = System.Drawing.Color.Maroon;
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.IsMarginVisible = false;
            chartArea1.AxisX.LabelAutoFitMaxFontSize = 5;
            chartArea1.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorGrid.LineWidth = 0;
            chartArea1.AxisX.MajorTickMark.Enabled = false;
            chartArea1.AxisX.Maximum = 300D;
            chartArea1.AxisX.Minimum = 3D;
            chartArea1.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisX2.IsMarginVisible = false;
            chartArea1.AxisX2.MajorGrid.Enabled = false;
            chartArea1.AxisY.Interval = 50D;
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.AxisY.IsMarginVisible = false;
            chartArea1.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.MajorGrid.LineWidth = 0;
            chartArea1.AxisY.MajorTickMark.Enabled = false;
            chartArea1.AxisY.Maximum = 100D;
            chartArea1.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            chartArea1.InnerPlotPosition.Auto = false;
            chartArea1.InnerPlotPosition.Height = 87.96179F;
            chartArea1.InnerPlotPosition.Width = 93.32934F;
            chartArea1.InnerPlotPosition.X = 4F;
            chartArea1.InnerPlotPosition.Y = 6F;
            chartArea1.Name = "ChartArea1";
            this.ram_chart.ChartAreas.Add(chartArea1);
            this.ram_chart.Dock = System.Windows.Forms.DockStyle.Top;
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend1.Name = "Legend1";
            this.ram_chart.Legends.Add(legend1);
            this.ram_chart.Location = new System.Drawing.Point(8, 31);
            this.ram_chart.Margin = new System.Windows.Forms.Padding(0);
            this.ram_chart.Name = "ram_chart";
            series1.BorderWidth = 3;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Used RAM";
            series1.ShadowColor = System.Drawing.Color.Empty;
            this.ram_chart.Series.Add(series1);
            this.ram_chart.Size = new System.Drawing.Size(824, 200);
            this.ram_chart.TabIndex = 13;
            this.ram_chart.Text = "load_chart";
            // 
            // ram_data
            // 
            this.ram_data.Controls.Add(this.totalRam);
            this.ram_data.Controls.Add(this.usedRam);
            this.ram_data.Controls.Add(this.freeRam);
            this.ram_data.Controls.Add(this.label7);
            this.ram_data.Controls.Add(this.label8);
            this.ram_data.Controls.Add(this.label9);
            this.ram_data.Dock = System.Windows.Forms.DockStyle.Top;
            this.ram_data.Location = new System.Drawing.Point(8, 231);
            this.ram_data.Name = "ram_data";
            this.ram_data.Size = new System.Drawing.Size(824, 94);
            this.ram_data.TabIndex = 3;
            // 
            // totalRam
            // 
            this.totalRam.AutoSize = true;
            this.totalRam.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalRam.Location = new System.Drawing.Point(310, 62);
            this.totalRam.Margin = new System.Windows.Forms.Padding(0);
            this.totalRam.Name = "totalRam";
            this.totalRam.Size = new System.Drawing.Size(47, 20);
            this.totalRam.TabIndex = 29;
            this.totalRam.Text = "7.9GB";
            // 
            // usedRam
            // 
            this.usedRam.AutoSize = true;
            this.usedRam.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usedRam.Location = new System.Drawing.Point(310, 12);
            this.usedRam.Margin = new System.Windows.Forms.Padding(0);
            this.usedRam.Name = "usedRam";
            this.usedRam.Size = new System.Drawing.Size(47, 20);
            this.usedRam.TabIndex = 28;
            this.usedRam.Text = "5.6GB";
            // 
            // freeRam
            // 
            this.freeRam.AutoSize = true;
            this.freeRam.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.freeRam.Location = new System.Drawing.Point(310, 37);
            this.freeRam.Margin = new System.Windows.Forms.Padding(0);
            this.freeRam.Name = "freeRam";
            this.freeRam.Size = new System.Drawing.Size(47, 20);
            this.freeRam.TabIndex = 27;
            this.freeRam.Text = "3.3GB";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(38, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 20);
            this.label7.TabIndex = 26;
            this.label7.Text = "Total RAM:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(38, 12);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 20);
            this.label8.TabIndex = 25;
            this.label8.Text = "Used RAM:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(38, 37);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "Free RAM:";
            // 
            // specs_lv
            // 
            this.specs_lv.AutoExpand = true;
            this.specs_lv.AutoScroll = true;
            this.specs_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.specs_lv.Location = new System.Drawing.Point(8, 325);
            this.specs_lv.Margin = new System.Windows.Forms.Padding(35, 3, 3, 3);
            this.specs_lv.Name = "specs_lv";
            this.specs_lv.Padding = new System.Windows.Forms.Padding(35, 10, 0, 0);
            this.specs_lv.Size = new System.Drawing.Size(824, 154);
            this.specs_lv.TabIndex = 4;
            this.specs_lv.Text = "listView_WOC1";
            this.specs_lv.Vertical = true;
            // 
            // timer_1s
            // 
            this.timer_1s.Interval = 1000;
            this.timer_1s.Tick += new System.EventHandler(this.timer_1s_Tick);
            // 
            // RAM_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.specs_lv);
            this.Controls.Add(this.ram_data);
            this.Controls.Add(this.ram_chart);
            this.Controls.Add(this.dropDown_WOC1);
            this.Name = "RAM_Tab";
            this.Padding = new System.Windows.Forms.Padding(8, 8, 8, 0);
            this.Size = new System.Drawing.Size(840, 520);
            ((System.ComponentModel.ISupportInitialize)(this.ram_chart)).EndInit();
            this.ram_data.ResumeLayout(false);
            this.ram_data.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DropDown_WOC dropDown_WOC1;
        private System.Windows.Forms.Panel ram_data;
        private System.Windows.Forms.Label totalRam;
        private System.Windows.Forms.Label usedRam;
        private System.Windows.Forms.Label freeRam;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private ListView_WOC specs_lv;
        private System.Windows.Forms.Timer timer_1s;
        private System.Windows.Forms.DataVisualization.Charting.Chart ram_chart;
    }
}
