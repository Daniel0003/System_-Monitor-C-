﻿using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class CPU_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.temp_dd = new DropDown_WOC();
            this.load_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.load_dd = new DropDown_WOC();
            this.cores_lv = new ListView_WOC();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.specs_lv = new ListView_WOC();
            this.timer_1s = new System.Windows.Forms.Timer(this.components);
            this.temps_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.animator_WOC1 = new Animator_WOC();
            ((System.ComponentModel.ISupportInitialize)(this.load_chart)).BeginInit();
            this.cores_lv.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.temps_chart)).BeginInit();
            this.SuspendLayout();
            // 
            // temp_dd
            // 
            this.temp_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.temp_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.temp_dd.Location = new System.Drawing.Point(8, 231);
            this.temp_dd.Name = "temp_dd";
            this.temp_dd.Size = new System.Drawing.Size(654, 23);
            this.temp_dd.TabIndex = 13;
            this.temp_dd.Text = "CPU Temp";
            // 
            // load_chart
            // 
            this.load_chart.BorderlineColor = System.Drawing.Color.Maroon;
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.IsMarginVisible = false;
            chartArea1.AxisX.LabelAutoFitMaxFontSize = 5;
            chartArea1.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorGrid.LineWidth = 0;
            chartArea1.AxisX.MajorTickMark.Enabled = false;
            chartArea1.AxisX.Maximum = 300D;
            chartArea1.AxisX.Minimum = 3D;
            chartArea1.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisX2.IsMarginVisible = false;
            chartArea1.AxisX2.MajorGrid.Enabled = false;
            chartArea1.AxisY.Interval = 50D;
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.AxisY.IsMarginVisible = false;
            chartArea1.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.MajorGrid.LineWidth = 0;
            chartArea1.AxisY.MajorTickMark.Enabled = false;
            chartArea1.AxisY.Maximum = 100D;
            chartArea1.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            chartArea1.InnerPlotPosition.Auto = false;
            chartArea1.InnerPlotPosition.Height = 87.96179F;
            chartArea1.InnerPlotPosition.Width = 93.32934F;
            chartArea1.InnerPlotPosition.X = 4F;
            chartArea1.InnerPlotPosition.Y = 6F;
            chartArea1.Name = "ChartArea1";
            this.load_chart.ChartAreas.Add(chartArea1);
            this.load_chart.Dock = System.Windows.Forms.DockStyle.Top;
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend1.Name = "Legend1";
            this.load_chart.Legends.Add(legend1);
            this.load_chart.Location = new System.Drawing.Point(8, 31);
            this.load_chart.Margin = new System.Windows.Forms.Padding(0);
            this.load_chart.Name = "load_chart";
            series1.BorderWidth = 3;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Used RAM";
            series1.ShadowColor = System.Drawing.Color.Empty;
            this.load_chart.Series.Add(series1);
            this.load_chart.Size = new System.Drawing.Size(654, 200);
            this.load_chart.TabIndex = 12;
            this.load_chart.Text = "load_chart";
            // 
            // load_dd
            // 

            this.load_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.load_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.load_dd.Location = new System.Drawing.Point(8, 8);
            this.load_dd.Name = "load_dd";
            this.load_dd.Size = new System.Drawing.Size(654, 23);
            this.load_dd.TabIndex = 11;
            this.load_dd.Text = "CPU Load";
            // 
            // cores_lv
            // 
            this.cores_lv.AutoExpand = false;
            this.cores_lv.AutoScroll = true;
            this.cores_lv.Controls.Add(this.panel1);
            this.cores_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.cores_lv.Location = new System.Drawing.Point(8, 454);
            this.cores_lv.Name = "cores_lv";
            this.cores_lv.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.cores_lv.Size = new System.Drawing.Size(654, 100);
            this.cores_lv.TabIndex = 15;
            this.cores_lv.Text = "listView_WOC1";
            this.cores_lv.Vertical = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(120, 90);
            this.panel1.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(35, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Temp:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(35, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Load:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(35, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Core:";
            // 
            // specs_lv
            // 
            this.specs_lv.AutoExpand = true;
            this.specs_lv.AutoScroll = true;
            this.specs_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.specs_lv.Location = new System.Drawing.Point(8, 554);
            this.specs_lv.Name = "specs_lv";
            this.specs_lv.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.specs_lv.Size = new System.Drawing.Size(654, 309);
            this.specs_lv.TabIndex = 16;
            this.specs_lv.Text = "listView_WOC2";
            this.specs_lv.Vertical = true;
            // 
            // timer_1s
            // 
            this.timer_1s.Interval = 1000;
            this.timer_1s.Tick += new System.EventHandler(this.timer_1s_Tick);
            // 
            // temps_chart
            // 
            this.temps_chart.BorderlineColor = System.Drawing.Color.Maroon;
            chartArea2.AxisX.IsLabelAutoFit = false;
            chartArea2.AxisX.IsMarginVisible = false;
            chartArea2.AxisX.LabelAutoFitMaxFontSize = 5;
            chartArea2.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea2.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea2.AxisX.MajorGrid.LineWidth = 0;
            chartArea2.AxisX.MajorTickMark.Enabled = false;
            chartArea2.AxisX.Maximum = 300D;
            chartArea2.AxisX.Minimum = 3D;
            chartArea2.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.AxisX2.IsMarginVisible = false;
            chartArea2.AxisX2.MajorGrid.Enabled = false;
            chartArea2.AxisY.Interval = 50D;
            chartArea2.AxisY.IsLabelAutoFit = false;
            chartArea2.AxisY.IsMarginVisible = false;
            chartArea2.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisY.MajorGrid.LineWidth = 0;
            chartArea2.AxisY.MajorTickMark.Enabled = false;
            chartArea2.AxisY.Maximum = 100D;
            chartArea2.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            chartArea2.InnerPlotPosition.Auto = false;
            chartArea2.InnerPlotPosition.Height = 87.96179F;
            chartArea2.InnerPlotPosition.Width = 93.32934F;
            chartArea2.InnerPlotPosition.X = 4F;
            chartArea2.InnerPlotPosition.Y = 6F;
            chartArea2.Name = "ChartArea1";
            this.temps_chart.ChartAreas.Add(chartArea2);
            this.temps_chart.Dock = System.Windows.Forms.DockStyle.Top;
            legend2.BackColor = System.Drawing.Color.Transparent;
            legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend2.Name = "Legend1";
            this.temps_chart.Legends.Add(legend2);
            this.temps_chart.Location = new System.Drawing.Point(8, 254);
            this.temps_chart.Margin = new System.Windows.Forms.Padding(0);
            this.temps_chart.Name = "temps_chart";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Used RAM";
            series2.ShadowColor = System.Drawing.Color.Empty;
            this.temps_chart.Series.Add(series2);
            this.temps_chart.Size = new System.Drawing.Size(654, 200);
            this.temps_chart.TabIndex = 18;
            this.temps_chart.Text = "temps_chart";
            // 
            // animator_WOC1
            // 
            this.animator_WOC1.Controls = null;
            // 
            // CPU_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.specs_lv);
            this.Controls.Add(this.cores_lv);
            this.Controls.Add(this.temps_chart);
            this.Controls.Add(this.temp_dd);
            this.Controls.Add(this.load_chart);
            this.Controls.Add(this.load_dd);
            this.Name = "CPU_Tab";
            this.Padding = new System.Windows.Forms.Padding(8, 8, 8, 0);
            this.Size = new System.Drawing.Size(670, 520);
            ((System.ComponentModel.ISupportInitialize)(this.load_chart)).EndInit();
            this.cores_lv.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.temps_chart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private DropDown_WOC temp_dd;
        private System.Windows.Forms.DataVisualization.Charting.Chart load_chart;
        private DropDown_WOC load_dd;
        private ListView_WOC cores_lv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private ListView_WOC specs_lv;
        private System.Windows.Forms.Timer timer_1s;
        private System.Windows.Forms.DataVisualization.Charting.Chart temps_chart;
        private Animator_WOC animator_WOC1;
    }
}
