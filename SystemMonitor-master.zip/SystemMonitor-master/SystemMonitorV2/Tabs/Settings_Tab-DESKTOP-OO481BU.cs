﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class Settings_Tab : UserControl, Theme_interface
    {
        private static Settings_Tab _instance;
        private MainForm form;
        public Settings_Tab(MainForm form)
        {
            InitializeComponent();
            this.form = form;

            chartHeightSlider.Value = Settings.Default.graphHeight;
            chartLineThiknessSlider.Value = Settings.Default.chartBorderWidth;
            cpuLenghtSlider.Value = Settings.Default.cpuXLenght;
            ramLenghtSlider.Value = Settings.Default.ramXLenght;
            gpuLenghtSlider.Value = Settings.Default.gpuXLenght;

            chartHeightValue.Text = Settings.Default.graphHeight.ToString() + " px";
            chartLineThiknessValue.Text = Settings.Default.chartBorderWidth.ToString() + " Px";
            cpuLenghtValue.Text = Settings.Default.cpuXLenght.ToString() + "sec";
            ramLenghtValue.Text = Settings.Default.ramXLenght.ToString() + "sec";
            gpuLenghtValue.Text = Settings.Default.gpuXLenght.ToString() + "sec";

            minimise_sw.IsOn = Settings.Default.minimiseOnExit;
            theme_sw.IsOn = !Settings.Default.lightTheme;
        }

        public void themeChanged(bool isLight)
        {
            foreach (Label label in settingsNames_holder.Controls)
                label.ForeColor = isLight ? Color.Black : Color.White;
            foreach (Label label in settingsValues_holder.Controls)
                label.ForeColor = isLight ? Color.Black : Color.White;
        }

        private void OnSizeChanged(object sender, EventArgs e)
        {
            foreach (Control control in sliders_holder.Controls)
                control.Invalidate();
        }

        private void settingsSlider_ValueChanged(Slider_WOC slider, float val)
        {
            int value = (int)val;
            switch (slider.TabIndex)
            {
                case 30:
                    Settings.Default.graphHeight = value;
                    chartHeightValue.Text = value + "px";
                    break;
                case 31:
                    Settings.Default.chartBorderWidth = value;
                    chartLineThiknessValue.Text = value + "px";
                    break;
                case 32:
                    Settings.Default.cpuXLenght = value;
                    cpuLenghtValue.Text = value + "Sec.";
                    break;
                case 33:
                    Settings.Default.ramXLenght = value;
                    ramLenghtValue.Text = value + "Sec.";
                    break;
                case 34:
                    Settings.Default.gpuXLenght = value;
                    gpuLenghtValue.Text = value + "Sec.";
                    break;
            }
            Settings.Default.Save();
        }

        private void switch_Click(object sender, EventArgs e)
        {
            Switch_WOC settings_sw = ((Switch_WOC)sender);
            if (settings_sw.TabIndex == 35)
            {
                Settings.Default.minimiseOnExit = settings_sw.IsOn;
                Settings.Default.Save();
            }
            else
            {
                Settings.Default.lightTheme = !settings_sw.IsOn;
                Settings.Default.Save();
                form.setTheme(!settings_sw.IsOn);
            }
        }

        public static Settings_Tab getInstance(MainForm form)
        {
            if (_instance == null)
                _instance = new Settings_Tab(form);
            return _instance;
        }
    }
}
