﻿using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class Dashboard_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Timer_1s = new System.Windows.Forms.Timer(this.components);
            this.archProgress_panel = new System.Windows.Forms.TableLayoutPanel();
            this.gpu_progress = new LimitlessUI.ArchProgressBar_WOC();
            this.drive_progress = new LimitlessUI.ArchProgressBar_WOC();
            this.cpu_progress = new LimitlessUI.ArchProgressBar_WOC();
            this.ram_progress = new LimitlessUI.ArchProgressBar_WOC();
            this.Timer_5s = new System.Windows.Forms.Timer(this.components);
            this.drives_lv = new LimitlessUI.ListView_WOC();
            this.archProgress_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Timer_1s
            // 
            this.Timer_1s.Enabled = true;
            this.Timer_1s.Interval = 1000;
            this.Timer_1s.Tick += new System.EventHandler(this.Timer_1s_Tick);
            // 
            // archProgress_panel
            // 
            this.archProgress_panel.ColumnCount = 4;
            this.archProgress_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.archProgress_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.archProgress_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.archProgress_panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.archProgress_panel.Controls.Add(this.gpu_progress, 0, 0);
            this.archProgress_panel.Controls.Add(this.drive_progress, 0, 0);
            this.archProgress_panel.Controls.Add(this.cpu_progress, 0, 0);
            this.archProgress_panel.Controls.Add(this.ram_progress, 0, 0);
            this.archProgress_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.archProgress_panel.Location = new System.Drawing.Point(0, 0);
            this.archProgress_panel.Name = "archProgress_panel";
            this.archProgress_panel.RowCount = 1;
            this.archProgress_panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.archProgress_panel.Size = new System.Drawing.Size(840, 227);
            this.archProgress_panel.TabIndex = 0;
            // 
            // gpu_progress
            // 
            this.gpu_progress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gpu_progress.Angle = 360;
            this.gpu_progress.BackLineThikness = 12F;
            this.gpu_progress.Font1 = new System.Drawing.Font("Segoe UI", 13F);
            this.gpu_progress.Font2 = new System.Drawing.Font("Segoe UI", 13F);
            this.gpu_progress.Font3 = new System.Drawing.Font("Segoe UI", 13F);
            this.gpu_progress.IgnoreHeight = false;
            this.gpu_progress.Location = new System.Drawing.Point(423, 8);
            this.gpu_progress.Name = "gpu_progress";
            this.gpu_progress.Offset = new System.Drawing.Point(0, 0);
            this.gpu_progress.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(223)))), ((int)(((byte)(223)))));
            this.gpu_progress.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.gpu_progress.ProgressLineThikness = 12F;
            this.gpu_progress.Size = new System.Drawing.Size(204, 210);
            this.gpu_progress.Style = LimitlessUI.ArchProgressBar_WOC.StyleEnum.Style3;
            this.gpu_progress.TabIndex = 3;
            this.gpu_progress.Text = "archProgressBar_WOC4";
            this.gpu_progress.Text1 = "GPU";
            this.gpu_progress.Text1Color = System.Drawing.SystemColors.ControlText;
            this.gpu_progress.Text2 = "99%";
            this.gpu_progress.Text2Color = System.Drawing.SystemColors.ControlText;
            this.gpu_progress.Text3 = "55C";
            this.gpu_progress.Text3Color = System.Drawing.SystemColors.ControlText;
            this.gpu_progress.Value = 50F;
            this.gpu_progress.Click += new System.EventHandler(this.ProgressBar_Click);
            // 
            // drive_progress
            // 
            this.drive_progress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.drive_progress.Angle = 360;
            this.drive_progress.BackLineThikness = 12F;
            this.drive_progress.Font1 = new System.Drawing.Font("Segoe UI", 13F);
            this.drive_progress.Font2 = new System.Drawing.Font("Segoe UI", 13F);
            this.drive_progress.Font3 = new System.Drawing.Font("Segoe UI", 13F);
            this.drive_progress.IgnoreHeight = false;
            this.drive_progress.Location = new System.Drawing.Point(633, 8);
            this.drive_progress.Name = "drive_progress";
            this.drive_progress.Offset = new System.Drawing.Point(0, 0);
            this.drive_progress.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(223)))), ((int)(((byte)(223)))));
            this.drive_progress.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.drive_progress.ProgressLineThikness = 12F;
            this.drive_progress.Size = new System.Drawing.Size(204, 210);
            this.drive_progress.Style = LimitlessUI.ArchProgressBar_WOC.StyleEnum.Style2;
            this.drive_progress.TabIndex = 4;
            this.drive_progress.Text = "archProgressBar_WOC3";
            this.drive_progress.Text1 = "Drive C:";
            this.drive_progress.Text1Color = System.Drawing.SystemColors.ControlText;
            this.drive_progress.Text2 = "99%";
            this.drive_progress.Text2Color = System.Drawing.SystemColors.ControlText;
            this.drive_progress.Text3 = "55C";
            this.drive_progress.Text3Color = System.Drawing.SystemColors.ControlText;
            this.drive_progress.Value = 50F;
            this.drive_progress.Click += new System.EventHandler(this.ProgressBar_Click);
            // 
            // cpu_progress
            // 
            this.cpu_progress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cpu_progress.Angle = 360;
            this.cpu_progress.BackLineThikness = 12F;
            this.cpu_progress.Font1 = new System.Drawing.Font("Segoe UI", 13F);
            this.cpu_progress.Font2 = new System.Drawing.Font("Segoe UI", 13F);
            this.cpu_progress.Font3 = new System.Drawing.Font("Segoe UI", 13F);
            this.cpu_progress.IgnoreHeight = false;
            this.cpu_progress.Location = new System.Drawing.Point(3, 8);
            this.cpu_progress.Name = "cpu_progress";
            this.cpu_progress.Offset = new System.Drawing.Point(0, 0);
            this.cpu_progress.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(223)))), ((int)(((byte)(223)))));
            this.cpu_progress.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.cpu_progress.ProgressLineThikness = 12F;
            this.cpu_progress.Size = new System.Drawing.Size(204, 210);
            this.cpu_progress.Style = LimitlessUI.ArchProgressBar_WOC.StyleEnum.Style3;
            this.cpu_progress.TabIndex = 1;
            this.cpu_progress.Text = "archProgressBar_WOC2";
            this.cpu_progress.Text1 = "CPU";
            this.cpu_progress.Text1Color = System.Drawing.SystemColors.ControlText;
            this.cpu_progress.Text2 = "99%";
            this.cpu_progress.Text2Color = System.Drawing.SystemColors.ControlText;
            this.cpu_progress.Text3 = "55C";
            this.cpu_progress.Text3Color = System.Drawing.Color.Lime;
            this.cpu_progress.Value = 25F;
            this.cpu_progress.Click += new System.EventHandler(this.ProgressBar_Click);
            // 
            // ram_progress
            // 
            this.ram_progress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ram_progress.Angle = 360;
            this.ram_progress.BackLineThikness = 12F;
            this.ram_progress.Font1 = new System.Drawing.Font("Segoe UI", 13F);
            this.ram_progress.Font2 = new System.Drawing.Font("Segoe UI", 13F);
            this.ram_progress.Font3 = new System.Drawing.Font("Segoe UI", 13F);
            this.ram_progress.IgnoreHeight = false;
            this.ram_progress.Location = new System.Drawing.Point(213, 8);
            this.ram_progress.Name = "ram_progress";
            this.ram_progress.Offset = new System.Drawing.Point(0, 0);
            this.ram_progress.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(223)))), ((int)(((byte)(223)))));
            this.ram_progress.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.ram_progress.ProgressLineThikness = 12F;
            this.ram_progress.Size = new System.Drawing.Size(204, 210);
            this.ram_progress.Style = LimitlessUI.ArchProgressBar_WOC.StyleEnum.Style2;
            this.ram_progress.TabIndex = 2;
            this.ram_progress.Text = "archProgressBar_WOC1";
            this.ram_progress.Text1 = "RAM";
            this.ram_progress.Text1Color = System.Drawing.SystemColors.ControlText;
            this.ram_progress.Text2 = "99%";
            this.ram_progress.Text2Color = System.Drawing.SystemColors.ControlText;
            this.ram_progress.Text3 = "55C";
            this.ram_progress.Text3Color = System.Drawing.SystemColors.ControlText;
            this.ram_progress.Value = 50F;
            this.ram_progress.Click += new System.EventHandler(this.ProgressBar_Click);
            // 
            // Timer_5s
            // 
            this.Timer_5s.Enabled = true;
            this.Timer_5s.Interval = 5000;
            this.Timer_5s.Tick += new System.EventHandler(this.Timer_5s_Tick);
            // 
            // drives_lv
            // 
            this.drives_lv.AutoExpand = true;
            this.drives_lv.AutoScroll = true;
            this.drives_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.drives_lv.Location = new System.Drawing.Point(0, 227);
            this.drives_lv.Name = "drives_lv";
            this.drives_lv.Size = new System.Drawing.Size(840, 190);
            this.drives_lv.TabIndex = 3;
            this.drives_lv.Text = "listView_WOC1";
            this.drives_lv.Vertical = true;
            // 
            // Dashboard_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.drives_lv);
            this.Controls.Add(this.archProgress_panel);
            this.Name = "Dashboard_Tab";
            this.Size = new System.Drawing.Size(840, 520);
            this.SizeChanged += new System.EventHandler(this.OnSizeChanged);
            this.archProgress_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion


        private System.Windows.Forms.Timer Timer_1s;
        private System.Windows.Forms.TableLayoutPanel archProgress_panel;
        private ArchProgressBar_WOC ram_progress;
        private ArchProgressBar_WOC gpu_progress;
        private ArchProgressBar_WOC cpu_progress;
        private ArchProgressBar_WOC drive_progress;
        private System.Windows.Forms.Timer Timer_5s;
        private ListView_WOC drives_lv;
    }
}
