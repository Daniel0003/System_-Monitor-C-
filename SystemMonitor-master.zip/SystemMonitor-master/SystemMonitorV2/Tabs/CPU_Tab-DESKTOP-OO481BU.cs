﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemMonitor.ListItems;
using System.Threading;
using System.Diagnostics;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class CPU_Tab : UserControl, Tab_WOC, Theme_interface
    {
        private DataCollector dataCollector;
        private int chartLenght;
        private static CPU_Tab _instance;

        public CPU_Tab(DataCollector dataCollector)
        {
            InitializeComponent();
            this.dataCollector = dataCollector;

            loadSeries();
            timer_1s.Start();
            loadSpecs();
        }

        public void themeChanged(bool isLight)
        {
            Utils.changeChartTheme(load_chart, isLight);
            Utils.changeChartTheme(temps_chart, isLight);
            Utils.changeSpecsTheme(specs_lv, isLight);

            foreach (VerticalLabels item in cores_lv.items)
                item.isLightTheme(isLight);
        }

        public void onShowTab()
        {
            Utils.prepareChart(load_chart, Settings.Default.cpuXLenght);
            Utils.prepareChart(temps_chart, Settings.Default.cpuXLenght);
            chartLenght = Settings.Default.cpuXLenght;
        }

        private void timer_1s_Tick(object sender, EventArgs e)
        {
            dataCollector.dataCollected.WaitOne();
            for (int i = 0; i < load_chart.Series.Count; i++)
            {
                try
                {
                    load_chart.Series[i].Points.AddY(dataCollector.cpuLoad.ElementAt(i).Value);
                    if (i < temps_chart.Series.Count)
                        temps_chart.Series[i].Points.AddY(dataCollector.cpuTemps.ElementAt(i).Value);
                    ((VerticalLabels)cores_lv.items.ElementAt(i)).setValues((float)Math.Round(dataCollector.cpuLoad.ElementAt(i).Value, 2), dataCollector.cpuTemps.ElementAt(i).Value);

                    if (temps_chart.Series[i].Points.Count > chartLenght || load_chart.Series[i].Points.Count > chartLenght)
                    {
                        load_chart.Series[i].Points.RemoveAt(0);
                        temps_chart.Series[i].Points.RemoveAt(0);

                        if (temps_chart.Series[i].Points.Count > chartLenght + 1)
                            while (temps_chart.Series[i].Points.Count > chartLenght)
                            {
                                load_chart.Series[i].Points.RemoveAt(0);
                                temps_chart.Series[i].Points.RemoveAt(0);
                            }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        private void loadSeries()
        {
            load_chart.Series.Clear();
            temps_chart.Series.Clear();

            dataCollector.dataCollected.WaitOne();
            foreach (string name in dataCollector.cpuLoad.Keys)
            {
                cores_lv.add(new VerticalLabels(name.Replace("CPU ", "")));
                Utils.addSerie(load_chart.Series, name);
                if (!name.Equals("CPU Total"))
                    Utils.addSerie(temps_chart.Series, name);
                else
                    Utils.addSerie(temps_chart.Series, "CPU Package");
            }
        }

        private void loadSpecs()
        {
            dataCollector.cpuThread.Join();
            foreach (KeyValuePair<string, string> pair in dataCollector.cpuData)
                specs_lv.add(new Specs_ListChild(pair.Key + ":", pair.Value, 10));
        }

        public static CPU_Tab getInstance(DataCollector dataCollector)
        {
            if (_instance == null)
                _instance = new CPU_Tab(dataCollector);
            return _instance;
        }
    }
}
