﻿using System;
using System.Linq;
using System.Windows.Forms;
using SystemMonitor.Fragments;
using SystemMonitor.Core;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class CPU_Tab : UserControl, Tab_WOC, IThemeChanger
    {
        private readonly DataCollector _dataCollector = DataCollector.Instance;
        private int chartLenght;
        private static CPU_Tab _instance;
        public static CPU_Tab Instance => _instance ?? (_instance = new CPU_Tab());

        public CPU_Tab()
        {
            InitializeComponent();

            LoadSeries();
            LoadSpecs();
        }

        public void ThemeChanged(bool isLight)
        {
            Utils.ChangeTheme(load_chart, isLight);
            Utils.ChangeTheme(temp_chart, isLight);
            Utils.ChangeTheme(specs_lv, isLight);
            Utils.ChangeTheme(load_dd, isLight);
            Utils.ChangeTheme(temp_dd, isLight);

            foreach (var control in cores_lv.Items)
                (control as VerticalLabels).IsLightTheme = isLight;
        }

        public void OnShowTab()
        {
            Utils.PrepareChart(load_chart, Settings.Default.cpuXLenght);
            Utils.PrepareChart(temp_chart, Settings.Default.cpuXLenght);
            chartLenght = Settings.Default.cpuXLenght;
        }

        private void Timer_1s_Tick(object sender, EventArgs e)
        {
            _dataCollector.DataCollected.WaitOne();
            for (int i = 0; i < load_chart.chart.Series.Count; i++)
            {
                try
                {
                    load_chart.chart.AddValue(i, (int) _dataCollector.CpuLoad.ElementAt(i).Value);
                    if (i < temp_chart.chart.Series.Count)
                        temp_chart.chart.AddValue(i, _dataCollector.CpuTemps.ElementAt(i).Value);
                    ((VerticalLabels) cores_lv.Items.ElementAt(i)).SetValues(
                        _dataCollector.CpuLoad.ElementAt(i).Value, _dataCollector.CpuTemps.ElementAt(i).Value);
                }
                catch
                {
                    // ignored
                }
            }
        }

        private void LoadSeries()
        {
            load_chart.chart.Series.Clear();
            temp_chart.chart.Series.Clear();

            _dataCollector.DataCollected.WaitOne();

            for (var i = 0; i < _dataCollector.CpuLoad.Keys.Count; i++)
            {
                var name = _dataCollector.CpuLoad.ElementAt(i).Key;

                cores_lv.Add(new VerticalLabels(name.Replace("CPU ", "")));
                load_chart.chart.AddSerie(Utils.LinesColors[i], name, true);
                temp_chart.chart.AddSerie(Utils.LinesColors[i], !name.Equals("CPU Total") ? name : "CPU Package", true);
            }
            temp_chart.legend.NotifySeriesChanged();
            load_chart.legend.NotifySeriesChanged();
        }

        private void LoadSpecs()
        {
            _dataCollector.CpuTask.Wait();
            foreach (var pair in _dataCollector.CpuData)
                specs_lv.Add(new Specs_ListChild(pair.Key + ":", pair.Value, 10));
        }
    }
}