﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using SystemMonitor.Core;

namespace SystemMonitor.Tabs
{
    public partial class RemoteMon_TAB : UserControl, IThemeChanger
    {
        private static RemoteMon_TAB _instance;
        public List<string> CheckedItems = new List<string>();
        private readonly DataCollector _dataCollector = DataCollector.Instance;

        public static RemoteMon_TAB Instance => _instance ?? (_instance = new RemoteMon_TAB());

        public RemoteMon_TAB()
        {
            InitializeComponent();
            server_switch.IsOn = Settings.Default.runServer;
            CheckForHardware();
        }

        private void CheckForHardware()
        {
            items_lv.Items.Add(_dataCollector.CpuName);
            items_lv.Items.Add("RAM: " + Math.Round(_dataCollector.TotalRam, 2) + "GB");

            foreach (SortedDictionary<string, string> gpu in _dataCollector.GpuData)
                if (!gpu["Name"].Contains("Intel"))
                    if (gpu["Name"].Contains("NVIDIA") || gpu["Name"].Contains("AMD") ||
                        gpu["Name"].Contains("ATI"))
                    {
                        items_lv.Items.Add("GPU (s)");
                        break;
                    }

            _dataCollector.DriveDataCollected.WaitOne();
            items_lv.Items.Add("Drive: " + _dataCollector.DriveData.First()["Caption"]);

            CheckedItems = Settings.Default.listData.Split(',').ToList();

            if (CheckedItems.Contains("CPU"))
                items_lv.Items[0].Checked = true;
            if (CheckedItems.Contains("RAM"))
                items_lv.Items[1].Checked = true;
            if (CheckedItems.Contains("GPU"))
                items_lv.Items[2].Checked = true;
            foreach (string item in CheckedItems)
            foreach (ListViewItem item2 in items_lv.Items)
                if (item2.Text.Equals(item))
                    item2.Checked = true;
        }

        public void ThemeChanged(bool isLight)
        {
            server_txt.ForeColor = isLight ? Color.Black : Color.White;
            client_txt.ForeColor = isLight ? Color.Black : Color.White;
            ip_txt.ForeColor = isLight ? Color.Black : Color.White;

            items_lv.BackColor = isLight ? Color.White : Color.Black;
            items_lv.ForeColor = isLight ? Color.Black : Color.White;
        }

        private void Items_lv_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            var itemsToDelete = new List<string>();
            foreach (ListViewItem item in items_lv.Items)
                itemsToDelete.Add(item.Text);
            

            CheckedItems.Clear();
            foreach (ListViewItem item in items_lv.CheckedItems)
            {
                if (item.Text.Equals(_dataCollector.CpuName))
                    CheckedItems.Add("CPU");
                else if (item.Text.Contains("GPU"))
                    CheckedItems.Add("GPU");
                else if (item.Text.Contains("RAM"))
                    CheckedItems.Add("RAM");
                else
                    CheckedItems.Add(item.Text);
                itemsToDelete.Remove(item.Text);
            }


            foreach (var item in itemsToDelete)
                if (item.Contains(_dataCollector.CpuName))
                    TCPServer.broadcastln("30");
                else if (item.Contains("RAM"))
                    TCPServer.broadcastln("31");
                else if (item.Contains("GPU"))
                    TCPServer.broadcastln("32");
                else if (item.Contains("Drive"))
                    TCPServer.broadcastln("36");

            Settings.Default.listData = string.Join(",", CheckedItems.ToArray());
            Settings.Default.Save();

            Sender.Instance.SetCheckedItems(CheckedItems);
            MainForm.Instance.HideBorders(splitContainer.Panel1.Width);
        }


        private void Server_switch_Click(object sender, EventArgs e)
        {
            if (server_switch.IsOn)
                TCPServer.startListeningInSeperateThread(4444, 1);
            else
                TCPServer.closeServer();

            Settings.Default.runServer = server_switch.IsOn;
            Settings.Default.Save();
        }


        public string Client
        {
            get => ip_txt.Text;
            set
            {
                int Del()
                {
                    ip_txt.Text = value;
                    return 0;
                }

                Invoke((Func<int>) Del);
            }
        }
    }
}