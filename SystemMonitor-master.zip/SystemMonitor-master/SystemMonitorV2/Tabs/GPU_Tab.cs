﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using SystemMonitor.Core;
using SystemMonitor.Fragments;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class GPU_Tab : UserControl, Tab_WOC, IThemeChanger
    {
        private static GPU_Tab _instance;
        private readonly DataCollector _dataCollector = DataCollector.Instance;
        private int _chartLenght;

        public static GPU_Tab Instance => _instance ?? (_instance = new GPU_Tab());

        public GPU_Tab()
        {
            InitializeComponent();

            _chartLenght = Settings.Default.gpuXLenght;
            timer_1s.Start();

            LoadSeries();
            LoadSpecs();
        }

        public void ThemeChanged(bool isLight)
        {
            Utils.ChangeTheme(gpu_chart, isLight);
            Utils.ChangeTheme(clocks_chart, isLight);
            Utils.ChangeTheme(specs_lv, isLight);
            Utils.ChangeTheme(gpuClocks_dd, isLight);
            Utils.ChangeTheme(gpu_dd, isLight);

            foreach (var item in gpus_lv.Items)
                (item as VerticalLabels).IsLightTheme = isLight;
        }

        public void OnShowTab()
        {
            Utils.PrepareChart(gpu_chart, Settings.Default.gpuXLenght);
            Utils.PrepareChart(clocks_chart, Settings.Default.gpuXLenght);
            _chartLenght = Settings.Default.gpuXLenght;
        }

        private void LoadSeries()
        {
            gpu_chart.chart.Series.Clear();
            clocks_chart.chart.Series.Clear();

            _dataCollector.DataCollected.WaitOne();
            for (int i = 0; i < _dataCollector.GpuCoreLoad.Count; i++)
            {
                gpus_lv.Add(new VerticalLabels("gpu #" + i));

                gpu_chart.chart.AddSerie(Color.Red, "GPU #" + i + " Load", true);
                gpu_chart.chart.AddSerie(Color.Red, "GPU #" + i + " Temp", true);
                clocks_chart.chart.AddSerie(Color.Red, "GPU #" + i + " Core clock", true);
                clocks_chart.chart.AddSerie(Color.Red, "GPU #" + i + " Memory clock", true);
            }
            gpu_chart.legend.NotifySeriesChanged();
            clocks_chart.legend.NotifySeriesChanged();
        }

        private void timer_1s_Tick(object sender, EventArgs e)
        {
            try
            {
                for (var i = 0; i < (gpu_chart.chart.Series.Count / 2); i++)
                {
                    string gpuName = _dataCollector.GpuCoreClock.Keys.ElementAt(i);
                    ((VerticalLabels) gpus_lv.Items.ElementAt(i)).SetValues(_dataCollector.GpuCoreLoad[gpuName],
                        _dataCollector.GpuTemps[gpuName], _dataCollector.GpuCoreClock[gpuName],
                        _dataCollector.GpuMemoryClock[gpuName]);

                    gpu_chart.chart.AddValue(i, _dataCollector.GpuCoreClock[gpuName]);
                    gpu_chart.chart.AddValue(i + 1, _dataCollector.GpuTemps[gpuName]);

                    clocks_chart.chart.AddValue(i, (int) _dataCollector.GpuCoreLoad[gpuName]);
                    clocks_chart.chart.AddValue(i + 1, _dataCollector.GpuMemoryClock[gpuName]);
                }
            }
            catch
            {
                // ignored
            }
        }

        private void LoadSpecs()
        {
            _dataCollector.GpuTask.Wait();
            foreach (var dictionary in _dataCollector.GpuData)
            {
                specs_lv.Add(Utils.GenerateTitleLabel(dictionary["Name"] + ":"));
                foreach (var pair in dictionary)
                    if (pair.Key != "Name" && !pair.Key.Contains("Caption") && !pair.Key.Contains("Description"))
                        specs_lv.Add(new Specs_ListChild(pair.Key + ":", pair.Value, 12));
            }
        }
    }
}