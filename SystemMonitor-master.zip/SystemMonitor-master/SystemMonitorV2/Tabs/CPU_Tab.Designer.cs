﻿using SystemMonitor.Fragments;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class CPU_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.load_dd = new LimitlessUI.DropDown_WOC();
            this.load_chart = new Chart_UC();
            this.timer_1s = new System.Windows.Forms.Timer(this.components);
            this.animator_WOC1 = new LimitlessUI.Animator_WOC();
            this.temp_dd = new LimitlessUI.DropDown_WOC();
            this.temp_chart = new Chart_UC();
            this.specs_lv = new LimitlessUI.ListView_WOC();
            this.cores_lv = new LimitlessUI.ListView_WOC();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cores_lv.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // load_dd
            // 
            this.load_dd.AnimationLength = 300;
            this.load_dd.ArrowSize = 19;
            this.load_dd.Control = this.load_chart;
            this.load_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.load_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.load_dd.Image = global::SystemMonitor.Properties.Resources.expand_light_ic;
            this.load_dd.Location = new System.Drawing.Point(8, 8);
            this.load_dd.Name = "load_dd";
            this.load_dd.Size = new System.Drawing.Size(830, 23);
            this.load_dd.TabIndex = 11;
            this.load_dd.Text = "CPU Load";
            this.load_dd.TextOffset = new System.Drawing.Point(-5, 0);
            // 
            // load_chart
            // 
            this.load_chart.Dock = System.Windows.Forms.DockStyle.Top;
            this.load_chart.Location = new System.Drawing.Point(8, 31);
            this.load_chart.Name = "load_chart";
            this.load_chart.Size = new System.Drawing.Size(830, 265);
            this.load_chart.TabIndex = 19;
            // 
            // timer_1s
            // 
            this.timer_1s.Enabled = true;
            this.timer_1s.Interval = 1000;
            this.timer_1s.Tick += new System.EventHandler(this.Timer_1s_Tick);
            // 
            // animator_WOC1
            // 
            this.animator_WOC1.Animation = LimitlessUI.Animator_WOC.Animations.ChangeWidth;
            this.animator_WOC1.CheckMonitorFps = false;
            this.animator_WOC1.Control = null;
            // 
            // temp_dd
            // 
            this.temp_dd.AnimationLength = 300;
            this.temp_dd.ArrowSize = 19;
            this.temp_dd.Control = this.temp_chart;
            this.temp_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.temp_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.temp_dd.Image = global::SystemMonitor.Properties.Resources.expand_light_ic;
            this.temp_dd.Location = new System.Drawing.Point(8, 296);
            this.temp_dd.Name = "temp_dd";
            this.temp_dd.Size = new System.Drawing.Size(830, 23);
            this.temp_dd.TabIndex = 20;
            this.temp_dd.Text = "CPU Temp";
            this.temp_dd.TextOffset = new System.Drawing.Point(-5, 0);
            // 
            // temp_chart
            // 
            this.temp_chart.Dock = System.Windows.Forms.DockStyle.Top;
            this.temp_chart.Location = new System.Drawing.Point(8, 319);
            this.temp_chart.Name = "temp_chart";
            this.temp_chart.Size = new System.Drawing.Size(830, 265);
            this.temp_chart.TabIndex = 24;
            // 
            // specs_lv
            // 
            this.specs_lv.AutoExpand = true;
            this.specs_lv.AutoScroll = true;
            this.specs_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.specs_lv.Location = new System.Drawing.Point(8, 684);
            this.specs_lv.Name = "specs_lv";
            this.specs_lv.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.specs_lv.Size = new System.Drawing.Size(830, 309);
            this.specs_lv.TabIndex = 26;
            this.specs_lv.Text = "listView_WOC2";
            this.specs_lv.Vertical = true;
            // 
            // cores_lv
            // 
            this.cores_lv.AutoExpand = false;
            this.cores_lv.AutoScroll = true;
            this.cores_lv.Controls.Add(this.panel1);
            this.cores_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.cores_lv.Location = new System.Drawing.Point(8, 584);
            this.cores_lv.Name = "cores_lv";
            this.cores_lv.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.cores_lv.Size = new System.Drawing.Size(830, 100);
            this.cores_lv.TabIndex = 25;
            this.cores_lv.Text = "listView_WOC1";
            this.cores_lv.Vertical = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(120, 90);
            this.panel1.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(35, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Temp:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(35, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Load:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(35, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Core:";
            // 
            // CPU_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.specs_lv);
            this.Controls.Add(this.cores_lv);
            this.Controls.Add(this.temp_chart);
            this.Controls.Add(this.temp_dd);
            this.Controls.Add(this.load_chart);
            this.Controls.Add(this.load_dd);
            this.Name = "CPU_Tab";
            this.Padding = new System.Windows.Forms.Padding(8, 8, 8, 0);
            this.Size = new System.Drawing.Size(846, 520);
            this.cores_lv.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private DropDown_WOC load_dd;
        private System.Windows.Forms.Timer timer_1s;
        private Animator_WOC animator_WOC1;
        private Chart_UC load_chart;
        private DropDown_WOC temp_dd;
        private Chart_UC temp_chart;
        private ListView_WOC specs_lv;
        private ListView_WOC cores_lv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}
