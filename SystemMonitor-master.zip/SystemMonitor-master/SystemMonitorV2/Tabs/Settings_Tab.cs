﻿using System;
using System.Drawing;
using System.Windows.Forms;
using SystemMonitor.Core;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class Settings_Tab : UserControl, IThemeChanger
    {
        private static Settings_Tab _instance;
        public static Settings_Tab Instance => _instance ?? (_instance = new Settings_Tab());

        public Settings_Tab()
        {
            InitializeComponent();

            chartHeightSlider.Value = Settings.Default.graphHeight;
            chartLineThiknessSlider.Value = Settings.Default.chartBorderWidth;
            cpuLenghtSlider.Value = Settings.Default.cpuXLenght;
            ramLenghtSlider.Value = Settings.Default.ramXLenght;
            gpuLenghtSlider.Value = Settings.Default.gpuXLenght;

            chartHeightValue.Text = Settings.Default.graphHeight + " px";
            chartLineThiknessValue.Text = Settings.Default.chartBorderWidth + " Px";
            cpuLenghtValue.Text = Settings.Default.cpuXLenght + "sec";
            ramLenghtValue.Text = Settings.Default.ramXLenght + "sec";
            gpuLenghtValue.Text = Settings.Default.gpuXLenght + "sec";

            minimise_sw.IsOn = Settings.Default.minimiseOnExit;
            theme_sw.IsOn = !Settings.Default.lightTheme;
        }

        public void ThemeChanged(bool isLight)
        {
            foreach (Label label in settingsNames_holder.Controls)
                label.ForeColor = isLight ? Color.Black : Color.White;
            foreach (Label label in settingsValues_holder.Controls)
                label.ForeColor = isLight ? Color.Black : Color.White;
        }

        private void OnSizeChanged(object sender, EventArgs e)
        {
            foreach (Control control in sliders_holder.Controls)
                control.Invalidate();
        }

        private void settingsSlider_ValueChanged(Slider_WOC slider, float val)
        {
            int value = (int)val;
            switch (slider.TabIndex)
            {
                case 30:
                    Settings.Default.graphHeight = value;
                    chartHeightValue.Text = value + "px";
                    break;
                case 31:
                    Settings.Default.chartBorderWidth = value;
                    chartLineThiknessValue.Text = value + "px";
                    break;
                case 32:
                    Settings.Default.cpuXLenght = value;
                    cpuLenghtValue.Text = value + "Sec.";
                    break;
                case 33:
                    Settings.Default.ramXLenght = value;
                    ramLenghtValue.Text = value + "Sec.";
                    break;
                case 34:
                    Settings.Default.gpuXLenght = value;
                    gpuLenghtValue.Text = value + "Sec.";
                    break;
            }
            Settings.Default.Save();
        }

        private void Switch_Click(object sender, EventArgs e)
        {
            var settings_sw = ((Switch_WOC)sender);
            if (settings_sw.TabIndex == 35)
            {
                Settings.Default.minimiseOnExit = settings_sw.IsOn;
                Settings.Default.Save();
            }
            else
            {
                Settings.Default.lightTheme = !settings_sw.IsOn;
                Settings.Default.Save();
                MainForm.Instance.SetTheme(!settings_sw.IsOn);
            }
        }

    }
}
