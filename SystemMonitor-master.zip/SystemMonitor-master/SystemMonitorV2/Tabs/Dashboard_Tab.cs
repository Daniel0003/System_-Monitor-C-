﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using SystemMonitor.Core;
using SystemMonitor.Fragments;
using SystemMonitor.Fragments;
using LimitlessUI;

namespace SystemMonitor.Tabs
{
    public partial class Dashboard_Tab : UserControl, IThemeChanger
    {
        private readonly DataCollector _dataCollector = DataCollector.Instance;
        private static Dashboard_Tab _instance;

        public static Dashboard_Tab Instance => _instance ?? (_instance = new Dashboard_Tab());
        public Dashboard_Tab() => InitializeComponent();


        public void ThemeChanged(bool isLight)
        {
            foreach (ArchProgressBar_WOC progress in archProgress_panel.Controls)
            {
                progress.Text1Color = isLight ? Color.Black : Color.White;
                progress.Text2Color = isLight ? Color.Black : Color.White;
                progress.Text3Color = isLight ? Color.Black : Color.White;
                progress.ProgressBackColor = isLight ? Theme.Default.controlsBG_light : Theme.Default.controlsBG_dark;
            }
            foreach (var control in drives_lv.Items)
                (control as Drives_listChild)?.ChangeTheme(isLight);
        }

        private void Timer_1s_Tick(object sender, EventArgs e)
        {
            try
            {
                _dataCollector.CpuTask.Wait();

                cpu_progress.UpdateData(Math.Round(_dataCollector.CpuLoad.First().Value, 2) + "%",
                    _dataCollector.CpuTemps.Last().Value + "°C", ((int) _dataCollector.CpuLoad.First().Value),
                    Utils.GetColorPerTemp(_dataCollector.CpuTemps.Last().Value));

                ram_progress.UpdateData(
                    Math.Round(_dataCollector.UsedRam, 2) + "/" + Math.Round(_dataCollector.TotalRam, 2) + "GB",
                    _dataCollector.UsedRamPrecentage);

                if (_dataCollector.GpuCoreLoad.Count != 0)
                    gpu_progress.UpdateData((int) _dataCollector.GpuCoreLoad.First().Value + "%",
                        _dataCollector.GpuTemps.First().Value + "°C", ((int) _dataCollector.GpuCoreLoad.First().Value),
                        Utils.GetColorPerTemp(_dataCollector.GpuTemps.First().Value));
            }
            catch
            {
                // ignored
            }
        }


        private void Timer_5s_Tick(object sender, EventArgs e)
        {
            try
            {
                if (drives_lv.Items.Count != _dataCollector.DriveData.Count || drives_lv.Items.Count == 0)
                {
                    drives_lv.Clear();
                    foreach (SortedDictionary<string, string> drive in _dataCollector.DriveData)
                    {
                        drives_lv.Add(new Drives_listChild(drive["Caption"],
                            Int16.Parse(drive["Load"]),
                            drive["Used Space"] + "/" +
                            drive["Size"]));
                        if (!Settings.Default.lightTheme)
                            ((Drives_listChild) drives_lv.Items.Last()).ChangeTheme(Settings.Default.lightTheme);
                        if ((drive["Caption"] + "\\").Equals(
                            Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System))))
                        {
                            drive_progress.UpdateData(
                                _dataCollector.DriveData.First()["Used Space"] + "/" +
                                _dataCollector.DriveData.First()["Size"],
                                Int32.Parse(_dataCollector.DriveData.ElementAt(0)["Load"]));
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void ProgressBar_Click(object sender, EventArgs e)
        {
            MainForm.Instance.LoadTab(((ArchProgressBar_WOC) sender).TabIndex);
        }


        private void OnSizeChanged(object sender, EventArgs e)
        {
            SuspendLayout();
            cpu_progress.Invalidate();
            ram_progress.Invalidate();
            gpu_progress.Invalidate();
            drive_progress.Invalidate();

            foreach (var drive in drives_lv.Items)
                (drive as Drives_listChild)?.Redraw();
            ResumeLayout();
        }
    }
}