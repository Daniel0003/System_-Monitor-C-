﻿using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class GPU_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GPU_Tab));
            this.gpuClocks_dd = new DropDown_WOC();
            this.gpuClocks_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.gpu_dd = new DropDown_WOC();
            this.gpu_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.gpus_lv = new ListView_WOC();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.specs_lv = new ListView_WOC();
            this.timer_1s = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.gpuClocks_chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gpu_chart)).BeginInit();
            this.gpus_lv.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpuClocks_dd
            // 
            this.gpuClocks_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpuClocks_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.gpuClocks_dd.Location = new System.Drawing.Point(8, 231);
            this.gpuClocks_dd.Name = "gpuClocks_dd";
            this.gpuClocks_dd.Size = new System.Drawing.Size(705, 23);
            this.gpuClocks_dd.TabIndex = 13;
            this.gpuClocks_dd.Text = "GPU Clocks";
            // 
            // gpuClocks_chart
            // 
            this.gpuClocks_chart.BorderlineColor = System.Drawing.Color.Maroon;
            chartArea3.AxisX.IsLabelAutoFit = false;
            chartArea3.AxisX.IsMarginVisible = false;
            chartArea3.AxisX.LabelAutoFitMaxFontSize = 5;
            chartArea3.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea3.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea3.AxisX.MajorGrid.LineWidth = 0;
            chartArea3.AxisX.MajorTickMark.Enabled = false;
            chartArea3.AxisX.Maximum = 300D;
            chartArea3.AxisX.Minimum = 3D;
            chartArea3.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea3.AxisX2.IsMarginVisible = false;
            chartArea3.AxisX2.MajorGrid.Enabled = false;
            chartArea3.AxisY.Interval = 500D;
            chartArea3.AxisY.IsLabelAutoFit = false;
            chartArea3.AxisY.IsMarginVisible = false;
            chartArea3.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea3.AxisY.MajorGrid.LineWidth = 0;
            chartArea3.AxisY.MajorTickMark.Enabled = false;
            chartArea3.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea3.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            chartArea3.InnerPlotPosition.Auto = false;
            chartArea3.InnerPlotPosition.Height = 87.96179F;
            chartArea3.InnerPlotPosition.Width = 93.32934F;
            chartArea3.InnerPlotPosition.X = 4F;
            chartArea3.InnerPlotPosition.Y = 6F;
            chartArea3.Name = "ChartArea1";
            this.gpuClocks_chart.ChartAreas.Add(chartArea3);
            this.gpuClocks_chart.Dock = System.Windows.Forms.DockStyle.Top;
            legend3.BackColor = System.Drawing.Color.Transparent;
            legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend3.Name = "Legend1";
            this.gpuClocks_chart.Legends.Add(legend3);
            this.gpuClocks_chart.Location = new System.Drawing.Point(8, 254);
            this.gpuClocks_chart.Margin = new System.Windows.Forms.Padding(0);
            this.gpuClocks_chart.Name = "gpuClocks_chart";
            series3.BorderWidth = 3;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Used RAM";
            series3.ShadowColor = System.Drawing.Color.Empty;
            this.gpuClocks_chart.Series.Add(series3);
            this.gpuClocks_chart.Size = new System.Drawing.Size(705, 200);
            this.gpuClocks_chart.TabIndex = 18;
            this.gpuClocks_chart.Text = "chart1";
            // 
            // gpu_dd
            // 
            this.gpu_dd.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpu_dd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.gpu_dd.Location = new System.Drawing.Point(8, 8);
            this.gpu_dd.Name = "gpu_dd";
            this.gpu_dd.Size = new System.Drawing.Size(705, 23);
            this.gpu_dd.TabIndex = 11;
            this.gpu_dd.Text = "GPU";
            // 
            // gpu_chart
            // 
            this.gpu_chart.BorderlineColor = System.Drawing.Color.Maroon;
            chartArea4.AxisX.IsLabelAutoFit = false;
            chartArea4.AxisX.IsMarginVisible = false;
            chartArea4.AxisX.LabelAutoFitMaxFontSize = 5;
            chartArea4.AxisX.LabelAutoFitMinFontSize = 5;
            chartArea4.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Transparent;
            chartArea4.AxisX.MajorGrid.LineWidth = 0;
            chartArea4.AxisX.MajorTickMark.Enabled = false;
            chartArea4.AxisX.Maximum = 300D;
            chartArea4.AxisX.Minimum = 3D;
            chartArea4.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea4.AxisX2.IsMarginVisible = false;
            chartArea4.AxisX2.MajorGrid.Enabled = false;
            chartArea4.AxisY.Interval = 50D;
            chartArea4.AxisY.IsLabelAutoFit = false;
            chartArea4.AxisY.IsMarginVisible = false;
            chartArea4.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.AxisY.MajorGrid.LineWidth = 0;
            chartArea4.AxisY.MajorTickMark.Enabled = false;
            chartArea4.AxisY.Maximum = 100D;
            chartArea4.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea4.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            chartArea4.InnerPlotPosition.Auto = false;
            chartArea4.InnerPlotPosition.Height = 87.96179F;
            chartArea4.InnerPlotPosition.Width = 93.32934F;
            chartArea4.InnerPlotPosition.X = 4F;
            chartArea4.InnerPlotPosition.Y = 6F;
            chartArea4.Name = "ChartArea1";
            this.gpu_chart.ChartAreas.Add(chartArea4);
            this.gpu_chart.Dock = System.Windows.Forms.DockStyle.Top;
            legend4.BackColor = System.Drawing.Color.Transparent;
            legend4.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend4.Name = "Legend1";
            this.gpu_chart.Legends.Add(legend4);
            this.gpu_chart.Location = new System.Drawing.Point(8, 31);
            this.gpu_chart.Margin = new System.Windows.Forms.Padding(0);
            this.gpu_chart.Name = "gpu_chart";
            series4.BorderWidth = 3;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.Name = "Used RAM";
            series4.ShadowColor = System.Drawing.Color.Empty;
            this.gpu_chart.Series.Add(series4);
            this.gpu_chart.Size = new System.Drawing.Size(705, 200);
            this.gpu_chart.TabIndex = 17;
            this.gpu_chart.Text = "load_chart";
            this.gpu_chart.Click += new System.EventHandler(this.gpu_chart_Click);
            // 
            // gpus_lv
            // 
            this.gpus_lv.AutoExpand = false;
            this.gpus_lv.AutoScroll = true;
            this.gpus_lv.Controls.Add(this.panel2);
            this.gpus_lv.Controls.Add(this.panel1);
            this.gpus_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpus_lv.Location = new System.Drawing.Point(8, 454);
            this.gpus_lv.Name = "gpus_lv";
            this.gpus_lv.Size = new System.Drawing.Size(705, 130);
            this.gpus_lv.TabIndex = 15;
            this.gpus_lv.Text = "listView_WOC1";
            this.gpus_lv.Vertical = true;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(145, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(160, 130);
            this.panel2.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(145, 130);
            this.panel1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(28, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Core Clock:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(28, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 30;
            this.label4.Text = "Memory Clock:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(28, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "Temperature:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(28, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 20);
            this.label6.TabIndex = 28;
            this.label6.Text = "GPU Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(28, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "Core Load:";
            // 
            // specs_lv
            // 
            this.specs_lv.AutoExpand = true;
            this.specs_lv.AutoScroll = true;
            this.specs_lv.Dock = System.Windows.Forms.DockStyle.Top;
            this.specs_lv.Location = new System.Drawing.Point(8, 584);
            this.specs_lv.Name = "specs_lv";
            this.specs_lv.Padding = new System.Windows.Forms.Padding(27, 10, 0, 0);
            this.specs_lv.Size = new System.Drawing.Size(705, 309);
            this.specs_lv.TabIndex = 16;
            this.specs_lv.Text = "listView_WOC2";
            this.specs_lv.Vertical = true;
            // 
            // timer_1s
            // 
            this.timer_1s.Interval = 1000;
            this.timer_1s.Tick += new System.EventHandler(this.timer_1s_Tick);
            // 
            // GPU_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.specs_lv);
            this.Controls.Add(this.gpus_lv);
            this.Controls.Add(this.gpuClocks_chart);
            this.Controls.Add(this.gpuClocks_dd);
            this.Controls.Add(this.gpu_chart);
            this.Controls.Add(this.gpu_dd);
            this.Name = "GPU_Tab";
            this.Padding = new System.Windows.Forms.Padding(8, 8, 8, 0);
            this.Size = new System.Drawing.Size(721, 520);
            ((System.ComponentModel.ISupportInitialize)(this.gpuClocks_chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gpu_chart)).EndInit();
            this.gpus_lv.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private DropDown_WOC gpuClocks_dd;
        private DropDown_WOC gpu_dd;
        private ListView_WOC gpus_lv;
        private System.Windows.Forms.Panel panel1;
        private ListView_WOC specs_lv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Timer timer_1s;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataVisualization.Charting.Chart gpu_chart;
        private System.Windows.Forms.DataVisualization.Charting.Chart gpuClocks_chart;
    }
}
