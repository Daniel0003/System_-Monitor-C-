﻿using LimitlessUI;

namespace SystemMonitor.Tabs
{
    partial class RemoteMon_TAB
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.separator_WOC3 = new Separator_WOC();
            this.items_lv = new System.Windows.Forms.ListView();
            this.client_txt = new System.Windows.Forms.Label();
            this.server_switch = new Switch_WOC();
            this.server_txt = new System.Windows.Forms.Label();
            this.ip_txt = new System.Windows.Forms.Label();
            this.separator_WOC1 = new Separator_WOC();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 1);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.client_txt);
            this.splitContainer.Panel2.Controls.Add(this.server_switch);
            this.splitContainer.Panel2.Controls.Add(this.server_txt);
            this.splitContainer.Panel2.Controls.Add(this.ip_txt);
            this.splitContainer.Size = new System.Drawing.Size(840, 519);
            this.splitContainer.SplitterDistance = 351;
            this.splitContainer.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.separator_WOC3);
            this.panel1.Controls.Add(this.items_lv);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(4, 4, 0, 0);
            this.panel1.Size = new System.Drawing.Size(351, 519);
            this.panel1.TabIndex = 12;
            // 
            // separator_WOC3
            // 
            this.separator_WOC3.Dock = System.Windows.Forms.DockStyle.Right;
            this.separator_WOC3.Location = new System.Drawing.Point(350, 4);
            this.separator_WOC3.Name = "separator_WOC3";
            this.separator_WOC3.Size = new System.Drawing.Size(1, 515);
            this.separator_WOC3.TabIndex = 16;
            this.separator_WOC3.Text = "separator_WOC3";
            this.separator_WOC3.Vertical = true;
            // 
            // items_lv
            // 
            this.items_lv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.items_lv.CheckBoxes = true;
            this.items_lv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.items_lv.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.items_lv.Location = new System.Drawing.Point(4, 4);
            this.items_lv.Margin = new System.Windows.Forms.Padding(0);
            this.items_lv.Name = "items_lv";
            this.items_lv.Size = new System.Drawing.Size(347, 515);
            this.items_lv.TabIndex = 14;
            this.items_lv.UseCompatibleStateImageBehavior = false;
            this.items_lv.View = System.Windows.Forms.View.List;
            this.items_lv.ItemChecked += new System.Windows.Forms.ItemCheckedEventHandler(this.Items_lv_ItemChecked);
            // 
            // client_txt
            // 
            this.client_txt.AutoSize = true;
            this.client_txt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.client_txt.Location = new System.Drawing.Point(22, 58);
            this.client_txt.Name = "client_txt";
            this.client_txt.Size = new System.Drawing.Size(107, 21);
            this.client_txt.TabIndex = 9;
            this.client_txt.Text = "Current client:";
            // 
            // server_switch
            // 
            this.server_switch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.server_switch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.server_switch.IsOn = false;
            this.server_switch.Location = new System.Drawing.Point(95, 27);
            this.server_switch.Name = "server_switch";
            this.server_switch.OffColor = System.Drawing.Color.DarkGray;
            this.server_switch.OffText = "Off";
            this.server_switch.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.server_switch.OnText = "On";
            this.server_switch.Size = new System.Drawing.Size(51, 18);
            this.server_switch.TabIndex = 12;
            this.server_switch.Text = "switch_WOC1";
            this.server_switch.TextEnabled = true;
            this.server_switch.Click += new System.EventHandler(this.Server_switch_Click);
            this.server_switch.DoubleClick += new System.EventHandler(this.Server_switch_Click);
            // 
            // server_txt
            // 
            this.server_txt.AutoSize = true;
            this.server_txt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.server_txt.Location = new System.Drawing.Point(22, 24);
            this.server_txt.Name = "server_txt";
            this.server_txt.Size = new System.Drawing.Size(58, 21);
            this.server_txt.TabIndex = 8;
            this.server_txt.Text = "Server:";
            // 
            // ip_txt
            // 
            this.ip_txt.AutoSize = true;
            this.ip_txt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ip_txt.Location = new System.Drawing.Point(129, 58);
            this.ip_txt.Name = "ip_txt";
            this.ip_txt.Size = new System.Drawing.Size(48, 21);
            this.ip_txt.TabIndex = 10;
            this.ip_txt.Text = "None";
            // 
            // separator_WOC1
            // 
            this.separator_WOC1.Dock = System.Windows.Forms.DockStyle.Top;
            this.separator_WOC1.Location = new System.Drawing.Point(0, 0);
            this.separator_WOC1.Name = "separator_WOC1";
            this.separator_WOC1.Size = new System.Drawing.Size(840, 1);
            this.separator_WOC1.TabIndex = 0;
            this.separator_WOC1.Text = "separator_WOC1";
            this.separator_WOC1.Vertical = false;
            // 
            // RemoteMon_TAB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.separator_WOC1);
            this.Name = "RemoteMon_TAB";
            this.Size = new System.Drawing.Size(840, 520);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Separator_WOC separator_WOC1;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label client_txt;
        private Switch_WOC server_switch;
        private System.Windows.Forms.Label server_txt;
        private System.Windows.Forms.Label ip_txt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView items_lv;
        private Separator_WOC separator_WOC3;
    }
}
