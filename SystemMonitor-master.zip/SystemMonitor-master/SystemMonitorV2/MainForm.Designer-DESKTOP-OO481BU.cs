﻿using LimitlessUI;

namespace SystemMonitor
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.title_bar = new System.Windows.Forms.Panel();
            this.minimise_btn = new FlatButton_WOC();
            this.maximise_btn = new FlatButton_WOC();
            this.exit_txt = new FlatButton_WOC();
            this.appTitle_txt = new System.Windows.Forms.Label();
            this.nav_panel = new System.Windows.Forms.Panel();
            this.settings_btn = new FlatButton_WOC();
            this.remote_btn = new FlatButton_WOC();
            this.gpu_btn = new FlatButton_WOC();
            this.ram_btn = new FlatButton_WOC();
            this.cpu_btn = new FlatButton_WOC();
            this.dashboard_btn = new FlatButton_WOC();
            this.drawer_brn = new FlatButton_WOC();
            this.dragControl = new DragControl_WOC();
            this.nav_adapter = new TabsAdapter_WOC();
            this.tab_holder = new System.Windows.Forms.Panel();
            this.tray_ic = new System.Windows.Forms.NotifyIcon(this.components);
            this.tray_ic_menu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drawer_anim = new Animator_WOC();
            this.tabTitle_txt = new System.Windows.Forms.Label();
            this.tabTitle_panel = new System.Windows.Forms.Panel();
            this.title_bar.SuspendLayout();
            this.nav_panel.SuspendLayout();
            this.tray_ic_menu.SuspendLayout();
            this.tabTitle_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // title_bar
            // 
            this.title_bar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.title_bar.Controls.Add(this.minimise_btn);
            this.title_bar.Controls.Add(this.maximise_btn);
            this.title_bar.Controls.Add(this.exit_txt);
            this.title_bar.Controls.Add(this.appTitle_txt);
            this.title_bar.Dock = System.Windows.Forms.DockStyle.Top;
            this.title_bar.Location = new System.Drawing.Point(2, 3);
            this.title_bar.Name = "title_bar";
            this.title_bar.Size = new System.Drawing.Size(1044, 30);
            this.title_bar.TabIndex = 0;
            // 
            // minimise_btn
            // 
            this.minimise_btn.ActiveColor = System.Drawing.Color.Empty;
            this.minimise_btn.ActiveImage = global::SystemMonitor.Properties.Resources.minimise_onhover_ic;
            this.minimise_btn.ActiveTextColor = System.Drawing.Color.White;
            this.minimise_btn.BackColor = System.Drawing.SystemColors.Control;
            this.minimise_btn.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimise_btn.DrawImage = true;
            this.minimise_btn.DrawText = false;
            this.minimise_btn.Image = ((System.Drawing.Image)(resources.GetObject("minimise_btn.Image")));
            this.minimise_btn.ImageSize = new System.Drawing.SizeF(17F, 17F);
            this.minimise_btn.IsTab = false;
            this.minimise_btn.Location = new System.Drawing.Point(942, 0);
            this.minimise_btn.Name = "minimise_btn";
            this.minimise_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.minimise_btn.OnHoverTextColor = System.Drawing.Color.White;
            this.minimise_btn.Selected = false;
            this.minimise_btn.Size = new System.Drawing.Size(34, 30);
            this.minimise_btn.TabIndex = 2;
            this.minimise_btn.Text = "exit_btn";
            this.minimise_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.minimise_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.minimise_btn.UseActiveImageWhileHovering = true;
            this.minimise_btn.Click += new System.EventHandler(this.minimise_btn_Click);
            // 
            // maximise_btn
            // 
            this.maximise_btn.ActiveColor = System.Drawing.Color.Empty;
            this.maximise_btn.ActiveImage = global::SystemMonitor.Properties.Resources.maxsimise_onhover_ic;
            this.maximise_btn.ActiveTextColor = System.Drawing.Color.White;
            this.maximise_btn.BackColor = System.Drawing.SystemColors.Control;
            this.maximise_btn.Dock = System.Windows.Forms.DockStyle.Right;
            this.maximise_btn.DrawImage = true;
            this.maximise_btn.DrawText = false;
            this.maximise_btn.Image = global::SystemMonitor.Properties.Resources.maximise_light_ic;
            this.maximise_btn.ImageSize = new System.Drawing.SizeF(17F, 17F);
            this.maximise_btn.IsTab = false;
            this.maximise_btn.Location = new System.Drawing.Point(976, 0);
            this.maximise_btn.Name = "maximise_btn";
            this.maximise_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.maximise_btn.OnHoverTextColor = System.Drawing.Color.White;
            this.maximise_btn.Selected = false;
            this.maximise_btn.Size = new System.Drawing.Size(34, 30);
            this.maximise_btn.TabIndex = 1;
            this.maximise_btn.Text = "exit_btn";
            this.maximise_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.maximise_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.maximise_btn.UseActiveImageWhileHovering = true;
            this.maximise_btn.Click += new System.EventHandler(this.maximise_btn_Click);
            // 
            // exit_txt
            // 
            this.exit_txt.ActiveColor = System.Drawing.Color.Empty;
            this.exit_txt.ActiveImage = global::SystemMonitor.Properties.Resources.exit_highlited_ic;
            this.exit_txt.ActiveTextColor = System.Drawing.Color.White;
            this.exit_txt.BackColor = System.Drawing.SystemColors.Control;
            this.exit_txt.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit_txt.DrawImage = true;
            this.exit_txt.DrawText = false;
            this.exit_txt.Image = global::SystemMonitor.Properties.Resources.exit_light_ic;
            this.exit_txt.ImageSize = new System.Drawing.SizeF(17F, 17F);
            this.exit_txt.IsTab = false;
            this.exit_txt.Location = new System.Drawing.Point(1010, 0);
            this.exit_txt.Name = "exit_txt";
            this.exit_txt.OnHoverColor = System.Drawing.Color.Empty;
            this.exit_txt.OnHoverTextColor = System.Drawing.Color.White;
            this.exit_txt.Selected = false;
            this.exit_txt.Size = new System.Drawing.Size(34, 30);
            this.exit_txt.TabIndex = 0;
            this.exit_txt.Text = "exit_btn";
            this.exit_txt.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.exit_txt.TextOffset = new System.Drawing.Point(0, 0);
            this.exit_txt.UseActiveImageWhileHovering = true;
            this.exit_txt.Click += new System.EventHandler(this.exit_btn_Click);
            this.exit_txt.DoubleClick += new System.EventHandler(this.exit_btn_Click);
            // 
            // appTitle_txt
            // 
            this.appTitle_txt.AutoSize = true;
            this.appTitle_txt.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appTitle_txt.Location = new System.Drawing.Point(10, 2);
            this.appTitle_txt.Name = "appTitle_txt";
            this.appTitle_txt.Size = new System.Drawing.Size(113, 20);
            this.appTitle_txt.TabIndex = 0;
            this.appTitle_txt.Text = "System Monitor";
            // 
            // nav_panel
            // 
            this.nav_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.nav_panel.Controls.Add(this.settings_btn);
            this.nav_panel.Controls.Add(this.remote_btn);
            this.nav_panel.Controls.Add(this.gpu_btn);
            this.nav_panel.Controls.Add(this.ram_btn);
            this.nav_panel.Controls.Add(this.cpu_btn);
            this.nav_panel.Controls.Add(this.dashboard_btn);
            this.nav_panel.Controls.Add(this.drawer_brn);
            this.nav_panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.nav_panel.Location = new System.Drawing.Point(2, 33);
            this.nav_panel.Margin = new System.Windows.Forms.Padding(0);
            this.nav_panel.Name = "nav_panel";
            this.nav_panel.Size = new System.Drawing.Size(200, 513);
            this.nav_panel.TabIndex = 1;
            // 
            // settings_btn
            // 
            this.settings_btn.ActiveColor = System.Drawing.Color.Empty;
            this.settings_btn.ActiveImage = global::SystemMonitor.Properties.Resources.settings_highlited_ic;
            this.settings_btn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.settings_btn.BackColor = System.Drawing.SystemColors.Control;
            this.settings_btn.Dock = System.Windows.Forms.DockStyle.Top;
            this.settings_btn.DrawImage = true;
            this.settings_btn.DrawText = true;
            this.settings_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.settings_btn.Image = global::SystemMonitor.Properties.Resources.settings_light_ic;
            this.settings_btn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.settings_btn.IsTab = true;
            this.settings_btn.Location = new System.Drawing.Point(0, 288);
            this.settings_btn.Name = "settings_btn";
            this.settings_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.settings_btn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.settings_btn.Selected = false;
            this.settings_btn.Size = new System.Drawing.Size(200, 48);
            this.settings_btn.TabIndex = 5;
            this.settings_btn.Text = "Settings";
            this.settings_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.settings_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.settings_btn.UseActiveImageWhileHovering = true;
            this.settings_btn.Click += new System.EventHandler(this.nav_click);
            this.settings_btn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // remote_btn
            // 
            this.remote_btn.ActiveColor = System.Drawing.Color.Empty;
            this.remote_btn.ActiveImage = global::SystemMonitor.Properties.Resources.remote_highlited_ic;
            this.remote_btn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.remote_btn.BackColor = System.Drawing.SystemColors.Control;
            this.remote_btn.Dock = System.Windows.Forms.DockStyle.Top;
            this.remote_btn.DrawImage = true;
            this.remote_btn.DrawText = true;
            this.remote_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.remote_btn.Image = ((System.Drawing.Image)(resources.GetObject("remote_btn.Image")));
            this.remote_btn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.remote_btn.IsTab = true;
            this.remote_btn.Location = new System.Drawing.Point(0, 240);
            this.remote_btn.Name = "remote_btn";
            this.remote_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.remote_btn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.remote_btn.Selected = false;
            this.remote_btn.Size = new System.Drawing.Size(200, 48);
            this.remote_btn.TabIndex = 4;
            this.remote_btn.Text = "Remote Monitoring";
            this.remote_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.remote_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.remote_btn.UseActiveImageWhileHovering = true;
            this.remote_btn.Click += new System.EventHandler(this.nav_click);
            this.remote_btn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // gpu_btn
            // 
            this.gpu_btn.ActiveColor = System.Drawing.Color.Empty;
            this.gpu_btn.ActiveImage = global::SystemMonitor.Properties.Resources.gpu_highlited_ic;
            this.gpu_btn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.gpu_btn.BackColor = System.Drawing.SystemColors.Control;
            this.gpu_btn.Dock = System.Windows.Forms.DockStyle.Top;
            this.gpu_btn.DrawImage = true;
            this.gpu_btn.DrawText = true;
            this.gpu_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.gpu_btn.Image = global::SystemMonitor.Properties.Resources.gpu_light_ic;
            this.gpu_btn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.gpu_btn.IsTab = true;
            this.gpu_btn.Location = new System.Drawing.Point(0, 192);
            this.gpu_btn.Name = "gpu_btn";
            this.gpu_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.gpu_btn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.gpu_btn.Selected = false;
            this.gpu_btn.Size = new System.Drawing.Size(200, 48);
            this.gpu_btn.TabIndex = 3;
            this.gpu_btn.Text = "GPU";
            this.gpu_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.gpu_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.gpu_btn.UseActiveImageWhileHovering = true;
            this.gpu_btn.Click += new System.EventHandler(this.nav_click);
            this.gpu_btn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // ram_btn
            // 
            this.ram_btn.ActiveColor = System.Drawing.Color.Empty;
            this.ram_btn.ActiveImage = global::SystemMonitor.Properties.Resources.ram_highlited_ic;
            this.ram_btn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.ram_btn.BackColor = System.Drawing.SystemColors.Control;
            this.ram_btn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ram_btn.DrawImage = true;
            this.ram_btn.DrawText = true;
            this.ram_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.ram_btn.Image = ((System.Drawing.Image)(resources.GetObject("ram_btn.Image")));
            this.ram_btn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.ram_btn.IsTab = true;
            this.ram_btn.Location = new System.Drawing.Point(0, 144);
            this.ram_btn.Name = "ram_btn";
            this.ram_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.ram_btn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.ram_btn.Selected = false;
            this.ram_btn.Size = new System.Drawing.Size(200, 48);
            this.ram_btn.TabIndex = 2;
            this.ram_btn.Text = "RAM";
            this.ram_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ram_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.ram_btn.UseActiveImageWhileHovering = true;
            this.ram_btn.Click += new System.EventHandler(this.nav_click);
            this.ram_btn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // cpu_btn
            // 
            this.cpu_btn.ActiveColor = System.Drawing.Color.Empty;
            this.cpu_btn.ActiveImage = global::SystemMonitor.Properties.Resources.cpu_highlited_ic;
            this.cpu_btn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.cpu_btn.BackColor = System.Drawing.SystemColors.Control;
            this.cpu_btn.Dock = System.Windows.Forms.DockStyle.Top;
            this.cpu_btn.DrawImage = true;
            this.cpu_btn.DrawText = true;
            this.cpu_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.cpu_btn.Image = global::SystemMonitor.Properties.Resources.cpu_light_ic;
            this.cpu_btn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.cpu_btn.IsTab = true;
            this.cpu_btn.Location = new System.Drawing.Point(0, 96);
            this.cpu_btn.Name = "cpu_btn";
            this.cpu_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.cpu_btn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.cpu_btn.Selected = false;
            this.cpu_btn.Size = new System.Drawing.Size(200, 48);
            this.cpu_btn.TabIndex = 1;
            this.cpu_btn.Text = "CPU";
            this.cpu_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cpu_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.cpu_btn.UseActiveImageWhileHovering = true;
            this.cpu_btn.Click += new System.EventHandler(this.nav_click);
            this.cpu_btn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // dashboard_btn
            // 
            this.dashboard_btn.ActiveColor = System.Drawing.Color.Empty;
            this.dashboard_btn.ActiveImage = global::SystemMonitor.Properties.Resources.dashboard_highlited_ic;
            this.dashboard_btn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.dashboard_btn.Dock = System.Windows.Forms.DockStyle.Top;
            this.dashboard_btn.DrawImage = true;
            this.dashboard_btn.DrawText = true;
            this.dashboard_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.dashboard_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.dashboard_btn.Image = global::SystemMonitor.Properties.Resources.dashboard_light_ic;
            this.dashboard_btn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.dashboard_btn.IsTab = true;
            this.dashboard_btn.Location = new System.Drawing.Point(0, 48);
            this.dashboard_btn.Name = "dashboard_btn";
            this.dashboard_btn.OnHoverColor = System.Drawing.Color.Empty;
            this.dashboard_btn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.dashboard_btn.Selected = true;
            this.dashboard_btn.Size = new System.Drawing.Size(200, 48);
            this.dashboard_btn.TabIndex = 0;
            this.dashboard_btn.Text = "Dashboard";
            this.dashboard_btn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard_btn.TextOffset = new System.Drawing.Point(0, 0);
            this.dashboard_btn.UseActiveImageWhileHovering = true;
            this.dashboard_btn.Click += new System.EventHandler(this.nav_click);
            this.dashboard_btn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // drawer_brn
            // 
            this.drawer_brn.ActiveColor = System.Drawing.Color.Empty;
            this.drawer_brn.ActiveImage = global::SystemMonitor.Properties.Resources.hamburger_highlited_ic;
            this.drawer_brn.ActiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.drawer_brn.BackColor = System.Drawing.SystemColors.Control;
            this.drawer_brn.Dock = System.Windows.Forms.DockStyle.Top;
            this.drawer_brn.DrawImage = true;
            this.drawer_brn.DrawText = true;
            this.drawer_brn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.drawer_brn.Image = global::SystemMonitor.Properties.Resources.hamburger_light_ic;
            this.drawer_brn.ImageSize = new System.Drawing.SizeF(23F, 23F);
            this.drawer_brn.IsTab = false;
            this.drawer_brn.Location = new System.Drawing.Point(0, 0);
            this.drawer_brn.Name = "drawer_brn";
            this.drawer_brn.OnHoverColor = System.Drawing.Color.Empty;
            this.drawer_brn.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.drawer_brn.Selected = false;
            this.drawer_brn.Size = new System.Drawing.Size(200, 48);
            this.drawer_brn.TabIndex = 6;
            this.drawer_brn.TextAligment = System.Drawing.ContentAlignment.MiddleLeft;
            this.drawer_brn.TextOffset = new System.Drawing.Point(0, 0);
            this.drawer_brn.UseActiveImageWhileHovering = true;
            this.drawer_brn.Click += new System.EventHandler(this.nav_click);
            this.drawer_brn.DoubleClick += new System.EventHandler(this.nav_click);
            // 
            // dragControl
            // 
            this.dragControl.DraggableInnerControls = false;
            this.dragControl.Fixed = true;
            this.dragControl.MaximiseOnDoubleClick = true;
            this.dragControl.TargetControl = this.title_bar;
            // 
            // nav_adapter
            // 
            this.nav_adapter.Control = this.tab_holder;
            // 
            // tab_holder
            // 
            this.tab_holder.BackColor = System.Drawing.SystemColors.Window;
            this.tab_holder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_holder.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tab_holder.Location = new System.Drawing.Point(202, 81);
            this.tab_holder.Name = "tab_holder";
            this.tab_holder.Size = new System.Drawing.Size(844, 465);
            this.tab_holder.TabIndex = 3;
            // 
            // tray_ic
            // 
            this.tray_ic.BalloonTipText = "System Monitor";
            this.tray_ic.BalloonTipTitle = "System Monitor";
            this.tray_ic.ContextMenuStrip = this.tray_ic_menu;
            this.tray_ic.Icon = ((System.Drawing.Icon)(resources.GetObject("tray_ic.Icon")));
            this.tray_ic.Text = "System Monitor";
            this.tray_ic.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tray_ic_MouseDoubleClick);
            // 
            // tray_ic_menu
            // 
            this.tray_ic_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.tray_ic_menu.Name = "tray_ic_menu";
            this.tray_ic_menu.Size = new System.Drawing.Size(93, 26);
            this.tray_ic_menu.Click += new System.EventHandler(this.tray_ic_menu_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // drawer_anim
            // 
            this.drawer_anim.Controls = this.nav_panel;
            // 
            // tabTitle_txt
            // 
            this.tabTitle_txt.AutoSize = true;
            this.tabTitle_txt.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabTitle_txt.Location = new System.Drawing.Point(17, 12);
            this.tabTitle_txt.Name = "tabTitle_txt";
            this.tabTitle_txt.Size = new System.Drawing.Size(89, 21);
            this.tabTitle_txt.TabIndex = 0;
            this.tabTitle_txt.Text = "Dashboard";
            // 
            // tabTitle_panel
            // 
            this.tabTitle_panel.Controls.Add(this.tabTitle_txt);
            this.tabTitle_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabTitle_panel.Location = new System.Drawing.Point(202, 33);
            this.tabTitle_panel.Name = "tabTitle_panel";
            this.tabTitle_panel.Size = new System.Drawing.Size(844, 48);
            this.tabTitle_panel.TabIndex = 2;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1050, 550);
            this.Controls.Add(this.tab_holder);
            this.Controls.Add(this.tabTitle_panel);
            this.Controls.Add(this.nav_panel);
            this.Controls.Add(this.title_bar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 370);
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(2, 3, 4, 4);
            this.Text = "System Monitor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnFormClosing);
            this.SizeChanged += new System.EventHandler(this.OnSizeChanged);
            this.title_bar.ResumeLayout(false);
            this.title_bar.PerformLayout();
            this.nav_panel.ResumeLayout(false);
            this.tray_ic_menu.ResumeLayout(false);
            this.tabTitle_panel.ResumeLayout(false);
            this.tabTitle_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel title_bar;
        private System.Windows.Forms.Panel nav_panel;
        private FlatButton_WOC settings_btn;
        private FlatButton_WOC remote_btn;
        private FlatButton_WOC gpu_btn;
        private FlatButton_WOC ram_btn;
        private FlatButton_WOC cpu_btn;
        private FlatButton_WOC dashboard_btn;
        private FlatButton_WOC drawer_brn;
        private System.Windows.Forms.Label appTitle_txt;
        private DragControl_WOC dragControl;
        private TabsAdapter_WOC nav_adapter;
        private System.Windows.Forms.NotifyIcon tray_ic;
        private FlatButton_WOC exit_txt;
        private System.Windows.Forms.ContextMenuStrip tray_ic_menu;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private FlatButton_WOC minimise_btn;
        private FlatButton_WOC maximise_btn;
        private Animator_WOC drawer_anim;
        private System.Windows.Forms.Panel tab_holder;
        private System.Windows.Forms.Label tabTitle_txt;
        private System.Windows.Forms.Panel tabTitle_panel;
    }
}