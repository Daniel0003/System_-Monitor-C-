﻿namespace SystemMonitor
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.legend_WOC1 = new LimitlessUI.Legend_WOC();
            this.chart_WOC1 = new LimitlessUI.Chart_WOC();
            this.SuspendLayout();
            // 
            // legend_WOC1
            // 
            this.legend_WOC1.AutoExpand = false;
            this.legend_WOC1.AutoScroll = true;
            this.legend_WOC1.Chart = null;
            this.legend_WOC1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.legend_WOC1.Location = new System.Drawing.Point(0, 296);
            this.legend_WOC1.Name = "legend_WOC1";
            this.legend_WOC1.Size = new System.Drawing.Size(846, 40);
            this.legend_WOC1.TabIndex = 0;
            this.legend_WOC1.Text = "legend_WOC1";
            this.legend_WOC1.TextColor = System.Drawing.Color.Empty;
            this.legend_WOC1.Vertical = false;
            // 
            // chart_WOC1
            // 
            this.chart_WOC1.ChartLength = 100;
            this.chart_WOC1.ChartLineThikness = 3;
            this.chart_WOC1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart_WOC1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.chart_WOC1.LineThikness = 1;
            this.chart_WOC1.Location = new System.Drawing.Point(0, 0);
            this.chart_WOC1.MaxYValue = 100;
            this.chart_WOC1.MinYValue = 0;
            this.chart_WOC1.Name = "chart_WOC1";
            this.chart_WOC1.Padding = new System.Windows.Forms.Padding(30);
            this.chart_WOC1.Size = new System.Drawing.Size(846, 296);
            this.chart_WOC1.TabIndex = 1;
            this.chart_WOC1.Text = "chart_WOC1";
            this.chart_WOC1.ValueInterval = 50;
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.chart_WOC1);
            this.Controls.Add(this.legend_WOC1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(846, 336);
            this.ResumeLayout(false);

        }

        #endregion

        private LimitlessUI.Legend_WOC legend_WOC1;
        private LimitlessUI.Chart_WOC chart_WOC1;
    }
}
