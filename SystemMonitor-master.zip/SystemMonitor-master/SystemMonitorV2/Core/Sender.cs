﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Management;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using SystemMonitor;
using SystemMonitor.Core;

public class Sender
{
    private static Sender _instance;

    private readonly DataCollector _dataCollector;
    private List<string> _checkedItems = new List<string>();
    private volatile bool _run = true;


    public Sender(List<string> checkedItems, List<string> ids)
    {
        _dataCollector = DataCollector.Instance;
        _checkedItems = checkedItems;

        TCPServer.onConnect += OnConnect;
        TCPServer.onDataReceive += OnReceive;
        TCPServer.onDisconnect += OnDisconect;
        Restart();
    }


    public static Sender Instance => _instance ?? (_instance =
                                         new Sender(Settings.Default.listData.Split(',').ToList(),
                                             Settings.Default.ids.Split(',').ToList()));

    private void OnConnect(Socket socket) => Restart();

    private void OnDisconect(Socket socket) => _run = false;

    private void OnReceive(string message, byte[] bytes, int count)
    {
        Debug.WriteLine("Received: " + message);
        if (message.Contains(':'))
            Settings.Default.listData = message.Split(':')[1];
        else
        {
            AddSubData(message);
            SubDataKey = message;
        }
    }

    private void Send()
    {
        try
        {
            while (_run)
            {
                if (SubDataKey.Equals("clear"))
                    foreach (var item in _checkedItems)
                        SendMainData(item);
                else
                    SendSubdata(SubDataKey);

                Thread.Sleep(1000);
            }
        }
        catch (Exception ex)
        {
            _run = false;
            Debug.WriteLine(ex.ToString());
        }
    }

    public void Restart()
    {
        if (!_run)
        {
            _run = true;
            new Thread(Send).Start();
        }
    }

    private void sendOrder(List<string> list)
    {
        foreach (var listItem in list)
            TCPServer.broadcastln("addIds:" + listItem);
    }

    private void SendMainData(string item)
    {
        if (!item.Contains("Drive"))
            switch (item)
            {
                case "CPU":
                    TCPServer.broadcastln("00CPU-" + Math.Round(_dataCollector.CpuLoad.Last().Value) + "%-" +
                                          _dataCollector.CpuTemps.Last().Value + "C-" +
                                          Utils.StringToHex(
                                              Utils.GetColorPerTemp((int) _dataCollector.CpuTemps.Last().Value)) + "-" +
                                          Math.Round(_dataCollector.CpuLoad.Last().Value));
                    break;
                case "RAM":
                    TCPServer.broadcastln("01RAM-" + Math.Round(_dataCollector.UsedRam, 1) + "/" +
                                          Math.Round(_dataCollector.TotalRam, 1) + "GB---" +
                                          _dataCollector.UsedRamPrecentage);
                    break;
                case "GPU":
                    TCPServer.broadcastln("0" + (2 + 0) + "GPU-" +
                                          Math.Round(Utils.AverageValue(_dataCollector.GpuCoreLoad)) + "%-" +
                                          Utils.AverageValue(_dataCollector.GpuTemps) + "C-" +
                                          Utils.StringToHex(Utils.GetColorPerTemp(Int32.Parse(Utils
                                              .AverageValue(_dataCollector.GpuTemps).ToString()))) + "-" +
                                          Math.Round(Utils.AverageValue(_dataCollector.GpuCoreLoad)));
                    break;
            }
        else
            for (int i = 0; i < _dataCollector.DriveData.Count; i++)
                if ("Drive: " + _dataCollector.DriveData.ElementAt(i)["Caption"] == item)
                    TCPServer.broadcastln("0" + (6 + i) + "Drive " +
                                          _dataCollector.DriveData.ElementAt(i)["Caption"].Remove(1) + "-" +
                                          _dataCollector.DriveData.ElementAt(i)["Used Space"] + "/" +
                                          _dataCollector.DriveData.ElementAt(i)["Size"] + "GB---" +
                                          _dataCollector.DriveData.ElementAt(i)["Load"] + "-N");
    }

    private void SendSubdata(string key)
    {
        switch (key)
        {
            case "CPU":
                int coresCount = _dataCollector.CpuLoad.Count;
                for (int i = 0; i < coresCount; i++)
                    TCPServer.broadcastln("2" + i + _dataCollector.CpuLoad.ElementAt(i).Value + "-" +
                                          _dataCollector.CpuTemps.ElementAt(i).Value);
                break;
            case "RAM":
                TCPServer.broadcastln("20" + _dataCollector.UsedRamPrecentage);
                break;
            case "GPU":
                TCPServer.broadcastln("20" + _dataCollector.GpuCoreLoad.First().Value + "-" +
                                      _dataCollector.GpuTemps.First().Value + Environment.NewLine + "21" +
                                      _dataCollector.GpuCoreClock.First().Value + "-" +
                                      _dataCollector.GpuMemoryClock.First().Value);
                break;
        }
    }

    private void SendStaticSubData(String key)
    {
        switch (key)
        {
            case "CPU":
                int coresCount = _dataCollector.CpuLoad.Count + 1;
                foreach (string value in _dataCollector.CpuData.Values)
                    TCPServer.broadcastln("setSubData:" + coresCount++ + "-" + value);

                break;
            case "RAM":
                break;
            case "GPU":
                break;
        }
    }

    public void AddSubData(String key)
    {
        _dataCollector.OpenComputerThread.Join();
        switch (key)
        {
            case "CPU":
                int coreCount = _dataCollector.CpuLoad.Count;

                for (int i = 0; i < coreCount - 1; i++)
                    TCPServer.broadcastln("11CPU Core #" + i + "-1111FF-FF1111");
                TCPServer.broadcastln("11CPU Total-1111FF-FF1111");
                break;
            case "RAM":
                TCPServer.broadcastln("11Memory Usage (%)-1111FF");
                break;
            case "GPU":
                TCPServer.broadcastln("11GPU-1111FF-FF1111");
                TCPServer.broadcastln("11Clocks-1111FF-11FF11");
                break;
        }


        //  foreach (String key in dataCollector.cpuData.Keys)
        //      cpuMessage += "-" + key + ",false";
        /*
                    TCPServer.broadcastln(cpuMessage);
                    TCPServer.broadcastln("addSubData:Memory Usage (%),true");

                    foreach (ManagementObject queryObj in Win32_VideoController.Get())
                        TCPServer.broadcastln("addSubData:GPU,true-Clocks,true");
                        */
    }

    public void SetCheckedItems(List<string> items)
    {
        this._checkedItems = items;
    }

    public string SubDataKey { get; set; } = "clear";
}