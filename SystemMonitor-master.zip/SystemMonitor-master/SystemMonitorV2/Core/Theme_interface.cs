﻿
namespace SystemMonitor.Core
{
    internal interface IThemeChanger
    {
        void ThemeChanged(bool isLight);
    }
}
