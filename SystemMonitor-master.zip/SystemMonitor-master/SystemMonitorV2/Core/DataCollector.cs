﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;
using OpenHardwareMonitor.Hardware;

namespace SystemMonitor.Core
{
    public class DataCollector
    {
        #region Batch of variables

        private readonly Computer _computer = new Computer()
        {
            CPUEnabled = true,
            GPUEnabled = true,
            RAMEnabled = true,
            HDDEnabled = true
        };

        public SortedDictionary<string, float> CpuLoad = new SortedDictionary<string, float>();
        public SortedDictionary<string, sbyte> CpuTemps = new SortedDictionary<string, sbyte>();
        public SortedDictionary<string, ushort> CpuClocks = new SortedDictionary<string, ushort>();
        public SortedDictionary<string, byte> CpuPowers = new SortedDictionary<string, byte>();

        public byte UsedRamPrecentage;
        public float UsedRam;
        public float TotalRam;

        public SortedDictionary<string, ushort> GpuCoreClock = new SortedDictionary<string, ushort>();
        public SortedDictionary<string, ushort> GpuMemoryClock = new SortedDictionary<string, ushort>();
        public SortedDictionary<string, ushort> GpuShaderClock = new SortedDictionary<string, ushort>();
        public SortedDictionary<string, float> GpuCoreLoad = new SortedDictionary<string, float>();
        public SortedDictionary<string, float> GpuMemoryLoad = new SortedDictionary<string, float>();
        public SortedDictionary<string, float> GpuMemoryFree = new SortedDictionary<string, float>();
        public SortedDictionary<string, float> GpuMemoryUsed = new SortedDictionary<string, float>();
        public SortedDictionary<string, float> GpuMemoryTotal = new SortedDictionary<string, float>();
        public SortedDictionary<string, int> GpuTemps = new SortedDictionary<string, int>();

        public SortedDictionary<string, string> CpuData = new SortedDictionary<string, string>();
        public List<SortedDictionary<string, string>> RamData = new List<SortedDictionary<string, string>>();
        public List<SortedDictionary<string, string>> GpuData = new List<SortedDictionary<string, string>>();
        public List<SortedDictionary<string, string>> DriveData = new List<SortedDictionary<string, string>>();


        public ManualResetEvent DataCollected = new ManualResetEvent(false);
        public ManualResetEvent DriveDataCollected = new ManualResetEvent(false);

        public Thread OpenComputerThread;
        private Timer _refreshTimer;
        private bool _run = true;
        public Task CpuTask, RamTask, GpuTask;
        private static DataCollector _instance;

        #endregion

        public DataCollector()
        {
            OpenComputerThread = new Thread(_computer.Open)
            {
                Priority = ThreadPriority.Highest
            };
            OpenComputerThread.Start();


            CpuTask = Task.Run(() => { LoadCpuSpecs(); });
            RamTask = Task.Run(() => { LoadRamSpecs(); });
            GpuTask = Task.Run(() => { LoadGpuSpecs(); });

            Task.Run(() =>
            {
                OpenComputerThread.Join();

                _refreshTimer = new Timer(state =>
                {
                    UpdateDriveData();
                    RefreshData();
                }, null, 0, 1000);
            });
        }


        public void UpdateDriveData()
        {
            if (_run)
            {
                DriveData.Clear();
                foreach (var queryObj in SearchIn("Win32_LogicalDisk"))
                foreach (var property in queryObj.Properties)
                    if (property.Value != null && !Const.DRIVE_IGNORE.Contains(property.Name))
                        if (property.Name.Equals("Caption"))
                        {
                            DriveData.Add(new SortedDictionary<string, string>());
                            DriveData.Last().Add("Caption", property.Value.ToString());
                        }
                        else if (property.Name.Equals("Size"))
                        {
                            DriveData.Last()
                                .Add("Size", Math.Round(Convert.ToDouble(property.Value) / 1073741824, 2).ToString());
                            DriveData.Last()
                                .Add("Used Space",
                                    Math.Round(Convert.ToDouble(property.Value) / 1073741824 -
                                               Convert.ToDouble(DriveData.Last()["FreeSpace"]), 2).ToString());
                            DriveData.Last()
                                .Add("Load",
                                    Math.Round(float.Parse(DriveData.Last()["Used Space"]) /
                                               float.Parse(DriveData.Last()["Size"]) * 100).ToString());
                        }
                        else if (property.Name.Equals("DriveType"))
                            DriveData.Last().Add(property.Name,
                                Const.DRIVE_TYPES[int.Parse(property.Value.ToString())]);
                        else if (property.Name.Equals("FreeSpace"))
                            DriveData.Last().Add("FreeSpace",
                                (Convert.ToDouble(property.Value) / 1073741824).ToString());
                DriveDataCollected.Set();
            }
        }

        public void LoadCpuSpecs()
        {
            foreach (var queryObj in SearchIn("Win32_Processor"))
            foreach (var property in queryObj.Properties)
                if (property.Value != null && !Const.CPU_IGNORE.Contains(property.Name))
                {
                    if (property.Name.Contains("Speed") || property.Name.Contains("Clock"))
                        CpuData.Add(property.Name, property.Value + "Mhz");
                    else if (property.Name.Contains("Size"))
                        CpuData.Add(property.Name, property.Value + "KB");
                    else
                        CpuData.Add(property.Name, property.Value.ToString());
                }
        }

        public void LoadRamSpecs()
        {
            foreach (var queryObj in SearchIn("Win32_PhysicalMemory"))
            foreach (var property in queryObj.Properties)
                if (property.Value != null && !Const.RAM_IGNORE.Contains(property.Name))
                    if (property.Name.Contains("BankLabel"))
                    {
                        RamData.Add(new SortedDictionary<string, string>());
                        RamData.Last().Add(property.Name, property.Value.ToString());
                    }
                    else if (property.Name.Contains("Voltage"))
                        RamData.Last().Add(property.Name, property.Value + "V");
                    else if (property.Name.Contains("Width"))
                        RamData.Last().Add(property.Name, property.Value + "Bit");
                    else if (property.Name.Contains("Speed"))
                        RamData.Last().Add(property.Name, property.Value + "Mhz");
                    else if (property.Name.Equals("Capacity"))
                        RamData.Last().Add(property.Name, long.Parse(property.Value.ToString()) / 1048576 + "MB");
                    else
                        RamData.Last().Add(property.Name, property.Value.ToString());
        }

        public void LoadGpuSpecs()
        {
            foreach (var queryObj in SearchIn("Win32_VideoController"))
            foreach (var property in queryObj.Properties)
                if (property.Value != null && !Const.GPU_IGNORE.Contains(property.Name))
                {
                    if (property.Name.Equals("AdapterRAM"))
                    {
                        GpuData.Add(new SortedDictionary<string, string>());
                        GpuData.Last().Add(property.Name,
                            (long.Parse(property.Value.ToString()) / 1048576) + "MB");
                    }
                    else if (property.Name.Contains("Rate"))
                        GpuData.Last().Add(property.Name, property.Value + "Hz");
                    else if (property.Name.Contains("Bit"))
                        GpuData.Last().Add(property.Name, property.Value + "Bit");
                    else
                        GpuData.Last().Add(property.Name, property.Value.ToString());
                }
        }

        public void RefreshData()
        {
            foreach (var hardwareItem in _computer.Hardware)
            {
                if (hardwareItem.HardwareType == HardwareType.CPU)
                {
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Clock)
                            CpuClocks[sensor.Name] = (ushort) sensor.Value.Value;
                        else if (sensor.SensorType == SensorType.Temperature)
                            CpuTemps[sensor.Name] = (sbyte) (sensor.Value ?? 0);
                        else if (sensor.SensorType == SensorType.Load)
                            CpuLoad[sensor.Name] = sensor.Value.Value;
                        else if (sensor.SensorType == SensorType.Power)
                            CpuPowers[sensor.Name] = (byte) sensor.Value.Value;
                    }
                }

                if (hardwareItem.HardwareType == HardwareType.RAM)
                {
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                        if (sensor.SensorType == SensorType.Load)
                            UsedRamPrecentage = (byte) sensor.Value.Value;
                        else if (sensor.SensorType == SensorType.Data)
                            if (sensor.Name.Equals("Used Memory"))
                                UsedRam = sensor.Value.Value;
                            else
                                TotalRam = UsedRam + sensor.Value.Value;
                }

                if (hardwareItem.HardwareType == HardwareType.GpuNvidia ||
                    hardwareItem.HardwareType == HardwareType.GpuAti)
                {
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                        if (sensor.SensorType == SensorType.Clock)
                        {
                            if (sensor.Name == "GPU Core")
                                GpuCoreClock[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                            if (sensor.Name == "GPU Memory")
                                GpuMemoryClock[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                            if (sensor.Name == "GPU Shader")
                                GpuShaderClock[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                        }
                        else if (sensor.SensorType == SensorType.Temperature)
                            GpuTemps[hardwareItem.Name] = (byte) (sensor.Value ?? 0);
                        else if (sensor.SensorType == SensorType.Load)
                        {
                            if (sensor.Name == "GPU Core")
                                GpuCoreLoad[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                            if (sensor.Name == "GPU Memory")
                                GpuMemoryLoad[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                        }
                        else if (sensor.SensorType == SensorType.Data)
                        {
                            if (sensor.Name == "GPU Memory Free")
                                GpuCoreLoad[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                            if (sensor.Name == "GPU Memory Used")
                                GpuMemoryLoad[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                            if (sensor.Name == "GPU Memory Total")
                                GpuMemoryLoad[hardwareItem.Name] = (ushort) (sensor.Value ?? 0);
                        }
                }
            }
            DataCollected.Set();
        }

        public string CpuName
        {
            get
            {
                var processorName = Registry.LocalMachine.OpenSubKey(@"Hardware\Description\System\CentralProcessor\0",
                    RegistryKeyPermissionCheck.ReadSubTree); //Processor info entry.
                if (processorName != null) return processorName.GetValue("ProcessorNameString").ToString();
                return "";
            }
        }

        public static DataCollector Instance => _instance ?? (_instance = new DataCollector());

        public void Stop()
        {
            _run = false;
            _refreshTimer.Dispose();
        }

        private ManagementObjectCollection SearchIn(string where) => new ManagementObjectSearcher("root\\CIMV2",
            "Select * from " + where).Get();
    }
}