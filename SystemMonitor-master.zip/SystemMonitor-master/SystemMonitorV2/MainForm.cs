﻿using LimitlessUI;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Net.Sockets;
using System.Windows.Forms;
using SystemMonitor.Core;
using SystemMonitor.Properties;
using SystemMonitor.Tabs;

namespace SystemMonitor
{
    public partial class MainForm : Form_WOC
    {
        private bool _isDrawerExpanded = true;

        public static MainForm Instance;

        public MainForm()
        {
            Instance = this;
            Utils_WOC._threadsForm = this;

            InitializeComponent();
            SetupNavigation();
            HideBorders(0);

            TCPServer.onConnect += OnConnect;
            TCPServer.onDisconnect +=
                (socket) => Utils.ShowNotification(tray_ic, "System Monitor", "Client disconected",
                    ToolTipIcon.None);


            if (!Settings.Default.lightTheme)
                SetTheme(false);

            if (!Settings.Default.drawerExpanded)
                nav_panel.Width = 48;
            if (Settings.Default.runServer)
                TCPServer.startListeningInSeperateThread(4444, 2);
        }


        public void SetTheme(bool isLight)
        {
            var images = isLight
                ? new[]
                {
                    Resources.dashboard_light_ic, Resources.cpu_light_ic, Resources.ram_light_ic,
                    Resources.gpu_light_ic, Resources.remote_light_ic, Resources.settings_light_ic,
                    Resources.hamburger_light_ic
                }
                : new[]
                {
                    Resources.dashboard_dark_ic, Resources.cpu_dark_ic, Resources.ram_dark_ic, Resources.gpu_dark_ic,
                    Resources.remote_dark_ic, Resources.settings_dark_ic, Resources.hamburger_dark_ic
                };

            foreach (FlatButton_WOC button in nav_panel.Controls)
            {
                button.BackColor = isLight ? Theme.Default.nav_light : Theme.Default.nav_dark;
                button.DefaultBackColor = isLight ? Theme.Default.nav_light : Theme.Default.nav_dark;


                if (!button.Selected)
                    button.ForeColor = isLight ? Color.Black : Color.White;
                else button.DefaultForeColor = isLight ? Color.Black : Color.White;

                button.Image = images[button.TabIndex];
            }

            foreach (var tab in nav_adapter.Tabs)
            {
                tab.BackColor = isLight ? Theme.Default.background_light : Theme.Default.background_dark;
                (tab as IThemeChanger)?.ThemeChanged(isLight);
            }

            BackColor = isLight ? Theme.Default.background_light : Theme.Default.background_dark;
            nav_panel.BackColor = isLight ? Theme.Default.nav_light : Theme.Default.nav_dark;
            tabTitle_panel.BackColor = isLight ? Theme.Default.background_light : Theme.Default.background_dark;
            tabTitle_txt.ForeColor = isLight ? Color.Black : Color.White;
            HideBorders(0);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            //     tab_holder.Height = Height - title_bar.Height - tabTitle_panel.Height - 7;
            //    tab_holder.Width = Width - nav_panel.Width  - 5;
            Debug.WriteLine("OnSizeChanged");
        }

        private void SetupNavigation()
        {
            SizeChanged += (sender, e) => HideBorders(0);
            tray_ic.Click += (sender, e) => Close();
            minimise_btn.Click += (sender, e) => WindowState = FormWindowState.Minimized;

            drawer_anim.OnAnimationStartDel += (control) => SuspendLayout();
            drawer_anim.OnAnimationEndDel += (control) => ResumeLayout();
            drawer_anim.OnWidthChangedDel += (control, change, progress) =>
            {
                //   tab_holder.Width += -(int)change;
                HideBorders(0);
                Invalidate();
            };

            nav_adapter.AddTab(Dashboard_Tab.Instance, true);
            nav_adapter.AddTab(CPU_Tab.Instance, false);
            nav_adapter.AddTab(RAM_Tab.Instance, false);
            nav_adapter.AddTab(GPU_Tab.Instance, false);
            nav_adapter.AddTab(RemoteMon_TAB.Instance, false);
            nav_adapter.AddTab(Settings_Tab.Instance, false);

            nav_adapter.ShowTab(0);
        }

        public void HideBorders(int bottomExpanction)
        {
            ClearLines();
            DrawLine(LinePositions.Top, title_bar.BackColor, 0, Width);
            DrawLine(LinePositions.Left, title_bar.BackColor, 0, title_bar.Height + 3);
            DrawLine(LinePositions.Left, Settings.Default.lightTheme ? nav_panel.BackColor : Theme.Default.nav_dark,
                title_bar.Height + 4, Height);
            DrawLine(LinePositions.Right, title_bar.BackColor, 0, title_bar.Height + 3);
            DrawLine(LinePositions.Bottom, Settings.Default.lightTheme ? nav_panel.BackColor : Theme.Default.nav_dark,
                0, nav_panel.Width + 2 + bottomExpanction);
            Invalidate();
        }


        private void OnConnect(Socket socket)
        {
            RemoteMon_TAB.Instance.Client = socket.RemoteEndPoint.ToString().Split(':')[0];
            Utils.ShowNotification(tray_ic, "Remote Monitor",
                "Client " + socket.RemoteEndPoint.ToString().Split(':')[0] + " connected.", ToolTipIcon.None);
        }


        private void NavClick(object sender, EventArgs e)
        {
            if (((FlatButton_WOC) sender).TabIndex == 6)
            {
                IsDrawerExpanded = !_isDrawerExpanded;
                return;
            }
            nav_adapter.ShowTab(((FlatButton_WOC) sender).TabIndex);
            tabTitle_txt.Text = ((FlatButton_WOC) sender).Text;
        }

        public void LoadTab(int tab)
        {
            nav_adapter.ShowTab(tab);
            if (tab == 0)
            {
                tabTitle_txt.Text = "Dashboard";
                dashboard_btn.Selected = true;
            }
            if (tab == 1)
            {
                tabTitle_txt.Text = "CPU";
                cpu_btn.Selected = true;
            }
            if (tab == 2)
            {
                tabTitle_txt.Text = "RAM";
                ram_btn.Selected = true;
            }
            if (tab == 3)
            {
                tabTitle_txt.Text = "GPU";
                gpu_btn.Selected = true;
            }
            if (tab == 4)
            {
                tabTitle_txt.Text = "Remote Monitoring";
                remote_btn.Selected = true;
            }
            if (tab == 5)
            {
                tabTitle_txt.Text = "Settings";
                settings_btn.Selected = true;
            }
        }

        private void ExitClick(object sender, EventArgs e)
        {
            if (!Settings.Default.minimiseOnExit)
                Close();
            else
            {
                WindowState = FormWindowState.Minimized;
                ShowInTaskbar = false;
                tray_ic.Visible = true;
                Hide();
            }
        }

        private void TrayDoubleClick(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Normal;
            ShowInTaskbar = true;
            Show();

            TopMost = true;
            Focus();
            BringToFront();
            TopMost = false;
            tray_ic.Visible = false;
        }


        private void maximise_btn_Click(object sender, EventArgs e)
        {
            WindowState = WindowState == FormWindowState.Normal
                ? FormWindowState.Maximized
                : FormWindowState.Normal;
            maximise_btn.Image = WindowState == FormWindowState.Normal
                ? Resources.maximise_light_ic
                : Resources.maximise2_light_ic;
            maximise_btn.ActiveImage = WindowState == FormWindowState.Normal
                ? Resources.maximise_hover_ic
                : Resources.maximise2_hover_ic;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            DataCollector.Instance.Stop();
            TCPServer.closeServer();
            Settings.Default.drawerExpanded = _isDrawerExpanded;
            Settings.Default.Save();
        }

        public bool IsDrawerExpanded
        {
            get => _isDrawerExpanded;
            set
            {
                drawer_anim.Animate(150, !value ? 48 : 200);
                _isDrawerExpanded = value;
            }
        }
    }
}