﻿namespace SystemMonitor.Fragments
{
    partial class VerticalLabels
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.memoryClockLabel = new System.Windows.Forms.Label();
            this.coreClockLabel = new System.Windows.Forms.Label();
            this.tempLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.loadLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // memoryClockLabel
            // 
            this.memoryClockLabel.AutoSize = true;
            this.memoryClockLabel.Font = new System.Drawing.Font("Segoe UI Semilight", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memoryClockLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.memoryClockLabel.Location = new System.Drawing.Point(0, 100);
            this.memoryClockLabel.Name = "memoryClockLabel";
            this.memoryClockLabel.Size = new System.Drawing.Size(0, 20);
            this.memoryClockLabel.TabIndex = 23;
            // 
            // coreClockLabel
            // 
            this.coreClockLabel.AutoSize = true;
            this.coreClockLabel.Font = new System.Drawing.Font("Segoe UI Semilight", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coreClockLabel.Location = new System.Drawing.Point(0, 75);
            this.coreClockLabel.Name = "coreClockLabel";
            this.coreClockLabel.Size = new System.Drawing.Size(0, 20);
            this.coreClockLabel.TabIndex = 22;
            // 
            // tempLabel
            // 
            this.tempLabel.AutoSize = true;
            this.tempLabel.Font = new System.Drawing.Font("Segoe UI Semilight", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tempLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tempLabel.Location = new System.Drawing.Point(13, 50);
            this.tempLabel.Name = "tempLabel";
            this.tempLabel.Size = new System.Drawing.Size(44, 20);
            this.tempLabel.TabIndex = 21;
            this.tempLabel.Text = "temp";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Segoe UI Semilight", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(0, 0);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(0, 20);
            this.nameLabel.TabIndex = 20;
            // 
            // loadLabel
            // 
            this.loadLabel.AutoSize = true;
            this.loadLabel.Font = new System.Drawing.Font("Segoe UI Semilight", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadLabel.Location = new System.Drawing.Point(0, 25);
            this.loadLabel.Name = "loadLabel";
            this.loadLabel.Size = new System.Drawing.Size(0, 20);
            this.loadLabel.TabIndex = 19;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.ForeColor = System.Drawing.Color.Coral;
            this.panel1.Location = new System.Drawing.Point(4, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(9, 9);
            this.panel1.TabIndex = 24;
            // 
            // VerticalLabels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.memoryClockLabel);
            this.Controls.Add(this.coreClockLabel);
            this.Controls.Add(this.tempLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.loadLabel);
            this.Name = "VerticalLabels";
            this.Size = new System.Drawing.Size(98, 120);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label memoryClockLabel;
        private System.Windows.Forms.Label coreClockLabel;
        private System.Windows.Forms.Label tempLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label loadLabel;
        private System.Windows.Forms.Panel panel1;
    }
}
