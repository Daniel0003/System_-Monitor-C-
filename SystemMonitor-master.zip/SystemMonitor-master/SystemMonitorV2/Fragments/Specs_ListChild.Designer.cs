﻿namespace SystemMonitor.Fragments
{
    partial class Specs_ListChild
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.parameterValue = new System.Windows.Forms.Label();
            this.parameterName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // parameterValue
            // 
            this.parameterValue.AutoSize = true;
            this.parameterValue.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.parameterValue.ForeColor = System.Drawing.Color.Black;
            this.parameterValue.Location = new System.Drawing.Point(276, 1);
            this.parameterValue.Name = "parameterValue";
            this.parameterValue.Size = new System.Drawing.Size(49, 21);
            this.parameterValue.TabIndex = 4;
            this.parameterValue.Text = "label1";
            // 
            // parameterName
            // 
            this.parameterName.AutoSize = true;
            this.parameterName.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.parameterName.ForeColor = System.Drawing.Color.DimGray;
            this.parameterName.Location = new System.Drawing.Point(1, 2);
            this.parameterName.Name = "parameterName";
            this.parameterName.Size = new System.Drawing.Size(218, 20);
            this.parameterName.TabIndex = 3;
            this.parameterName.Text = "Number Of Logical Processors:";
            // 
            // Specs_ListChild
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.parameterValue);
            this.Controls.Add(this.parameterName);
            this.Name = "Specs_ListChild";
            this.Size = new System.Drawing.Size(536, 26);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label parameterValue;
        private System.Windows.Forms.Label parameterName;
    }
}
