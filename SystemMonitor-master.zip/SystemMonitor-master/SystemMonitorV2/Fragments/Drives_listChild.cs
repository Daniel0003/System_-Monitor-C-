﻿using System.Drawing;
using System.Windows.Forms;

namespace SystemMonitor.Fragments
{
    public partial class Drives_listChild : UserControl
    {
        public Drives_listChild(string driveLabel, int progress, string driveUsed)
        {
            InitializeComponent();
            driveTxt.Text = "Drive " + driveLabel;
            driveUsed_txt.Text = driveUsed;
            drive_load.Value = progress;
        }

        public void Update(string driveLabel, int progress, string driveUsed)
        {
            driveTxt.Text = "Drive " + driveLabel + ":";
            driveUsed_txt.Text = driveUsed;
            drive_load.Value = progress;
        }

        public void ChangeTheme(bool isLight)
        {
            driveTxt.ForeColor = isLight ? Color.Black : Color.White;
            driveUsed_txt.ForeColor = isLight ? Color.Black : Color.White;
            drive_load.ProgressBackColor = isLight ? Theme.Default.controlsBG_light : Theme.Default.controlsBG_dark;
        }

        public void Redraw() => drive_load.Invalidate();
    }
}