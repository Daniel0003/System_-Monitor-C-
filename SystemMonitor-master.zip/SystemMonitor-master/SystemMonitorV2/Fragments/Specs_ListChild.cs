﻿using System.Drawing;
using System.Windows.Forms;

namespace SystemMonitor.Fragments
{
    public partial class Specs_ListChild : UserControl
    {
        public Specs_ListChild()
        {
            InitializeComponent();
        }

        public Specs_ListChild(string name, string value, int fontSize)
        {
            InitializeComponent();
            parameterName.Text = name;
            parameterValue.Text = value;
            // parameterName.Font.Size = fontSize;
        }

        public bool IsLightTheme
        {
            set =>parameterValue.ForeColor = value ? Color.Black : Color.White;
        }
    }
}