﻿using System.Windows.Forms;

namespace SystemMonitor.Fragments
{
    public partial class Chart_UC : UserControl
    {
        public Chart_UC()
        {
            InitializeComponent();

            SizeChanged += (a,b) => chart.Invalidate();
        }
    }
}
