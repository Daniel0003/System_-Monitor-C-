﻿using System.Drawing;
using System.Windows.Forms;

namespace SystemMonitor.Fragments
{
    public partial class VerticalLabels : UserControl
    {
        public VerticalLabels(string name)
        {
            InitializeComponent();
            nameLabel.Text = name.Replace("AMD Radeon ", "");
        }

        public VerticalLabels() => InitializeComponent();


        public void SetName(string name)
        {
            nameLabel.Text = name.Replace("AMD Radeon ", "");
        }

        public void SetValues(float load, int temp)
        {
            panel1.BackColor = Utils.GetColorPerTemp(temp);
            loadLabel.Text = load + "%";
            tempLabel.Text = temp + "°C";
        }

        public void SetValues(float load, int temp, int coreClock, int memoryClock)
        {
            panel1.BackColor = Utils.GetColorPerTemp(temp);
            loadLabel.Text = load + "%";
            tempLabel.Text = temp + "°C";
            coreClockLabel.Text = coreClock + "Mhz";
            memoryClockLabel.Text = memoryClock + "Mhz";
        }

        public bool IsLightTheme
        {
            set
            {
                loadLabel.ForeColor = value ? Color.Black : Color.White;
                tempLabel.ForeColor = value ? Color.Black : Color.White;
                coreClockLabel.ForeColor = value ? Color.Black : Color.White;
                memoryClockLabel.ForeColor = value ? Color.Black : Color.White;
                nameLabel.ForeColor = value ? Color.Black : Color.White;
            }
        }
    }
}