﻿using LimitlessUI;

namespace SystemMonitor.Fragments
{
    partial class Drives_listChild
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.drive_load = new LimitlessUI.ProgressBar_WOC();
            this.driveUsed_txt = new System.Windows.Forms.Label();
            this.driveTxt = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.drive_load);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(80, 4, 130, 0);
            this.panel1.Size = new System.Drawing.Size(809, 26);
            this.panel1.TabIndex = 8;
            // 
            // drive_load
            // 
            this.drive_load.BackLineThikness = 10F;
            this.drive_load.Dock = System.Windows.Forms.DockStyle.Fill;
            this.drive_load.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(255)))));
            this.drive_load.FrontLineThikness = 10F;
            this.drive_load.Location = new System.Drawing.Point(80, 4);
            this.drive_load.Name = "drive_load";
            this.drive_load.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.drive_load.Rounded = true;
            this.drive_load.Size = new System.Drawing.Size(599, 22);
            this.drive_load.Smooth = true;
            this.drive_load.TabIndex = 0;
            this.drive_load.Text = "progressBar_WOC1";
            this.drive_load.Value = 50;
            // 
            // driveUsed_txt
            // 
            this.driveUsed_txt.AutoSize = true;
            this.driveUsed_txt.Dock = System.Windows.Forms.DockStyle.Right;
            this.driveUsed_txt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driveUsed_txt.Location = new System.Drawing.Point(685, 0);
            this.driveUsed_txt.Margin = new System.Windows.Forms.Padding(0);
            this.driveUsed_txt.Name = "driveUsed_txt";
            this.driveUsed_txt.Padding = new System.Windows.Forms.Padding(0, 3, 10, 0);
            this.driveUsed_txt.Size = new System.Drawing.Size(124, 24);
            this.driveUsed_txt.TabIndex = 10;
            this.driveUsed_txt.Text = "540.2/100.4GB";
            // 
            // driveTxt
            // 
            this.driveTxt.AutoSize = true;
            this.driveTxt.Dock = System.Windows.Forms.DockStyle.Left;
            this.driveTxt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driveTxt.Location = new System.Drawing.Point(0, 0);
            this.driveTxt.Margin = new System.Windows.Forms.Padding(0);
            this.driveTxt.Name = "driveTxt";
            this.driveTxt.Padding = new System.Windows.Forms.Padding(10, 3, 0, 0);
            this.driveTxt.Size = new System.Drawing.Size(74, 24);
            this.driveTxt.TabIndex = 9;
            this.driveTxt.Text = "Drive C:";
            // 
            // Drives_listChild
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.driveUsed_txt);
            this.Controls.Add(this.driveTxt);
            this.Controls.Add(this.panel1);
            this.Name = "Drives_listChild";
            this.Size = new System.Drawing.Size(809, 26);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label driveUsed_txt;
        private System.Windows.Forms.Label driveTxt;
        private ProgressBar_WOC drive_load;
    }
}
