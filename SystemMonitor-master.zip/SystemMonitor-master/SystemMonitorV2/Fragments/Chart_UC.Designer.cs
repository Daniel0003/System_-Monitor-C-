﻿namespace SystemMonitor.Fragments
{
    partial class Chart_UC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.legend = new LimitlessUI.Legend_WOC();
            this.chart = new LimitlessUI.Chart_WOC();
            this.SuspendLayout();
            // 
            // legend
            // 
            this.legend.AutoExpand = false;
            this.legend.AutoScroll = true;
            this.legend.Chart = this.chart;
            this.legend.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.legend.Location = new System.Drawing.Point(0, 296);
            this.legend.Name = "legend";
            this.legend.Size = new System.Drawing.Size(846, 40);
            this.legend.TabIndex = 0;
            this.legend.Text = "legend_WOC1";
            this.legend.TextColor = System.Drawing.SystemColors.ControlText;
            this.legend.Vertical = false;
            // 
            // chart
            // 
            this.chart.ChartLength = 100;
            this.chart.ChartLineThikness = 3;
            this.chart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.chart.LineThikness = 1;
            this.chart.Location = new System.Drawing.Point(0, 0);
            this.chart.MaxYValue = 100;
            this.chart.MinYValue = 0;
            this.chart.Name = "chart";
            this.chart.Padding = new System.Windows.Forms.Padding(30, 30, 30, 5);
            this.chart.Size = new System.Drawing.Size(846, 296);
            this.chart.TabIndex = 1;
            this.chart.Text = "chart_WOC1";
            this.chart.ValueInterval = 50;
            // 
            // Chart_UC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.chart);
            this.Controls.Add(this.legend);
            this.Name = "Chart_UC";
            this.Size = new System.Drawing.Size(846, 336);
            this.ResumeLayout(false);

        }

        #endregion
        public LimitlessUI.Chart_WOC chart;
        public LimitlessUI.Legend_WOC legend;
    }
}
