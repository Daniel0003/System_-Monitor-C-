﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using OpenHardwareMonitor.Hardware;
using SystemMonitor;
using Microsoft.Win32;

public class DataCollector
{
    #region Batch of variables
    private static readonly string[] CPUIGNORE =
     {
            "L3CacheSpeed",
            "CurrentClockSpeed",
            "AssetTag",
            "Availability",
            "Caption",
            "Characteristics",
            "CpuStatus",
            "CreationClassName",
            "DataWidth",
            "AddressWidth",
            "DeviceID",
            "Family",
            "Level",
            "LoadPercentage",
            "Manufacturer",
            "PartNumber",
            "ProcessorId",
            "ProcessorType",
            "Revision",
            "Role",
            "SerialNumber",
            "SocketDesignation",
            "Status",
            "StatusInfo",
            "SystemCreationClassName",
            "SystemName",
            "UpgradeMethod",
            "Version",
            "Architecture",
            "CurrentVoltage"
        };

    private static readonly string[] RAMIGNORE =
    {
            "Attributes",
            "Caption",
            "CreationClassName",
            "Description",
            "DeviceLocator",
            "FormFactor",
            "InterleaveDataDepth",
            "InterleavePosition",
            "Name",
            "PositionInRow",
            "ConfiguredClockSpeed",
            "Tag",
            "TypeDetail",
            "MemoryType"
        };

    private static readonly string[] DRIVEIGNORE =
    {
            "Access: ",
            "CreationClassName",
            "DeviceID",
            "DriveType",
            "MaximumComponentLength",
            "MediaType",
            "SupportsDiskQuotas",
            "SystemCreationClassName",
            "SystemName"
        };

    private static readonly string[] GPUIGNORE =
    {
            "AdapterCompatibility",
            "AdapterDACType",
            "Availability",
            "ConfigManagerErrorCode",
            "ConfigManagerUserConfig",
            "CreationClassName",
            "CurrentNumberOfColumns",
            "CurrentNumberOfRows",
            "CurrentScanMode",
            "DeviceID",
            "DitherType",
            "InfFilename",
            "InfSection",
            "InstalledDisplayDrivers",
            "Monochrome",
            "PNPDeviceID",
            "SystemCreationClassName",
            "SystemName",
            "VideoArchitecture",
            "VideoMemoryType",
            "VideoProcessor",
            "CurrentHorizontalResolution",
            "CurrentVerticalResolution"
        };

    private static readonly string[] DRIVETYPES = {
            "Unknown",
            "No Root Directory",
            "Removable Disk",
            "Local Disk",
            "Network Drive",
            "Compact Disc",
            "RAM Disk"
            };

    private Computer _computer;

    public SortedDictionary<string, int> cpuLoad = new SortedDictionary<string, int>();
    public SortedDictionary<string, sbyte> cpuTemps = new SortedDictionary<string, sbyte>();
    public SortedDictionary<string, ushort> cpuClocks = new SortedDictionary<string, ushort>();
    public SortedDictionary<string, byte> cpuPowers = new SortedDictionary<string, byte>();

    public byte usedRamPrecentage;
    public float usedRam;
    public float totalRam;

    public SortedDictionary<string, ushort> gpuCoreClock = new SortedDictionary<string, ushort>();
    public SortedDictionary<string, ushort> gpuMemoryClock = new SortedDictionary<string, ushort>();
    public SortedDictionary<string, ushort> gpuShaderClock = new SortedDictionary<string, ushort>();
    public SortedDictionary<string, float> gpuCoreLoad = new SortedDictionary<string, float>();
    public SortedDictionary<string, float> gpuMemoryLoad = new SortedDictionary<string, float>();
    public SortedDictionary<string, float> gpuMemoryFree = new SortedDictionary<string, float>();
    public SortedDictionary<string, float> gpuMemoryUsed = new SortedDictionary<string, float>();
    public SortedDictionary<string, float> gpuMemoryTotal = new SortedDictionary<string, float>();
    public SortedDictionary<string, int> gpuTemps = new SortedDictionary<string, int>();

    public SortedDictionary<string, string> cpuData = new SortedDictionary<string, string>();
    public List<SortedDictionary<string, string>> ramData = new List<SortedDictionary<string, string>>();
    public List<SortedDictionary<string, string>> gpuData = new List<SortedDictionary<string, string>>();
    public List<SortedDictionary<string, string>> driveData = new List<SortedDictionary<string, string>>();

    private bool _run = true;
    public Boolean run = true;
    public Thread openComputerThread;
    public Thread cpuThread;
    public Thread ramThread;
    public Thread gpuThread;
    public ManualResetEvent dataCollected = new ManualResetEvent(false);
    public ManualResetEvent driveDataCollected = new ManualResetEvent(false);
    #endregion

    public DataCollector()
    {
        _computer = new Computer()
        {
            CPUEnabled = true,
            GPUEnabled = true,
            RAMEnabled = true,
            HDDEnabled = true
        };

        cpuThread = new Thread(new ThreadStart(loadCpuSpecs));
        ramThread = new Thread(new ThreadStart(loadRamSpecs));
        gpuThread = new Thread(new ThreadStart(loadGpuSpecs));
        openComputerThread = new Thread(new ThreadStart(_computer.Open));

        openComputerThread.Priority = ThreadPriority.Highest;

        openComputerThread.Start();
        cpuThread.Start();
        ramThread.Start();
        gpuThread.Start();

        new Thread(autoRefresh).Start();
    }

    public void autoRefresh()
    {
        openComputerThread.Join();
        while (run)
        {
            updateDriveData();
            refreshData();
            if (run)
                Thread.Sleep(Settings.Default.refreshRate);
        }
    }

    public void updateDriveData()
    {
        if (_run)
        {
            driveData.Clear();
            foreach (ManagementObject queryObj in new ManagementObjectSearcher("root\\CIMV2", "Select * from Win32_LogicalDisk").Get())
                foreach (PropertyData property in queryObj.Properties)
                    if (property.Value != null && !DRIVEIGNORE.Contains(property.Name))
                        if (property.Name.Equals("Caption"))
                        {
                            driveData.Add(new SortedDictionary<string, string>());
                            driveData.Last().Add("Caption", property.Value.ToString());
                        }
                        else if (property.Name.Equals("Size"))
                        {
                            driveData.Last()
                                .Add("Size", Math.Round(Convert.ToDouble(property.Value) / 1073741824, 2).ToString());
                            driveData.Last()
                                .Add("Used Space",
                                    Math.Round(Convert.ToDouble(property.Value) / 1073741824 -
                                               Convert.ToDouble(driveData.Last()["FreeSpace"]), 2).ToString());
                            driveData.Last()
                                .Add("Load",
                                    Math.Round(float.Parse(driveData.Last()["Used Space"]) /
                                               float.Parse(driveData.Last()["Size"]) * 100).ToString());
                        }
                        else if (property.Name.Equals("DriveType"))
                            driveData.Last().Add(property.Name, DRIVETYPES[Int16.Parse(property.Value.ToString())]);
                        else if (property.Name.Equals("FreeSpace"))
                            driveData.Last().Add("FreeSpace", (Convert.ToDouble(property.Value) / 1073741824).ToString());
            driveDataCollected.Set();
        }
    }

    public void loadCpuSpecs()
    {
        foreach (
         ManagementObject queryObj in
         new ManagementObjectSearcher("root\\CIMV2", "Select * from Win32_Processor").Get())
            foreach (PropertyData property in queryObj.Properties)
                if (property.Value != null && !CPUIGNORE.Contains(property.Name)) //CurrentVoltage - check
                {
                    if (property.Name.Contains("Speed") || property.Name.Contains("Clock"))
                        cpuData.Add(property.Name, property.Value + "Mhz");
                    else if (property.Name.Contains("Size"))
                        cpuData.Add(property.Name, property.Value + "KB");
                    else
                        cpuData.Add(property.Name, property.Value.ToString());
                }
    }

    public void loadRamSpecs()
    {
        foreach (
             ManagementObject queryObj in
             new ManagementObjectSearcher("root\\CIMV2", "Select * from Win32_PhysicalMemory").Get())
            foreach (PropertyData property in queryObj.Properties)
                if (property.Value != null && !RAMIGNORE.Contains(property.Name))
                    if (property.Name.Contains("BankLabel"))
                    {
                        ramData.Add(new SortedDictionary<string, string>());
                        ramData.Last().Add(property.Name, property.Value.ToString());
                    }
                    else if (property.Name.Contains("Voltage"))
                        ramData.Last().Add(property.Name, property.Value + "V");
                    else if (property.Name.Contains("Width"))
                        ramData.Last().Add(property.Name, property.Value + "Bit");
                    else if (property.Name.Contains("Speed"))
                        ramData.Last().Add(property.Name, property.Value + "Mhz");
                    else if (property.Name.Equals("Capacity"))
                        ramData.Last().Add(property.Name, (Int64.Parse(property.Value.ToString()) / (1024 * 1024)) + "MB");
                    else
                        ramData.Last().Add(property.Name, property.Value.ToString());
    }

    public void loadGpuSpecs()
    {
        foreach (ManagementObject queryObj in new ManagementObjectSearcher("root\\CIMV2", "Select * from Win32_VideoController").Get())
            foreach (PropertyData property in queryObj.Properties)
                if (property.Value != null && !GPUIGNORE.Contains(property.Name))
                {
                    if (property.Name.Equals("AdapterRAM"))
                    {
                        gpuData.Add(new SortedDictionary<string, string>());
                        gpuData.Last().Add(property.Name, (Int64.Parse(property.Value.ToString()) / (1024 * 1024)) + "MB");
                    }
                    else if (property.Name.Contains("Rate"))
                        gpuData.Last().Add(property.Name, property.Value + "Hz");
                    else if (property.Name.Contains("Bit"))
                        gpuData.Last().Add(property.Name, property.Value + "Bit");
                    else
                        gpuData.Last().Add(property.Name, property.Value.ToString());
                }
    }

    public void refreshData()
    {
        foreach (var hardwareItem in _computer.Hardware)
        {
            if (hardwareItem.HardwareType == HardwareType.CPU)
            {
                hardwareItem.Update();
                foreach (var sensor in hardwareItem.Sensors)
                {
                    if (sensor.SensorType == SensorType.Clock)
                        cpuClocks[sensor.Name] = (ushort)sensor.Value.Value;
                    else if (sensor.SensorType == SensorType.Temperature)
                        cpuTemps[sensor.Name] = (sbyte)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                    else if (sensor.SensorType == SensorType.Load)
                        cpuLoad[sensor.Name] = (int)sensor.Value.Value;
                    else if (sensor.SensorType == SensorType.Power)
                        cpuPowers[sensor.Name] = (byte)sensor.Value.Value;
                }
            }

            if (hardwareItem.HardwareType == HardwareType.RAM)
            {
                hardwareItem.Update();
                foreach (var sensor in hardwareItem.Sensors)
                    if (sensor.SensorType == SensorType.Load)
                        usedRamPrecentage = (byte)sensor.Value.Value;
                    else if (sensor.SensorType == SensorType.Data)
                        if (sensor.Name.Equals("Used Memory"))
                            usedRam = sensor.Value.Value;
                        else
                            totalRam = usedRam + sensor.Value.Value;
            }

            if (hardwareItem.HardwareType == HardwareType.GpuNvidia ||
             hardwareItem.HardwareType == HardwareType.GpuAti)
            {
                hardwareItem.Update();
                foreach (var sensor in hardwareItem.Sensors)
                    if (sensor.SensorType == SensorType.Clock)
                    {
                        if (sensor.Name == "GPU Core")
                            gpuCoreClock[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                        if (sensor.Name == "GPU Memory")
                            gpuMemoryClock[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                        if (sensor.Name == "GPU Shader")
                            gpuShaderClock[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                    }
                    else if (sensor.SensorType == SensorType.Temperature)
                        gpuTemps[hardwareItem.Name] =
                        (byte)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                    else if (sensor.SensorType == SensorType.Load)
                    {
                        if (sensor.Name == "GPU Core")
                            gpuCoreLoad[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                        if (sensor.Name == "GPU Memory")
                            gpuMemoryLoad[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                    }
                    else if (sensor.SensorType == SensorType.Data)
                    {
                        if (sensor.Name == "GPU Memory Free")
                            gpuCoreLoad[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                        if (sensor.Name == "GPU Memory Used")
                            gpuMemoryLoad[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                        if (sensor.Name == "GPU Memory Total")
                            gpuMemoryLoad[hardwareItem.Name] =
                            (ushort)(sensor.Value.HasValue ? sensor.Value.Value : 0);
                    }
            }
        }
        dataCollected.Set();
    }
    public string CpuName
    {
        get
        {
            RegistryKey processor_name = Registry.LocalMachine.OpenSubKey(@"Hardware\Description\System\CentralProcessor\0", RegistryKeyPermissionCheck.ReadSubTree); //This registry entry contains entry for processor info.
            if (processor_name != null)
                if (processor_name.GetValue("ProcessorNameString") != null)
                    return processor_name.GetValue("ProcessorNameString").ToString();
            return null;
        }
    }
}