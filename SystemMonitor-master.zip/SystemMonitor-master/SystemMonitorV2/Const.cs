﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemMonitor
{
    class Const
    {
        public static readonly string[] CPU_IGNORE =
        {
            "L3CacheSpeed",
            "CurrentClockSpeed",
            "AssetTag",
            "Availability",
            "Caption",
            "Characteristics",
            "CpuStatus",
            "CreationClassName",
            "DataWidth",
            "AddressWidth",
            "DeviceID",
            "Family",
            "Level",
            "LoadPercentage",
            "Manufacturer",
            "PartNumber",
            "ProcessorId",
            "ProcessorType",
            "Revision",
            "Role",
            "SerialNumber",
            "SocketDesignation",
            "Status",
            "StatusInfo",
            "SystemCreationClassName",
            "SystemName",
            "UpgradeMethod",
            "Version",
            "Architecture",
            "CurrentVoltage"
        };

        public static readonly string[] RAM_IGNORE =
        {
            "Attributes",
            "Caption",
            "CreationClassName",
            "Description",
            "DeviceLocator",
            "FormFactor",
            "InterleaveDataDepth",
            "InterleavePosition",
            "Name",
            "PositionInRow",
            "ConfiguredClockSpeed",
            "Tag",
            "TypeDetail",
            "MemoryType"
        };

        public static readonly string[] DRIVE_IGNORE =
        {
            "Access: ",
            "CreationClassName",
            "DeviceID",
            "DriveType",
            "MaximumComponentLength",
            "MediaType",
            "SupportsDiskQuotas",
            "SystemCreationClassName",
            "SystemName"
        };

        public static readonly string[] GPU_IGNORE =
        {
            "AdapterCompatibility",
            "AdapterDACType",
            "Availability",
            "ConfigManagerErrorCode",
            "ConfigManagerUserConfig",
            "CreationClassName",
            "CurrentNumberOfColumns",
            "CurrentNumberOfRows",
            "CurrentScanMode",
            "DeviceID",
            "DitherType",
            "InfFilename",
            "InfSection",
            "InstalledDisplayDrivers",
            "Monochrome",
            "PNPDeviceID",
            "SystemCreationClassName",
            "SystemName",
            "VideoArchitecture",
            "VideoMemoryType",
            "VideoProcessor",
            "CurrentHorizontalResolution",
            "CurrentVerticalResolution"
        };

        public static readonly string[] DRIVE_TYPES =
        {
            "Unknown",
            "No Root Directory",
            "Removable Disk",
            "Local Disk",
            "Network Drive",
            "Compact Disc",
            "RAM Disk"
        };
    }
}