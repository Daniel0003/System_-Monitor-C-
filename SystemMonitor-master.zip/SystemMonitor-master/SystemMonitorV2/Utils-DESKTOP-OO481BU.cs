﻿using LimitlessUI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using SystemMonitor;
using SystemMonitor.ListItems;

class Utils
{
    public static readonly string PATH = Path.GetFullPath("System Monitor.exe");
    public static int fontSize1 = 11;
    public static Stopwatch stopwatch = new Stopwatch();

    public static void changeChartTheme(Chart chart, bool light)
    {
        chart.BackColor = light ? Color.White : Theme.Default.background_dark;
        chart.Legends[0].ForeColor = !light ? Color.White : Theme.Default.background_dark;
        chart.ChartAreas[0].BackColor = light ? Color.White : Theme.Default.background_dark;
        chart.ChartAreas[0].AxisX.LineColor = !light ? Color.White : Theme.Default.background_dark;
        chart.ChartAreas[0].AxisY.LineColor = !light ? Color.White : Theme.Default.background_dark;
        chart.ChartAreas[0].AxisY.LabelStyle.ForeColor = !light ? Color.White : Theme.Default.background_dark;
    }
    public static void changeSpecsTheme(ListView_WOC specsContainer, bool isLight)
    {
        foreach (Control item in specsContainer.items)
            if (item is Specs_ListChild)
                ((Specs_ListChild)item).isLightTheme(isLight);
            else if(item is Label)
            {
               item.ForeColor = isLight ? Color.Black : Color.White;
            }
    }
    public static Label generateTitleLabel(string title)
    {
        return new Label()
        {
            Text = title,
            Font = new Font("Segoe UI Semibold", 13, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)))
        };
    }
    public static List<string> readFile(string path)
    {
        return File.Exists(PATH + "//" + path) ? File.ReadAllLines(PATH + "//" + path).ToList() : new List<string>();
    }
    public static string listToString(List<string> list)
    {
        string s = "";
        foreach (string st in list)
            s += st;
        return s;
    }

    public static int averageValue(List<float> list)
    {
        int value = 0;
        foreach (int i in list)
        {
            value += i;
        }
        return value / list.Count();
    }

    public static void loadUserControl(UserControl control, int X, int Y, Panel container)
    {
        control.Location = new Point(X, Y);
        container.Controls.Add(control);
    }

    public static void prepareChart(Chart chart, int xLenght)
    {
        chart.Height = Settings.Default.graphHeight;
        chart.ChartAreas[0].AxisX.Maximum = xLenght;
        foreach (Series s in chart.Series)
        {
            s.BorderWidth = Settings.Default.chartBorderWidth;
        }
    }

    public static void addSerie(SeriesCollection series, string serieName)
    {
        series.Add(serieName);
        series.Last().ChartType = SeriesChartType.Line;
        series.Last().BorderWidth = Settings.Default.chartBorderWidth;
        series.Last().Points.AddY(5);
    }

    public static Color getColorPerTemp(int temp)
    {
        if (temp > 70)
            return Color.Red;
        else if (temp > 50)
            return Color.Orange;
        else if (temp > 25)
            return Color.LawnGreen;
        else if (temp > 0)
            return Color.Blue;

        return Color.DeepSkyBlue;
    }

    public static string StringToHex(Color c)
    {
        return $"{c.R:X2}{c.G:X2}{c.B:X2}";
    }

    public static void showNotification(NotifyIcon ni, string title, string content, ToolTipIcon icon)
    {
        ni.ShowBalloonTip(1500, title, content, icon);
    }

    internal static float averageValue(SortedDictionary<string, float> dictionary)
    {
        float total = 0;
        foreach (float var in dictionary.Values)
            total += var;
        return total / dictionary.Count;
    }
    internal static float averageValue(SortedDictionary<string, int> dictionary)
    {
        float total = 0;
        foreach (float var in dictionary.Values)
            total += var;
        return total / dictionary.Count;
    }
}
